package com.example

import com.example.data.model.Sale
import org.junit.Assert.assertEquals
import org.junit.Test

class RealizedProfitCalculationTest {

    private fun realizedProfit(sale: Sale): Double {
        val total = sale.totalSaleAmount
        if (total <= 0.001 || sale.profit == 0.0) return 0.0
        val received = sale.amountReceived.coerceIn(0.0, total)
        return (sale.profit * (received / total)).coerceIn(
            minOf(0.0, sale.profit),
            maxOf(0.0, sale.profit)
        )
    }

    @Test
    fun zeroReceivedMeansZeroRealizedProfit() {
        val sale = Sale(
            productId = 1L,
            productName = "Formula 1 Shake",
            quantity = 1,
            totalSaleAmount = 1543.82,
            totalPurchaseCost = 1285.61,
            profit = 258.21,
            amountReceived = 0.0,
            amountPending = 1543.82,
            paymentStatus = "PENDING"
        )

        assertEquals(0.0, realizedProfit(sale), 0.001)
    }

    @Test
    fun partialPaymentRealizesProportionalProfit() {
        val sale = Sale(
            productId = 1L,
            productName = "Formula 1 Shake",
            quantity = 2,
            totalSaleAmount = 4260.74,
            totalPurchaseCost = 3538.74,
            profit = 722.0,
            amountReceived = 2130.37,
            amountPending = 2130.37,
            paymentStatus = "PARTIAL"
        )

        assertEquals(361.0, realizedProfit(sale), 0.001)
    }

    @Test
    fun fullPaymentRealizesFullProfit() {
        val sale = Sale(
            productId = 1L,
            productName = "Formula 1 Shake",
            quantity = 1,
            totalSaleAmount = 1543.82,
            totalPurchaseCost = 1285.61,
            profit = 258.21,
            amountReceived = 1543.82,
            amountPending = 0.0,
            paymentStatus = "PAID"
        )

        assertEquals(258.21, realizedProfit(sale), 0.001)
    }
}
