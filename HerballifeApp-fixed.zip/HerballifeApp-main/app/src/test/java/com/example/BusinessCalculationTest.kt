package com.example

import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.Sale
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class BusinessCalculationTest {

    @Test
    fun testPurchaseCostAndTaxCalculation() {
        val mrp = 2000.0
        val discountPercent = 25.0 // 25% discount on MRP -> 500
        val discountAmount = mrp * (discountPercent / 100.0)
        assertEquals(500.0, discountAmount, 0.001)

        val priceAfterDiscount = mrp - discountAmount
        assertEquals(1500.0, priceAfterDiscount, 0.001)

        val taxPercent = 18.0 // 18% GST
        val taxAmount = priceAfterDiscount * (taxPercent / 100.0)
        assertEquals(270.0, taxAmount, 0.001)

        val finalCostPerUnit = priceAfterDiscount + taxAmount
        assertEquals(1770.0, finalCostPerUnit, 0.001)

        val quantity = 10
        val totalPurchaseAmount = finalCostPerUnit * quantity
        assertEquals(17700.0, totalPurchaseAmount, 0.001)
    }

    @Test
    fun testStockMovementIntegrity() {
        var currentStock = 0

        // Purchase 20 units
        val purchaseQty = 20
        currentStock += purchaseQty
        assertEquals(20, currentStock)

        // Sell 5 units
        val sale1Qty = 5
        currentStock -= sale1Qty
        assertEquals(15, currentStock)

        // Sell another 7 units
        val sale2Qty = 7
        currentStock -= sale2Qty
        assertEquals(8, currentStock)

        // Purchase additional 12 units
        val purchase2Qty = 12
        currentStock += purchase2Qty
        assertEquals(20, currentStock)
    }

    @Test
    fun testSaleProfitAndPointsCalculation() {
        val unitPurchaseCost = 1444.32
        val baseSellingPrice = 2100.0
        val sellingDiscountPercent = 5.0 // 5% discount to customer
        val discountAmount = baseSellingPrice * (sellingDiscountPercent / 100.0)
        val finalSellingPrice = baseSellingPrice - discountAmount
        assertEquals(1995.0, finalSellingPrice, 0.001)

        val quantity = 4
        val totalSaleAmount = finalSellingPrice * quantity
        assertEquals(7980.0, totalSaleAmount, 0.001)

        val totalCost = unitPurchaseCost * quantity
        assertEquals(5777.28, totalCost, 0.001)

        val profit = totalSaleAmount - totalCost
        assertEquals(2202.72, profit, 0.001)

        // Points calculation
        val pointsPerUnit = 1.025
        val totalPoints = pointsPerUnit * quantity
        assertEquals(4.1, totalPoints, 0.001)
    }

    @Test
    fun testHistoricalTransactionIndependence() {
        // Product at time of purchase & sale
        val originalProduct = Product(
            id = 1L,
            name = "Protein Whey 1kg",
            sku = "PW-100",
            variant = "Vanilla",
            mrp = 3000.0,
            purchasePrice = 2200.0,
            discountPercentage = 20.0,
            taxPercentage = 18.0,
            finalPurchaseCost = 2076.8,
            sellingPrice = 2800.0,
            points = 2.0,
            currentStock = 10
        )

        // Historical Sale recorded
        val historicSale = Sale(
            id = 101L,
            productId = originalProduct.id,
            productName = originalProduct.name,
            quantity = 2,
            sellingPrice = originalProduct.sellingPrice,
            discountPercentage = 0.0,
            discountAmount = 0.0,
            finalSellingPrice = 2800.0,
            totalSaleAmount = 5600.0,
            unitPurchaseCost = originalProduct.finalPurchaseCost,
            totalPurchaseCost = originalProduct.finalPurchaseCost * 2,
            profit = 5600.0 - (originalProduct.finalPurchaseCost * 2),
            pointsPerUnit = originalProduct.points,
            totalPoints = originalProduct.points * 2,
            customerName = "Test Client",
            saleDate = 1672531199000L // Historical timestamp
        )

        // User now updates product price in catalog to higher rate
        val updatedProduct = originalProduct.copy(
            mrp = 3500.0,
            purchasePrice = 2600.0,
            finalPurchaseCost = 2454.4,
            sellingPrice = 3300.0,
            points = 2.5
        )

        // Verify historicSale remains completely unaffected by the catalog price change
        assertEquals(5600.0, historicSale.totalSaleAmount, 0.001)
        assertEquals(2076.8, historicSale.unitPurchaseCost, 0.001)
        assertEquals(4153.6, historicSale.totalPurchaseCost, 0.001)
        assertEquals(1446.4, historicSale.profit, 0.001)
        assertEquals(4.0, historicSale.totalPoints, 0.001)
        assertNotEquals(updatedProduct.sellingPrice * historicSale.quantity, historicSale.totalSaleAmount)
    }

    @Test
    fun testDateFilterTimestampRanges() {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfToday = cal.timeInMillis
        val endOfToday = startOfToday + 24 * 3600 * 1000L - 1

        // Current moment must be inside TODAY range
        assertTrue(now in startOfToday..endOfToday)

        // Yesterday
        val yCal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfYesterday = yCal.timeInMillis
        val endOfYesterday = startOfYesterday + 24 * 3600 * 1000L - 1
        assertTrue(startOfYesterday < startOfToday)
        assertEquals(startOfToday - 1, endOfYesterday)

        // Month start
        val mCal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfMonth = mCal.timeInMillis
        assertTrue(startOfMonth <= startOfToday)
        assertTrue(now >= startOfMonth)
    }
}
