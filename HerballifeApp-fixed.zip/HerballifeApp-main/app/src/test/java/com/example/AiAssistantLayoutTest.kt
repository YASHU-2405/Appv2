package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.test.core.app.ApplicationProvider
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AiAssistantViewModel
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AiAssistantLayoutTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testAiAssistantInputBarComponentsExist() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = AiAssistantViewModel(app)

        composeTestRule.setContent {
            MyApplicationTheme {
                AiAssistantScreen(
                    viewModel = viewModel,
                    onNavigateToDestination = {}
                )
            }
        }

        // 1. Screen root container
        composeTestRule.onNodeWithTag("ai_assistant_screen").assertIsDisplayed()

        // 2. Input bar surface container
        composeTestRule.onNodeWithTag("ai_input_bar_surface").assertIsDisplayed()

        // 3. All 5 required components in input bar
        composeTestRule.onNodeWithTag("ai_camera_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_gallery_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_mic_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_text_input").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_send_button").assertIsDisplayed()
    }
}
