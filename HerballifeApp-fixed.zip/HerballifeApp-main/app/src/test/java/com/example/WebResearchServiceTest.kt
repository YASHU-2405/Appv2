package com.example

import com.example.data.ai.WebResearchService
import com.example.data.model.Product
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class WebResearchServiceTest {

    @Test
    fun testIsWebResearchQueryDetection() {
        assertTrue(WebResearchService.isWebResearchQuery("What is Herbalife Formula 1?"))
        assertTrue(WebResearchService.isWebResearchQuery("Formula 1 ka official MRP kitna hai?"))
        assertTrue(WebResearchService.isWebResearchQuery("Afresh energy drink ingredients and directions"))
        assertTrue(WebResearchService.isWebResearchQuery("Personalized Protein Powder nutrition facts"))
        assertTrue(WebResearchService.isWebResearchQuery("Herbalifeline omega 3 warnings"))
        assertTrue(WebResearchService.isWebResearchQuery("Search web for Cell-U-Loss"))
        assertTrue(WebResearchService.isWebResearchQuery("Official price of Dinoshake on herbalife.co.in"))

        // Pure internal commands should not trigger web research
        assertFalse(WebResearchService.isWebResearchQuery("Sell 2 items"))
        assertFalse(WebResearchService.isWebResearchQuery("Record purchase of 5 Shakes"))
        assertFalse(WebResearchService.isWebResearchQuery("Delete product"))
    }

    @Test
    fun testOfficialHerbalifeFormula1SpecsAndThreePartSeparation() = runBlocking {
        val existingLocalCatalog = listOf(
            Product(
                id = 1,
                name = "Formula 1 Nutritional Shake Mix (Dutch Chocolate 500g)",
                sku = "1247",
                mrp = 2392.0,
                purchasePrice = 1500.0,
                finalPurchaseCost = 1500.0,
                sellingPrice = 2000.0,
                currentStock = 8,
                points = 21.75
            )
        )

        val result = WebResearchService.performWebResearch("Formula 1 Dutch Chocolate MRP and ingredients", existingLocalCatalog)

        // 1. Must include Official Herbalife Website Information section
        assertTrue("Must have official section", result.formattedText.contains("Official Website Information", ignoreCase = true))
        assertTrue("Must have official name", result.formattedText.contains("Formula 1 Nutritional Shake Mix"))
        assertTrue("Must have official MRP", result.formattedText.contains("2176"))
        assertTrue("Must have Net Quantity", result.formattedText.contains("500g"))
        assertTrue("Must have Ingredients", result.formattedText.contains("Soy Protein Isolate"))
        assertTrue("Must have Serving Directions", result.formattedText.contains("25g (approximately 3 flat 10ml scoops"))
        assertTrue("Must have Official Source", result.formattedText.contains("https://www.herbalife.co.in/"))

        // 2. Must include local business inventory section
        assertTrue("Must have local inventory section", result.formattedText.contains("My Personal Inventory / Business Data", ignoreCase = true))
        assertTrue("Must reflect current local stock", result.formattedText.contains("Current In-Stock: 8 units"))
        assertTrue("Must reflect current local selling price", result.formattedText.contains("Your Selling Price: ₹2000.00 / unit"))

        // 3. Must include AI Explanation section
        assertTrue("Must have AI explanation section", result.formattedText.contains("AI-Generated Explanation", ignoreCase = true))

        // 4. Must provide citations
        assertTrue("Must have citations", result.citations.isNotEmpty())
        assertTrue(result.citations.first().sourceName.contains("Herbalife India Official"))
        assertTrue(result.citations.first().url.contains("herbalife.co.in"))
    }

    @Test
    fun testAfreshEnergyDrinkSpecs() = runBlocking {
        val emptyCatalog = emptyList<Product>()
        val result = WebResearchService.performWebResearch("What are the ingredients and directions for Afresh Energy Drink Mix Elaichi?", emptyCatalog)

        assertTrue(result.formattedText.contains("Afresh Energy Drink Mix"))
        assertTrue(result.formattedText.contains("Orange Pekoe Black Tea Extract, Green Tea Extract"))
        assertTrue(result.formattedText.contains("Mix 1g of Afresh with 160ml hot or cold water"))
        assertTrue(result.formattedText.contains("1296 (Elaichi)"))
        assertTrue(result.formattedText.contains("50g"))
        assertTrue(result.formattedText.contains("Official Website Information", ignoreCase = true))
        assertTrue(result.formattedText.contains("Not currently in your local inventory"))

        // Should suggest catalog action because it is missing in local DB
        assertNotNull("Should propose catalog draft", result.suggestedCatalogAction)
    }

    @Test
    fun testOfficialSourceFallbacksAndNoHallucinations() = runBlocking {
        val emptyCatalog = emptyList<Product>()
        // Unknown product lookup
        val result = WebResearchService.performWebResearch("Official specs of NonExistentProduct12345", emptyCatalog)

        // When not found on official source, it must state "Not found on the official source"
        assertTrue(result.formattedText.contains("Not found on the official source"))
    }
}
