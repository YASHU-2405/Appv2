package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.preferences.CustomThemeConfig

data class ThemePreset(
    val name: String,
    val config: CustomThemeConfig
)

val PRESET_THEMES = listOf(
    ThemePreset(
        name = "Forest Emerald",
        config = CustomThemeConfig(
            primaryColor = 0xFF1B5E20,
            secondaryColor = 0xFF2E7D32,
            backgroundColor = 0xFFF9FBF7,
            surfaceColor = 0xFFFFFFFF,
            textColor = 0xFF1A1C18,
            accentColor = 0xFFFFB300,
            isDark = false
        )
    ),
    ThemePreset(
        name = "Ocean Blue",
        config = CustomThemeConfig(
            primaryColor = 0xFF0D47A1,
            secondaryColor = 0xFF1976D2,
            backgroundColor = 0xFFF4F7FB,
            surfaceColor = 0xFFFFFFFF,
            textColor = 0xFF0D1B2A,
            accentColor = 0xFF00B4D8,
            isDark = false
        )
    ),
    ThemePreset(
        name = "Royal Velvet",
        config = CustomThemeConfig(
            primaryColor = 0xFF4A148C,
            secondaryColor = 0xFF7B1FA2,
            backgroundColor = 0xFFFAF5FF,
            surfaceColor = 0xFFFFFFFF,
            textColor = 0xFF21005D,
            accentColor = 0xFFFF80AB,
            isDark = false
        )
    ),
    ThemePreset(
        name = "Cyber Neon (Dark)",
        config = CustomThemeConfig(
            primaryColor = 0xFF00E676,
            secondaryColor = 0xFF00B0FF,
            backgroundColor = 0xFF121212,
            surfaceColor = 0xFF1E1E1E,
            textColor = 0xFFE0E0E0,
            accentColor = 0xFFFFD600,
            isDark = true
        )
    ),
    ThemePreset(
        name = "Midnight Slate (Dark)",
        config = CustomThemeConfig(
            primaryColor = 0xFF81C784,
            secondaryColor = 0xFF4CAF50,
            backgroundColor = 0xFF121814,
            surfaceColor = 0xFF1B231C,
            textColor = 0xFFE1E3DF,
            accentColor = 0xFFFFB74D,
            isDark = true
        )
    ),
    ThemePreset(
        name = "Warm Sunset",
        config = CustomThemeConfig(
            primaryColor = 0xFFBF360C,
            secondaryColor = 0xFFD84315,
            backgroundColor = 0xFFFFF8F6,
            surfaceColor = 0xFFFFFFFF,
            textColor = 0xFF2A150E,
            accentColor = 0xFFFF6F00,
            isDark = false
        )
    )
)

val COLOR_SWATCHES = listOf(
    0xFF1B5E20, 0xFF2E7D32, 0xFF00796B, 0xFF0D47A1, 0xFF1565C0, 0xFF0288D1,
    0xFF4A148C, 0xFF6A1B9A, 0xFFC2185B, 0xFFBF360C, 0xFFD84315, 0xFFE65100,
    0xFFFFB300, 0xFFFFD600, 0xFF212121, 0xFF37474F, 0xFF455A64, 0xFF78909C
)

@Composable
fun CustomThemeEditor(
    currentConfig: CustomThemeConfig,
    onConfigChange: (CustomThemeConfig) -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedColorTarget by remember { mutableStateOf("primary") }
    var hexInputText by remember(currentConfig, selectedColorTarget) {
        val colorLong = when (selectedColorTarget) {
            "primary" -> currentConfig.primaryColor
            "secondary" -> currentConfig.secondaryColor
            "accent" -> currentConfig.accentColor
            "background" -> currentConfig.backgroundColor
            "surface" -> currentConfig.surfaceColor
            "text" -> currentConfig.textColor
            else -> currentConfig.primaryColor
        }
        mutableStateOf("%06X".format(colorLong and 0xFFFFFF))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("custom_theme_editor_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Custom Theme Designer",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(
                    onClick = onReset,
                    modifier = Modifier.testTag("reset_custom_theme_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset")
                }
            }

            // Live Preview Box
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp)),
                color = Color(currentConfig.backgroundColor),
                border = BorderStroke(1.dp, Color(currentConfig.primaryColor).copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Theme Preview",
                            fontWeight = FontWeight.Bold,
                            color = Color(currentConfig.textColor),
                            fontSize = 14.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(currentConfig.accentColor).copy(alpha = 0.25f)
                        ) {
                            Text(
                                text = "ACCENT",
                                color = Color(currentConfig.accentColor),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(currentConfig.surfaceColor),
                        border = BorderStroke(1.dp, Color(currentConfig.textColor).copy(alpha = 0.15f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Store Product Name",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = Color(currentConfig.textColor)
                                )
                                Text(
                                    text = "Surface container styling",
                                    fontSize = 11.sp,
                                    color = Color(currentConfig.textColor).copy(alpha = 0.7f)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(currentConfig.primaryColor)
                            ) {
                                Text(
                                    text = "Button",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Presets Selector
            Text(
                text = "Curated Color Palettes:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(PRESET_THEMES) { preset ->
                    val isSelected = currentConfig.primaryColor == preset.config.primaryColor &&
                            currentConfig.backgroundColor == preset.config.backgroundColor
                    FilterChip(
                        selected = isSelected,
                        onClick = { onConfigChange(preset.config) },
                        label = { Text(preset.name) },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color(preset.config.primaryColor))
                            )
                        },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            HorizontalDivider()

            // Dark canvas toggle for custom theme
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Dark Canvas Mode",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Switch background/surface to dark tones",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = currentConfig.isDark,
                    onCheckedChange = { isDark ->
                        val updated = if (isDark) {
                            currentConfig.copy(
                                isDark = true,
                                backgroundColor = 0xFF121814,
                                surfaceColor = 0xFF1E241F,
                                textColor = 0xFFE1E3DF
                            )
                        } else {
                            currentConfig.copy(
                                isDark = false,
                                backgroundColor = 0xFFF9FBF7,
                                surfaceColor = 0xFFFFFFFF,
                                textColor = 0xFF1A1C18
                            )
                        }
                        onConfigChange(updated)
                    }
                )
            }

            // Target Component Color Selector
            Text(
                text = "Customize Element Color:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )

            val targets = listOf(
                "primary" to "Primary",
                "secondary" to "Secondary",
                "accent" to "Accent",
                "surface" to "Surface",
                "background" to "Background",
                "text" to "Text"
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(targets) { (key, label) ->
                    val isSelected = selectedColorTarget == key
                    val colorLong = when (key) {
                        "primary" -> currentConfig.primaryColor
                        "secondary" -> currentConfig.secondaryColor
                        "accent" -> currentConfig.accentColor
                        "background" -> currentConfig.backgroundColor
                        "surface" -> currentConfig.surfaceColor
                        "text" -> currentConfig.textColor
                        else -> currentConfig.primaryColor
                    }
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedColorTarget = key },
                        label = { Text(label) },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorLong))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                            )
                        },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            // Quick Color Palette Swatches
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(COLOR_SWATCHES) { colorLong ->
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(colorLong))
                            .border(1.5.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                            .clickable {
                                val updated = when (selectedColorTarget) {
                                    "primary" -> currentConfig.copy(primaryColor = colorLong)
                                    "secondary" -> currentConfig.copy(secondaryColor = colorLong)
                                    "accent" -> currentConfig.copy(accentColor = colorLong)
                                    "background" -> currentConfig.copy(backgroundColor = colorLong)
                                    "surface" -> currentConfig.copy(surfaceColor = colorLong)
                                    "text" -> currentConfig.copy(textColor = colorLong)
                                    else -> currentConfig
                                }
                                onConfigChange(updated)
                            }
                    )
                }
            }

            // Hex Code Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = hexInputText,
                    onValueChange = { input ->
                        val filtered = input.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }.take(6)
                        hexInputText = filtered
                        if (filtered.length == 6) {
                            try {
                                val parsed = 0xFF000000 or filtered.toLong(16)
                                val updated = when (selectedColorTarget) {
                                    "primary" -> currentConfig.copy(primaryColor = parsed)
                                    "secondary" -> currentConfig.copy(secondaryColor = parsed)
                                    "accent" -> currentConfig.copy(accentColor = parsed)
                                    "background" -> currentConfig.copy(backgroundColor = parsed)
                                    "surface" -> currentConfig.copy(surfaceColor = parsed)
                                    "text" -> currentConfig.copy(textColor = parsed)
                                    else -> currentConfig
                                }
                                onConfigChange(updated)
                            } catch (_: Exception) { }
                        }
                    },
                    label = { Text("Hex Code (#RRGGBB)") },
                    prefix = { Text("#", fontWeight = FontWeight.Bold) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = try {
                        Color(0xFF000000 or (hexInputText.takeIf { it.length == 6 }?.toLong(16) ?: 0L))
                    } catch (_: Exception) {
                        Color.Gray
                    },
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {}
            }
        }
    }
}
