package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
    CUSTOM
}

data class CustomThemeConfig(
    val primaryColor: Long = 0xFF1B5E20,
    val secondaryColor: Long = 0xFF2E7D32,
    val backgroundColor: Long = 0xFFF9FBF7,
    val surfaceColor: Long = 0xFFFFFFFF,
    val textColor: Long = 0xFF1A1C18,
    val accentColor: Long = 0xFFFFB300,
    val isDark: Boolean = false
)

data class UserProfile(
    val businessName: String = "Onest Nutrition Hub",
    val ownerName: String = "Yash Tyagi",
    val phone: String = "+91 98765 43210",
    val email: String = "yash.tyagi24052@gmail.com",
    val tagline: String = "Premium Nutrition & Wellness",
    val avatarUri: String = "",
    val defaultPurchaseDiscount: Double = 25.0
)

class AppSettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("onest_nutrition_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _customThemeConfig = MutableStateFlow(loadCustomThemeConfig())
    val customThemeConfig: StateFlow<CustomThemeConfig> = _customThemeConfig.asStateFlow()

    private val _animationsEnabled = MutableStateFlow(prefs.getBoolean(KEY_ANIMATIONS, true))
    val animationsEnabled: StateFlow<Boolean> = _animationsEnabled.asStateFlow()

    private val _subtractUsageCostFromRevenue = MutableStateFlow(prefs.getBoolean(KEY_SUBTRACT_USAGE_COST, false))
    val subtractUsageCostFromRevenue: StateFlow<Boolean> = _subtractUsageCostFromRevenue.asStateFlow()

    private val _userProfile = MutableStateFlow(loadUserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeMode.value = mode
    }

    fun updateCustomThemeConfig(config: CustomThemeConfig) {
        prefs.edit()
            .putLong(KEY_CUSTOM_PRIMARY, config.primaryColor)
            .putLong(KEY_CUSTOM_SECONDARY, config.secondaryColor)
            .putLong(KEY_CUSTOM_BG, config.backgroundColor)
            .putLong(KEY_CUSTOM_SURFACE, config.surfaceColor)
            .putLong(KEY_CUSTOM_TEXT, config.textColor)
            .putLong(KEY_CUSTOM_ACCENT, config.accentColor)
            .putBoolean(KEY_CUSTOM_IS_DARK, config.isDark)
            .apply()
        _customThemeConfig.value = config
    }

    fun resetCustomTheme() {
        updateCustomThemeConfig(CustomThemeConfig())
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ANIMATIONS, enabled).apply()
        _animationsEnabled.value = enabled
    }

    fun setSubtractUsageCostFromRevenue(subtract: Boolean) {
        prefs.edit().putBoolean(KEY_SUBTRACT_USAGE_COST, subtract).apply()
        _subtractUsageCostFromRevenue.value = subtract
    }

    fun setDefaultPurchaseDiscount(discount: Double) {
        val clamped = discount.coerceIn(0.0, 100.0)
        prefs.edit().putString(KEY_DEFAULT_PURCHASE_DISCOUNT, clamped.toString()).apply()
        _userProfile.value = _userProfile.value.copy(defaultPurchaseDiscount = clamped)
    }

    fun updateUserProfile(profile: UserProfile) {
        prefs.edit()
            .putString(KEY_BIZ_NAME, profile.businessName)
            .putString(KEY_OWNER_NAME, profile.ownerName)
            .putString(KEY_PHONE, profile.phone)
            .putString(KEY_EMAIL, profile.email)
            .putString(KEY_TAGLINE, profile.tagline)
            .putString(KEY_AVATAR, profile.avatarUri)
            .putString(KEY_DEFAULT_PURCHASE_DISCOUNT, profile.defaultPurchaseDiscount.coerceIn(0.0, 100.0).toString())
            .apply()
        _userProfile.value = profile.copy(defaultPurchaseDiscount = profile.defaultPurchaseDiscount.coerceIn(0.0, 100.0))
    }

    private fun loadThemeMode(): ThemeMode {
        val saved = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name)
        return try {
            ThemeMode.valueOf(saved ?: ThemeMode.SYSTEM.name)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        }
    }

    private fun loadCustomThemeConfig(): CustomThemeConfig {
        return CustomThemeConfig(
            primaryColor = prefs.getLong(KEY_CUSTOM_PRIMARY, 0xFF1B5E20),
            secondaryColor = prefs.getLong(KEY_CUSTOM_SECONDARY, 0xFF2E7D32),
            backgroundColor = prefs.getLong(KEY_CUSTOM_BG, 0xFFF9FBF7),
            surfaceColor = prefs.getLong(KEY_CUSTOM_SURFACE, 0xFFFFFFFF),
            textColor = prefs.getLong(KEY_CUSTOM_TEXT, 0xFF1A1C18),
            accentColor = prefs.getLong(KEY_CUSTOM_ACCENT, 0xFFFFB300),
            isDark = prefs.getBoolean(KEY_CUSTOM_IS_DARK, false)
        )
    }

    private fun loadUserProfile(): UserProfile {
        val discStr = prefs.getString(KEY_DEFAULT_PURCHASE_DISCOUNT, "25.0") ?: "25.0"
        val parsedDisc = (discStr.toDoubleOrNull() ?: 25.0).coerceIn(0.0, 100.0)
        return UserProfile(
            businessName = prefs.getString(KEY_BIZ_NAME, "Onest Nutrition Hub") ?: "Onest Nutrition Hub",
            ownerName = prefs.getString(KEY_OWNER_NAME, "Yash Tyagi") ?: "Yash Tyagi",
            phone = prefs.getString(KEY_PHONE, "+91 98765 43210") ?: "+91 98765 43210",
            email = prefs.getString(KEY_EMAIL, "yash.tyagi24052@gmail.com") ?: "yash.tyagi24052@gmail.com",
            tagline = prefs.getString(KEY_TAGLINE, "Premium Nutrition & Wellness") ?: "Premium Nutrition & Wellness",
            avatarUri = prefs.getString(KEY_AVATAR, "") ?: "",
            defaultPurchaseDiscount = parsedDisc
        )
    }

    companion object {
        private const val KEY_THEME_MODE = "pref_theme_mode"
        private const val KEY_ANIMATIONS = "pref_animations_enabled"
        private const val KEY_SUBTRACT_USAGE_COST = "pref_subtract_usage_cost"
        private const val KEY_BIZ_NAME = "pref_biz_name"
        private const val KEY_OWNER_NAME = "pref_owner_name"
        private const val KEY_PHONE = "pref_phone"
        private const val KEY_EMAIL = "pref_email"
        private const val KEY_TAGLINE = "pref_tagline"
        private const val KEY_AVATAR = "pref_avatar"
        private const val KEY_DEFAULT_PURCHASE_DISCOUNT = "pref_default_purchase_discount"
        private const val KEY_CUSTOM_PRIMARY = "pref_custom_primary"
        private const val KEY_CUSTOM_SECONDARY = "pref_custom_secondary"
        private const val KEY_CUSTOM_BG = "pref_custom_bg"
        private const val KEY_CUSTOM_SURFACE = "pref_custom_surface"
        private const val KEY_CUSTOM_TEXT = "pref_custom_text"
        private const val KEY_CUSTOM_ACCENT = "pref_custom_accent"
        private const val KEY_CUSTOM_IS_DARK = "pref_custom_is_dark"

        @Volatile
        private var INSTANCE: AppSettingsManager? = null

        fun getInstance(context: Context): AppSettingsManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AppSettingsManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
