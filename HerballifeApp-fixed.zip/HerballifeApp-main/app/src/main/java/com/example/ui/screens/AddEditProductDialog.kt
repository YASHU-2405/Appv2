package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.preferences.AppSettingsManager
import com.example.ui.components.GstTypeSelector
import com.example.ui.theme.ForestGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    initialProduct: Product? = null,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    val context = LocalContext.current
    val appSettings = remember { AppSettingsManager.getInstance(context) }
    val userProfile by appSettings.userProfile.collectAsState()
    val defaultProfileDiscount = userProfile.defaultPurchaseDiscount

    var name by remember { mutableStateOf(initialProduct?.name ?: "") }
    var sku by remember { mutableStateOf(initialProduct?.sku ?: "") }
    var variant by remember { mutableStateOf(initialProduct?.variant ?: "") }

    var mrpStr by remember { mutableStateOf(initialProduct?.mrp?.takeIf { it > 0 }?.toString() ?: "") }
    var purchasePriceStr by remember { mutableStateOf(initialProduct?.purchasePrice?.takeIf { it > 0 }?.toString() ?: "") }
    var discountPercentStr by remember {
        val initialDisc = initialProduct?.discountPercentage?.takeIf { it > 0 } ?: if (initialProduct == null) defaultProfileDiscount else 0.0
        mutableStateOf(if (initialDisc % 1.0 == 0.0) "%.0f".format(initialDisc) else "%.2f".format(initialDisc))
    }
    var gstType by remember { mutableStateOf(initialProduct?.gstType ?: "PERCENTAGE") }
    var taxPercentStr by remember { mutableStateOf(initialProduct?.taxPercentage?.takeIf { it > 0 }?.toString() ?: "18") }
    var gstFixedAmountStr by remember { mutableStateOf(initialProduct?.gstFixedAmount?.takeIf { it > 0 }?.toString() ?: "0") }

    var sellingPriceStr by remember { mutableStateOf(initialProduct?.sellingPrice?.takeIf { it > 0 }?.toString() ?: "") }
    var sellingDiscountStr by remember { mutableStateOf(initialProduct?.sellingDiscountPercentage?.takeIf { it > 0 }?.toString() ?: "0") }
    var pointsStr by remember { mutableStateOf(initialProduct?.points?.takeIf { it > 0 }?.toString() ?: "0") }

    var currentStockStr by remember { mutableStateOf(initialProduct?.currentStock?.toString() ?: "0") }
    var minStockAlertStr by remember { mutableStateOf(initialProduct?.minStockAlert?.toString() ?: "5") }
    var notes by remember { mutableStateOf(initialProduct?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Automatic deterministic calculation for Purchase Cost:
    // Base Price - Discount + GST (Percentage or Fixed) = Final Purchase Cost
    val origPrice = (purchasePriceStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val discPercent = (discountPercentStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
    val taxPercent = (taxPercentStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val gstFixedAmt = (gstFixedAmountStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    val discAmt = origPrice * (discPercent / 100.0)
    val priceAfterDisc = (origPrice - discAmt).coerceAtLeast(0.0)
    val taxAmt = if (gstType == "FIXED_AMOUNT") {
        gstFixedAmt
    } else {
        priceAfterDisc * (taxPercent / 100.0)
    }
    val calculatedFinalPurchaseCost = (priceAfterDisc + taxAmt).coerceAtLeast(0.0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                if (initialProduct == null) "Add New Product" else "Edit Product",
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(
                        tonalElevation = 3.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier.testTag("cancel_product_button")
                            ) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    if (name.isBlank()) {
                                        errorMessage = "Product name is required"
                                        return@Button
                                    }
                                    val mrp = mrpStr.toDoubleOrNull() ?: 0.0
                                    val sellingPrice = sellingPriceStr.toDoubleOrNull() ?: 0.0
                                    val points = pointsStr.toDoubleOrNull() ?: 0.0
                                    val stock = currentStockStr.toIntOrNull() ?: 0
                                    val minAlert = minStockAlertStr.toIntOrNull() ?: 5
                                    val sellingDisc = sellingDiscountStr.toDoubleOrNull() ?: 0.0

                                    val product = Product(
                                        id = initialProduct?.id ?: 0,
                                        name = name.trim(),
                                        sku = sku.trim(),
                                        variant = variant.trim(),
                                        mrp = mrp,
                                        purchasePrice = origPrice,
                                        discountPercentage = discPercent,
                                        gstType = gstType,
                                        taxPercentage = if (gstType == "PERCENTAGE") taxPercent else 0.0,
                                        gstFixedAmount = if (gstType == "FIXED_AMOUNT") gstFixedAmt else 0.0,
                                        taxAmount = taxAmt,
                                        finalPurchaseCost = calculatedFinalPurchaseCost,
                                        sellingPrice = sellingPrice,
                                        sellingDiscountPercentage = sellingDisc,
                                        points = points,
                                        currentStock = stock,
                                        minStockAlert = minAlert,
                                        notes = notes.trim(),
                                        createdAt = initialProduct?.createdAt ?: System.currentTimeMillis()
                                    )
                                    onSave(product)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_product_button")
                            ) {
                                Text("Save Product")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(6.dp))

                    errorMessage?.let { msg ->
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // Basic Info
                    Text("Basic Information", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; errorMessage = null },
                        label = { Text("Product Name *") },
                        placeholder = { Text("e.g. Formula 1 Shake") },
                        modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = sku,
                            onValueChange = { sku = it },
                            label = { Text("SKU / Code") },
                            placeholder = { Text("e.g. F1-500G") },
                            modifier = Modifier.weight(1f).testTag("product_sku_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = variant,
                            onValueChange = { variant = it },
                            label = { Text("Variant / Size") },
                            placeholder = { Text("e.g. 500g Vanilla") },
                            modifier = Modifier.weight(1f).testTag("product_variant_input"),
                            singleLine = true
                        )
                    }

                    // Pricing & Purchasing
                    Text("Purchase & Costing", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = mrpStr,
                            onValueChange = { mrpStr = it },
                            label = { Text("MRP (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("product_mrp_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = purchasePriceStr,
                            onValueChange = { purchasePriceStr = it },
                            label = { Text("Base Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("product_purchase_price_input"),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = discountPercentStr,
                        onValueChange = { discountPercentStr = it },
                        label = { Text("Discount Recd (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("product_discount_input"),
                        singleLine = true
                    )

                    // GST Type Selector: Percentage (%) vs Fixed Amount (₹)
                    GstTypeSelector(
                        selectedType = gstType,
                        onTypeSelected = { gstType = it }
                    )

                    if (gstType == "PERCENTAGE") {
                        OutlinedTextField(
                            value = taxPercentStr,
                            onValueChange = { taxPercentStr = it },
                            label = { Text("GST Percentage (%) *") },
                            placeholder = { Text("e.g. 18") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("product_tax_input"),
                            singleLine = true
                        )
                    } else {
                        OutlinedTextField(
                            value = gstFixedAmountStr,
                            onValueChange = { gstFixedAmountStr = it },
                            label = { Text("GST Amount (₹) *") },
                            placeholder = { Text("e.g. 100") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("product_gst_fixed_input"),
                            singleLine = true
                        )
                    }

                    // Calculation Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Automatic Cost Calculation:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            val gstSummary = if (gstType == "FIXED_AMOUNT") {
                                "GST Fixed (₹%.2f)".format(taxAmt)
                            } else {
                                "GST %.1f%% (₹%.2f)".format(taxPercent, taxAmt)
                            }
                            Text(
                                "Base (₹%.2f) - Disc (₹%.2f) + %s".format(origPrice, discAmt, gstSummary),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                "= Final Purchase Cost: ₹%.2f per unit".format(calculatedFinalPurchaseCost),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenPrimary
                            )
                        }
                    }

                    // Selling & Points
                    Text("Selling Price & Points", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = sellingPriceStr,
                            onValueChange = { sellingPriceStr = it },
                            label = { Text("Selling Price (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("product_selling_price_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = pointsStr,
                            onValueChange = { pointsStr = it },
                            label = { Text("Volume Points") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("product_points_input"),
                            singleLine = true
                        )
                    }

                    // Stock Settings
                    Text("Inventory & Alert", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = currentStockStr,
                            onValueChange = { currentStockStr = it },
                            label = { Text("Current Stock") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("product_stock_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = minStockAlertStr,
                            onValueChange = { minStockAlertStr = it },
                            label = { Text("Min Stock Alert") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("product_min_alert_input"),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Description") },
                        modifier = Modifier.fillMaxWidth().testTag("product_notes_input"),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
