package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_usages")
data class ProductUsage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitCost: Double = 0.0,
    val totalCost: Double = 0.0,
    val usageDate: Long = System.currentTimeMillis(),
    val notes: String = "",
    val receiptImageUri: String? = null
) {
    val unitPurchaseCost: Double get() = unitCost
    val purpose: String get() = notes
}
