package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY saleDate DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales ORDER BY saleDate DESC")
    suspend fun getAllSalesList(): List<Sale>

    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun getSaleById(id: Long): Sale?

    @Query("SELECT * FROM sales WHERE productId = :productId ORDER BY saleDate DESC")
    fun getSalesForProduct(productId: Long): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE productId = :productId ORDER BY saleDate DESC")
    suspend fun getSalesForProductList(productId: Long): List<Sale>

    @Query("SELECT * FROM sales WHERE saleDate >= :start AND saleDate <= :end ORDER BY saleDate DESC")
    fun getSalesInRange(start: Long, end: Long): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE saleDate >= :start AND saleDate <= :end ORDER BY saleDate DESC")
    suspend fun getSalesInRangeList(start: Long, end: Long): List<Sale>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sale: Sale): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sales: List<Sale>): List<Long>

    @Update
    suspend fun update(sale: Sale)

    @Delete
    suspend fun delete(sale: Sale)

    @Query("DELETE FROM sales")
    suspend fun deleteAll()
}
