package com.example.data.ai

import android.graphics.Bitmap
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.Sale
import com.example.data.preferences.AppSettingsManager
import com.example.data.repository.NutritionRepository
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class NaturalLanguageProcessor(
    private val repository: NutritionRepository,
    private val settingsManager: AppSettingsManager? = null
) {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    suspend fun processUserCommand(
        input: String,
        onSearchingWeb: (Boolean) -> Unit = {}
    ): AiAssistantResponse {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return AiAssistantResponse.TextMessage("Kripya koi sawal ya command likhein ya bolein. (Please enter a question or command.)")
        }

        // Check for immediate navigation commands (read-only, no confirmation needed)
        val navDest = detectNavigationCommand(trimmed)
        if (navDest != null) {
            return AiAssistantResponse.Navigate(navDest)
        }

        val products = repository.getAllProductsList()
        val sales = repository.getAllSalesList()
        val purchases = repository.getAllPurchasesList()

        // Check if query is for Web Research / Herbalife product info / official prices / ingredients / label instructions
        val isExplicitDataAction = isDirectTransactionCommand(trimmed)
        if (!isExplicitDataAction && WebResearchService.isWebResearchQuery(trimmed)) {
            onSearchingWeb(true)
            try {
                val researchResult = WebResearchService.performWebResearch(trimmed, products)
                return AiAssistantResponse.TextMessage(
                    message = researchResult.formattedText,
                    citations = researchResult.citations,
                    isWebResearched = true,
                    suggestedCatalogAction = researchResult.suggestedCatalogAction
                )
            } finally {
                onSearchingWeb(false)
            }
        }

        // 1. Try Gemini AI if API key is configured
        if (GeminiClient.isConfigured()) {
            val geminiResult = tryGeminiProcessing(trimmed, products, sales, purchases)
            if (geminiResult != null) {
                return geminiResult
            }
        }

        // 2. Intelligent local natural language processor (works offline 100% reliably)
        return processLocally(trimmed, products, sales, purchases)
    }

    private fun isDirectTransactionCommand(input: String): Boolean {
        val lower = input.lowercase()
        val actionKeywords = listOf(
            "record sale", "add sale", "sold", "becha", "bikri",
            "record purchase", "add purchase", "stock in", "purchased", "khareeda",
            "delete product", "delete sale", "delete purchase", "remove item", "hatao"
        )
        return actionKeywords.any { lower.contains(it) }
    }

    suspend fun processUserCommandWithImage(input: String, bitmap: Bitmap): AiAssistantResponse {
        val products = repository.getAllProductsList()

        if (GeminiClient.isConfigured()) {
            val systemPrompt = """
                You are an expert AI Receipt / Invoice Scanner for "Onest Nutrition Manager".
                Analyze the provided receipt, bill, or product-order image.

                Current Products in catalog:
                ${products.joinToString(", ") { "${it.name} (SKU: ${it.sku})" }}

                Extract ONLY information that is clearly visible:
                - Product Name
                - Product SKU
                - Quantity
                - MRP
                - Original purchase price
                - Discount percentage & amount
                - Tax / GST percentage & amount
                - Final price per unit
                - Total amount
                - Invoice / order number
                - Date
                - Supplier/store

                STRICT ACCURACY RULES:
                - Preserve visible product names, SKU text, punctuation, symbols and Unicode/emoji exactly.
                - NEVER invent, estimate, assume, or fill a missing value.
                - If a value is not clearly visible, return JSON null for that value and set needsReview=true.
                - NEVER assume GST/tax is 18%. If tax is not printed, return null.
                - NEVER calculate a missing price, discount, tax, quantity, invoice number, or date from typical/default values.
                - Match a catalog item by SKU first, then by a clear exact product-name match. Do not force a fuzzy match.
                - If the image is unreadable, return an empty items array rather than inventing data.

                Respond ONLY with valid JSON. Unknown values MUST be null:
                {
                  "type": "RECEIPT_REVIEW",
                  "invoiceNumber": "<string or null>",
                  "orderDate": "<string or null>",
                  "store": "<string or null>",
                  "overallNeedsReview": <true/false>,
                  "items": [
                    {
                      "productName": "<string>",
                      "sku": "<string or null>",
                      "quantity": <number or null>,
                      "mrp": <number or null>,
                      "originalPrice": <number or null>,
                      "discountPercentage": <number or null>,
                      "discountAmount": <number or null>,
                      "taxPercentage": <number or null>,
                      "taxAmount": <number or null>,
                      "finalPrice": <number or null>,
                      "totalAmount": <number or null>,
                      "needsReview": <true/false>
                    }
                  ]
                }
            """.trimIndent()


            val promptText = if (input.isNotBlank()) input else "Please extract all purchased items, pricing, tax, discounts, and invoice details from this receipt."
            val responseText = GeminiClient.generateMultimodalContent(systemPrompt, promptText, bitmap).getOrNull()
            if (responseText != null) {
                val parsed = parseReceiptJsonResponse(responseText, products)
                if (parsed != null) return parsed
            }
        }

        // Offline / Fallback Receipt Draft
        return createFallbackReceiptReview(input, products)
    }

    private fun extractJsonBlock(raw: String): String {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start != -1 && end > start) {
            raw.substring(start, end + 1).trim()
        } else {
            raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        }
    }

    private fun parseReceiptJsonResponse(raw: String, products: List<Product>): AiAssistantResponse? {
        return try {
            val clean = extractJsonBlock(raw)
            val json = JSONObject(clean)
            if (json.optString("type") != "RECEIPT_REVIEW") return null

            val itemsArr = json.optJSONArray("items") ?: JSONArray()
            val draftItems = mutableListOf<DraftPurchaseItem>()

            for (i in 0 until itemsArr.length()) {
                val obj = itemsArr.optJSONObject(i) ?: continue

                val pName = obj.optString("productName", "").trim()
                if (pName.isBlank()) continue

                fun numberOrNull(key: String): Double? {
                    if (!obj.has(key) || obj.isNull(key)) return null
                    return obj.optDouble(key, Double.NaN).takeIf { !it.isNaN() }
                }

                fun intOrNull(key: String): Int? {
                    if (!obj.has(key) || obj.isNull(key)) return null
                    return obj.optInt(key, -1).takeIf { it >= 0 }
                }

                val qty = intOrNull("quantity")
                val mrp = numberOrNull("mrp")
                val orig = numberOrNull("originalPrice")
                val discPercent = numberOrNull("discountPercentage")
                val discAmt = numberOrNull("discountAmount")
                val taxPercent = numberOrNull("taxPercentage")
                val taxAmt = numberOrNull("taxAmount")
                val finalPrice = numberOrNull("finalPrice")
                val total = numberOrNull("totalAmount")

                val sku = obj.optString("sku", "").trim()
                val matched = products.firstOrNull { sku.isNotBlank() && it.sku.equals(sku, ignoreCase = true) }
                    ?: products.firstOrNull {
                        it.name.equals(pName, ignoreCase = true) ||
                            (it.name.length >= 5 && pName.equals(it.name, ignoreCase = true))
                    }

                val needsReview = obj.optBoolean("needsReview", false) ||
                    qty == null || qty <= 0 ||
                    mrp == null || mrp <= 0 ||
                    orig == null || orig < 0 ||
                    discPercent == null || discPercent < 0 ||
                    discAmt == null || discAmt < 0 ||
                    taxPercent == null || taxPercent < 0 ||
                    taxAmt == null || taxAmt < 0 ||
                    finalPrice == null || finalPrice <= 0 ||
                    total == null || total <= 0 ||
                    matched == null

                draftItems.add(
                    DraftPurchaseItem(
                        productName = matched?.name ?: pName,
                        quantity = qty ?: 0,
                        mrp = mrp ?: 0.0,
                        originalPrice = orig ?: 0.0,
                        discountPercentage = discPercent ?: 0.0,
                        discountAmount = discAmt ?: 0.0,
                        taxPercentage = taxPercent ?: 0.0,
                        taxAmount = taxAmt ?: 0.0,
                        finalPricePerUnit = finalPrice ?: 0.0,
                        totalAmount = total ?: 0.0,
                        matchedProductId = matched?.id,
                        sku = if (sku.isNotBlank()) sku else (matched?.sku ?: ""),
                        needsReview = needsReview
                    )
                )
            }

            if (draftItems.isEmpty()) return null

            val invoiceNumber = json.optString("invoiceNumber", "").trim()
            val orderDate = json.optString("orderDate", "").trim()
            val store = json.optString("store", "").trim()

            val receiptDraft = ReceiptReviewDraft(
                items = draftItems,
                invoiceNumber = invoiceNumber,
                orderDateStr = orderDate,
                detectedStoreOrSupplier = store,
                overallNeedsReview = json.optBoolean("overallNeedsReview", false) ||
                    invoiceNumber.isBlank() ||
                    orderDate.isBlank() ||
                    draftItems.any { it.needsReview }
            )

            AiAssistantResponse.ConfirmReceiptReview(
                receiptDraft = receiptDraft,
                message = "🧾 Receipt read complete. Review every highlighted field before confirming. Nothing is added to stock automatically."
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun createFallbackReceiptReview(input: String, products: List<Product>): AiAssistantResponse {
        return AiAssistantResponse.TextMessage(
            "🧾 Receipt scan could not reliably extract the purchase details. " +
                "No stock was changed. Please use a clearer image or enter the values manually. " +
                "I will not invent product names, quantities, prices, GST, discounts, or totals."
        )
    }

    private fun detectNavigationCommand(input: String): NavigateAction? {
        val lower = input.lowercase().trim()
        return when {
            lower.contains("profile") || lower.contains("my account") ->
                NavigateAction("PROFILE", "Opening your Business Profile page...")
            lower.contains("usage") || lower.contains("personal use") || lower.contains("khud use") || lower.contains("consume") ->
                NavigateAction("PRODUCT_USAGE", "Navigating to Product Usage & Personal Consumption...")
            lower.contains("borrow") || lower.contains("udhar") || lower.contains("lend") || lower.contains("udhari") ->
                NavigateAction("BORROWED_PRODUCTS", "Navigating to Borrowed Products & Stock tracker...")
            lower.contains("go to product") || lower.contains("open product") || lower.contains("products dikhao") || lower == "products" ->
                NavigateAction("PRODUCTS", "Navigating to Products Catalog...")
            lower.contains("go to sale") || lower.contains("open sale") || lower.contains("sales dikhao") || lower == "sales" ->
                NavigateAction("SALES", "Navigating to Sales section...")
            lower.contains("go to purchase") || lower.contains("open purchase") || lower.contains("purchases dikhao") || lower == "purchases" || lower.contains("stock in") ->
                NavigateAction("PURCHASES", "Navigating to Stock In / Purchases...")
            lower.contains("report") || lower.contains("analytics") ->
                NavigateAction("REPORTS", "Opening Financial & Inventory Reports...")
            lower.contains("setting") ->
                NavigateAction("SETTINGS", "Opening App Settings & Backup...")
            lower.contains("history") || lower.contains("ledger") ->
                NavigateAction("HISTORY", "Opening History Ledger...")
            lower.contains("dashboard") || lower.contains("home") ->
                NavigateAction("DASHBOARD", "Navigating to Main Dashboard...")
            lower.contains("search") ->
                NavigateAction("SEARCH", "Opening Global Search...")
            else -> null
        }
    }

    private suspend fun tryGeminiProcessing(
        input: String,
        products: List<Product>,
        sales: List<Sale>,
        purchases: List<Purchase>
    ): AiAssistantResponse? {
        val productsJson = products.joinToString("\n") {
            "ID:${it.id}, Name:${it.name}, SKU:${it.sku}, Stock:${it.currentStock}, MRP:${it.mrp}, PurchaseCost:${it.finalPurchaseCost}, SellingPrice:${it.sellingPrice}, Points:${it.points}"
        }
        val recentSales = sales.take(15).joinToString("\n") {
            "Product:${it.productName}, Qty:${it.quantity}, Total:${it.totalSaleAmount}, Profit:${it.profit}, Date:${dateFormat.format(Date(it.saleDate))}"
        }

        val defaultDiscount = settingsManager?.userProfile?.value?.defaultPurchaseDiscount ?: 25.0

        val systemPrompt = """
            You are the AI Assistant for "Onest Nutrition Manager" (English, Hindi, and Hinglish).
            You have full control to query data, create products, record sales/purchases, edit products, delete data, and change settings.
            
            IMPORTANT SAFETY RULES:
            1. You must NEVER invent stock, prices, sales, purchases, tax, discounts, profit, or points. Always use the local database.
            2. For ANY data-changing action (Add, Edit, Delete, Stock update, Price change, Discount change, Tax change, Settings change), you must return a CONFIRMATION structure. Never modify data silently.
            3. Read-only queries must be answered immediately in the user's language.
            
            BUSINESS SETTINGS:
            Default Purchase Discount: $defaultDiscount% (Use this default percentage for new purchase/stock-in items unless the user specifies a different discount).
            
            DATABASE:
            PRODUCTS:
            $productsJson
            
            RECENT SALES:
            $recentSales
            
            JSON FORMATS:
            
            Format 1 (Information / Read-only Q&A):
            { "type": "MESSAGE", "text": "<helpful factual answer>" }
            
            Format 2 (New Sale Entry):
            { "type": "CONFIRM_SALE", "productId": <num>, "productName": "<str>", "quantity": <num>, "sellingPrice": <num>, "discountPercentage": <num>, "gstType": "PERCENTAGE"|"FIXED_AMOUNT", "gstPercentage": <num>, "gstFixedAmount": <num>, "customerName": "<str>", "customerContact": "<str>", "customerEmail": "<str>", "customerAddress": "<str>" }
            
            Format 3 (Purchase / Stock In):
            { "type": "CONFIRM_PURCHASE", "items": [ { "productName": "<str>", "quantity": <num>, "mrp": <num>, "originalPrice": <num>, "discountPercentage": <num>, "gstType": "PERCENTAGE"|"FIXED_AMOUNT", "gstFixedAmount": <num>, "taxPercentage": <num> } ], "invoiceNumber": "<str>" }
            
            Format 4 (Edit Product / Price / Stock / Points / Discount / Tax):
            { "type": "CONFIRM_EDIT", "productId": <num>, "productName": "<str>", "fieldName": "Selling Price"|"Stock"|"Points"|"Discount"|"Tax"|"MRP", "newValue": <num> }
            
            Format 5 (Add New Product):
            { "type": "CONFIRM_CREATE_PRODUCT", "name": "<str>", "sku": "<str>", "mrp": <num>, "purchasePrice": <num>, "sellingPrice": <num>, "points": <num>, "currentStock": <num> }
            
            Format 6 (Delete Item):
            { "type": "CONFIRM_DELETE", "targetType": "PRODUCT"|"SALE"|"PURCHASE", "id": <num>, "title": "<str>", "quantityStr": "<str>", "amountStr": "<str>" }
            
            Format 7 (Settings change):
            { "type": "CONFIRM_SETTINGS", "settingName": "Theme Mode"|"Animations", "newValue": "<str>" }
            
            Output strictly valid JSON only.
        """.trimIndent()

        val responseText = GeminiClient.generateContent(systemPrompt, input).getOrNull() ?: return null
        return parseGeminiJsonResponse(responseText, products, sales, purchases)
    }

    private fun parseGeminiJsonResponse(
        raw: String,
        products: List<Product>,
        sales: List<Sale>,
        purchases: List<Purchase>
    ): AiAssistantResponse? {
        try {
            val clean = extractJsonBlock(raw)
            val json = JSONObject(clean)

            when (json.optString("type")) {
                "MESSAGE" -> {
                    return AiAssistantResponse.TextMessage(json.optString("text", "Data fetched."))
                }
                "CONFIRM_SALE" -> {
                    val pName = json.optString("productName")
                    val pId = json.optLong("productId")
                    val matchedProduct = products.find { it.id == pId }
                        ?: products.find { it.name.equals(pName, ignoreCase = true) }
                        ?: products.find { it.name.contains(pName, ignoreCase = true) }

                    if (matchedProduct != null) {
                        val qty = json.optInt("quantity", 1).coerceAtLeast(1)
                        val price = json.optDouble("sellingPrice", matchedProduct.sellingPrice).coerceAtLeast(0.0)
                        val discPercent = json.optDouble("discountPercentage", 0.0).coerceIn(0.0, 100.0)
                        val discAmtUnit = price * (discPercent / 100.0)
                        val taxableUnit = (price - discAmtUnit).coerceAtLeast(0.0)

                        val gstType = json.optString("gstType", "PERCENTAGE").uppercase()
                        val gstFixed = json.optDouble("gstFixedAmount", 0.0).coerceAtLeast(0.0)
                        val gstPercent = json.optDouble("gstPercentage", 0.0).coerceAtLeast(0.0)

                        val unitGst = if (gstType == "FIXED_AMOUNT") gstFixed else taxableUnit * (gstPercent / 100.0)
                        val finalUnitPrice = taxableUnit + unitGst
                        val totalSale = finalUnitPrice * qty
                        val totalGst = unitGst * qty

                        val unitCost = matchedProduct.finalPurchaseCost
                        val totalCost = unitCost * qty
                        val profit = (taxableUnit * qty) - totalCost
                        val points = matchedProduct.points * qty
                        val remStock = matchedProduct.currentStock - qty

                        return AiAssistantResponse.ConfirmSale(
                            draft = DraftSaleAction(
                                productId = matchedProduct.id,
                                productName = matchedProduct.name,
                                quantity = qty,
                                sellingPrice = price,
                                discountPercentage = discPercent,
                                discountAmount = discAmtUnit * qty,
                                gstType = if (gstType == "FIXED_AMOUNT") "FIXED_AMOUNT" else "PERCENTAGE",
                                gstPercentage = if (gstType == "FIXED_AMOUNT") 0.0 else gstPercent,
                                gstFixedAmount = if (gstType == "FIXED_AMOUNT") gstFixed else 0.0,
                                gstAmount = totalGst,
                                finalSellingPrice = finalUnitPrice,
                                totalSaleAmount = totalSale,
                                unitPurchaseCost = unitCost,
                                profit = profit,
                                points = points,
                                remainingStock = remStock,
                                customerName = json.optString("customerName").takeIf { it.isNotBlank() },
                                customerContact = json.optString("customerContact").takeIf { it.isNotBlank() },
                                customerEmail = json.optString("customerEmail").takeIf { it.isNotBlank() },
                                customerAddress = json.optString("customerAddress").takeIf { it.isNotBlank() }
                            ),
                            message = "ACTION: Add Sale. Please review and confirm:"
                        )
                    } else {
                        return AiAssistantResponse.TextMessage(
                            "⚠️ Needs Review: Could not find product \"${pName.ifBlank { "requested item" }}\" in your current catalog. Please check the product name or add it to your products list first."
                        )
                    }
                }
                "CONFIRM_PURCHASE" -> {
                    val itemsArr = json.optJSONArray("items")
                    if (itemsArr != null && itemsArr.length() > 0) {
                        val draftItems = mutableListOf<DraftPurchaseItem>()
                        for (i in 0 until itemsArr.length()) {
                            val itemObj = itemsArr.getJSONObject(i)
                            val name = itemObj.optString("productName", "Unknown Product")
                            val qty = itemObj.optInt("quantity", 1)
                            val mrp = itemObj.optDouble("mrp", 0.0)
                            val orig = itemObj.optDouble("originalPrice", mrp)
                            val defaultDisc = settingsManager?.userProfile?.value?.defaultPurchaseDiscount ?: 25.0
                            val discPercent = itemObj.optDouble("discountPercentage", defaultDisc)
                            val gstType = itemObj.optString("gstType", "PERCENTAGE").uppercase()
                            val gstFixed = itemObj.optDouble("gstFixedAmount", 0.0)
                            val taxPercent = itemObj.optDouble("taxPercentage", 18.0)

                            val discAmt = orig * (discPercent / 100.0)
                            val afterDisc = orig - discAmt
                            val taxAmt = if (gstType == "FIXED_AMOUNT") gstFixed else afterDisc * (taxPercent / 100.0)
                            val finalUnit = afterDisc + taxAmt
                            val totalAmt = finalUnit * qty

                            val matched = products.find { it.name.contains(name, ignoreCase = true) }

                            draftItems.add(
                                DraftPurchaseItem(
                                    productName = name,
                                    quantity = qty,
                                    mrp = mrp,
                                    originalPrice = orig,
                                    discountPercentage = discPercent,
                                    discountAmount = discAmt,
                                    gstType = if (gstType == "FIXED_AMOUNT") "FIXED_AMOUNT" else "PERCENTAGE",
                                    gstFixedAmount = gstFixed,
                                    taxPercentage = if (gstType == "FIXED_AMOUNT") 0.0 else taxPercent,
                                    taxAmount = taxAmt,
                                    finalPricePerUnit = finalUnit,
                                    totalAmount = totalAmt,
                                    matchedProductId = matched?.id
                                )
                            )
                        }
                        return AiAssistantResponse.ConfirmPurchase(
                            draft = DraftPurchaseAction(
                                items = draftItems,
                                invoiceNumber = json.optString("invoiceNumber", "INV-${System.currentTimeMillis() % 10000}")
                            ),
                            message = "ACTION: Add Purchase. Please review and confirm:"
                        )
                    }
                }
                "CONFIRM_EDIT" -> {
                    val pName = json.optString("productName")
                    val pId = json.optLong("productId")
                    val matched = products.find { it.id == pId } ?: products.find { it.name.contains(pName, ignoreCase = true) }
                    if (matched != null) {
                        val field = json.optString("fieldName", "Selling Price")
                        val newVal = json.optDouble("newValue", 0.0)
                        val oldVal = when (field) {
                            "Stock" -> "${matched.currentStock} units"
                            "Points" -> "${matched.points} pts"
                            "Discount" -> "${matched.discountPercentage}%"
                            "Tax" -> "${matched.taxPercentage}%"
                            "MRP" -> "₹${matched.mrp}"
                            else -> "₹${matched.sellingPrice}"
                        }
                        return AiAssistantResponse.ConfirmEdit(
                            draft = DraftEditProductAction(
                                productId = matched.id,
                                productName = matched.name,
                                fieldName = field,
                                oldValue = oldVal,
                                newValue = if (field == "Stock") "${newVal.toInt()} units" else if (field.contains("Point")) "$newVal pts" else if (field.contains("Disc") || field.contains("Tax")) "$newVal%" else "₹$newVal",
                                newSellingPrice = if (field.contains("Price", ignoreCase = true)) newVal else null,
                                newStock = if (field.contains("Stock", ignoreCase = true)) newVal.toInt() else null,
                                newPoints = if (field.contains("Point", ignoreCase = true)) newVal else null,
                                newDiscount = if (field.contains("Disc", ignoreCase = true)) newVal else null,
                                newTax = if (field.contains("Tax", ignoreCase = true)) newVal else null,
                                newMrp = if (field.contains("MRP", ignoreCase = true)) newVal else null
                            ),
                            message = "ACTION: Edit Product (${matched.name}). Please review changes:"
                        )
                    } else {
                        return AiAssistantResponse.TextMessage(
                            "⚠️ Needs Review: Could not find product \"${pName.ifBlank { "specified item" }}\" in your catalog to edit."
                        )
                    }
                }
                "CONFIRM_CREATE_PRODUCT" -> {
                    val name = json.optString("name", "New Nutrition Product")
                    val mrp = json.optDouble("mrp", 1000.0)
                    val purchasePrice = json.optDouble("purchasePrice", mrp * 0.75)
                    val sellingPrice = json.optDouble("sellingPrice", mrp * 0.9)
                    val points = json.optDouble("points", 1.0)
                    val stock = json.optInt("currentStock", 0)

                    return AiAssistantResponse.ConfirmCreateProduct(
                        draft = DraftCreateProductAction(
                            name = name,
                            sku = json.optString("sku", "SKU-${System.currentTimeMillis() % 1000}"),
                            mrp = mrp,
                            purchasePrice = purchasePrice,
                            finalPurchaseCost = purchasePrice,
                            sellingPrice = sellingPrice,
                            points = points,
                            currentStock = stock
                        ),
                        message = "ACTION: Add New Product to Catalog. Please review and confirm:"
                    )
                }
                "CONFIRM_DELETE" -> {
                    val targetType = json.optString("targetType", "PRODUCT")
                    val id = json.optLong("id", 0L)
                    if (id <= 0L) {
                        return AiAssistantResponse.TextMessage("⚠️ Cannot delete: Invalid or unspecified record ID.")
                    }
                    val title = json.optString("title", "Item #$id")
                    return AiAssistantResponse.ConfirmDelete(
                        draft = DraftDeleteAction(
                            targetType = targetType,
                            id = id,
                            title = title,
                            dateStr = dateFormat.format(Date()),
                            quantityStr = json.optString("quantityStr", "-"),
                            amountStr = json.optString("amountStr", "-")
                        ),
                        message = "ACTION: Delete $targetType. This will remove records and update inventory. Please confirm:"
                    )
                }
                "CONFIRM_SETTINGS" -> {
                    val setting = json.optString("settingName", "Theme Mode")
                    val newVal = json.optString("newValue", "DARK")
                    return AiAssistantResponse.ConfirmSettingsChange(
                        draft = DraftUpdateSettingsAction(
                            settingName = setting,
                            oldValue = "Current",
                            newValue = newVal,
                            newThemeMode = if (setting.contains("Theme", ignoreCase = true)) newVal else null,
                            newAnimationsEnabled = if (setting.contains("Anim", ignoreCase = true)) newVal.equals("true", true) || newVal.equals("on", true) else null
                        ),
                        message = "ACTION: Change App Settings. Please confirm:"
                    )
                }
            }
        } catch (_: Exception) {
            // fallback
        }
        return null
    }

    private fun processLocally(
        input: String,
        products: List<Product>,
        sales: List<Sale>,
        purchases: List<Purchase>
    ): AiAssistantResponse {
        val lower = input.lowercase()

        // 1. Delete request
        if (lower.contains("delete") || lower.contains("hata do") || lower.contains("remove")) {
            if (lower.contains("sale") && sales.isNotEmpty()) {
                val matchedProduct = products.find { lower.contains(it.name.lowercase()) }
                val targetSale = if (matchedProduct != null) {
                    sales.firstOrNull { it.productId == matchedProduct.id } ?: sales.first()
                } else {
                    sales.first()
                }
                return AiAssistantResponse.ConfirmDelete(
                    draft = DraftDeleteAction(
                        targetType = "SALE",
                        id = targetSale.id,
                        title = "Sale #${targetSale.id} - ${targetSale.productName}",
                        dateStr = dateFormat.format(Date(targetSale.saleDate)),
                        quantityStr = "${targetSale.quantity} units sold",
                        amountStr = "₹%.2f".format(targetSale.totalSaleAmount)
                    ),
                    message = "ACTION: Delete Sale record. Warning: Stock will be restored (+${targetSale.quantity}). Please confirm:"
                )
            } else if ((lower.contains("purchase") || lower.contains("invoice") || lower.contains("bill")) && purchases.isNotEmpty()) {
                val matchedProduct = products.find { lower.contains(it.name.lowercase()) }
                val targetPurchase = if (matchedProduct != null) {
                    purchases.firstOrNull { it.productId == matchedProduct.id } ?: purchases.first()
                } else {
                    purchases.first()
                }
                return AiAssistantResponse.ConfirmDelete(
                    draft = DraftDeleteAction(
                        targetType = "PURCHASE",
                        id = targetPurchase.id,
                        title = "Purchase #${targetPurchase.id} - ${targetPurchase.productName}",
                        dateStr = dateFormat.format(Date(targetPurchase.purchaseDate)),
                        quantityStr = "${targetPurchase.quantity} units purchased",
                        amountStr = "₹%.2f".format(targetPurchase.totalAmount)
                    ),
                    message = "ACTION: Delete Purchase record. Warning: Stock will be reduced (-${targetPurchase.quantity}). Please confirm:"
                )
            }

            val matchedProduct = products.find { lower.contains(it.name.lowercase()) }
            if (matchedProduct != null) {
                return AiAssistantResponse.ConfirmDelete(
                    draft = DraftDeleteAction(
                        targetType = "PRODUCT",
                        id = matchedProduct.id,
                        title = matchedProduct.name,
                        dateStr = dateFormat.format(Date()),
                        quantityStr = "${matchedProduct.currentStock} in stock",
                        amountStr = "MRP ₹${matchedProduct.mrp}"
                    ),
                    message = "ACTION: Delete Product. Warning: This permanently removes ${matchedProduct.name} from catalog. Please confirm:"
                )
            }
        }

        // 2. Settings change request
        if (lower.contains("dark mode") || lower.contains("light mode") || lower.contains("theme")) {
            val targetMode = if (lower.contains("light")) "LIGHT" else if (lower.contains("system")) "SYSTEM" else "DARK"
            return AiAssistantResponse.ConfirmSettingsChange(
                draft = DraftUpdateSettingsAction(
                    settingName = "Theme Mode",
                    oldValue = "Current Mode",
                    newValue = targetMode,
                    newThemeMode = targetMode
                ),
                message = "ACTION: Change App Theme to $targetMode. Please confirm:"
            )
        }
        if (lower.contains("animation") || lower.contains("animations")) {
            val enable = lower.contains("on") || lower.contains("enable") || lower.contains("chalu")
            return AiAssistantResponse.ConfirmSettingsChange(
                draft = DraftUpdateSettingsAction(
                    settingName = "Animations",
                    oldValue = if (enable) "OFF" else "ON",
                    newValue = if (enable) "ON" else "OFF",
                    newAnimationsEnabled = enable
                ),
                message = "ACTION: Toggle Animations to ${if (enable) "ON" else "OFF"}. Please confirm:"
            )
        }

        // 3. Edit request (Price, Stock, Points, Discount, Tax)
        if (lower.contains("kar do") || lower.contains("set") || lower.contains("change") || lower.contains("update") || lower.contains("badal")) {
            val matched = products.find { lower.contains(it.name.lowercase()) }
            if (matched != null) {
                val number = Regex("\\d+(\\.\\d+)?").find(lower)?.value?.toDoubleOrNull()
                if (number != null) {
                    val field = when {
                        lower.contains("selling price") || lower.contains("price") || lower.contains("rate") || lower.contains("bhav") -> "Selling Price"
                        lower.contains("stock") -> "Stock"
                        lower.contains("point") -> "Points"
                        lower.contains("discount") -> "Discount"
                        lower.contains("tax") || lower.contains("gst") -> "Tax"
                        lower.contains("mrp") -> "MRP"
                        else -> "Selling Price"
                    }
                    val oldVal = when (field) {
                        "Stock" -> "${matched.currentStock} units"
                        "Points" -> "${matched.points} pts"
                        "Discount" -> "${matched.discountPercentage}%"
                        "Tax" -> "${matched.taxPercentage}%"
                        "MRP" -> "₹${matched.mrp}"
                        else -> "₹${matched.sellingPrice}"
                    }
                    val newValStr = when (field) {
                        "Stock" -> "${number.toInt()} units"
                        "Points" -> "$number pts"
                        "Discount", "Tax" -> "$number%"
                        else -> "₹$number"
                    }
                    return AiAssistantResponse.ConfirmEdit(
                        draft = DraftEditProductAction(
                            productId = matched.id,
                            productName = matched.name,
                            fieldName = field,
                            oldValue = oldVal,
                            newValue = newValStr,
                            newSellingPrice = if (field == "Selling Price") number else null,
                            newStock = if (field == "Stock") number.toInt() else null,
                            newPoints = if (field == "Points") number else null,
                            newDiscount = if (field == "Discount") number else null,
                            newTax = if (field == "Tax") number else null,
                            newMrp = if (field == "MRP") number else null
                        ),
                        message = "ACTION: Edit Product (${matched.name}). Please review changes:"
                    )
                }
            }
        }

        // 4. Add new product request
        if (lower.contains("add product") || lower.contains("new product") || lower.contains("naya product")) {
            val cleanName = input.replace(Regex("(?i)(add product|new product|naya product)"), "").trim()
            val finalName = if (cleanName.isNotBlank()) cleanName else "New Protein Shake"
            return AiAssistantResponse.ConfirmCreateProduct(
                draft = DraftCreateProductAction(
                    name = finalName,
                    sku = "SKU-${System.currentTimeMillis() % 1000}",
                    mrp = 2000.0,
                    purchasePrice = 1500.0,
                    finalPurchaseCost = 1500.0,
                    sellingPrice = 1850.0,
                    points = 1.0,
                    currentStock = 0
                ),
                message = "ACTION: Add New Product ($finalName). Please review and confirm:"
            )
        }

        // 5. Sale entry request (with customer details)
        val saleConfirm = tryParseSaleCommandLocally(input, products)
        if (saleConfirm != null) return saleConfirm

        // 5b. Purchase / Stock In request (with GST support)
        val purchaseConfirm = tryParsePurchaseCommandLocally(input, products)
        if (purchaseConfirm != null) return purchaseConfirm

        // 6. Read-Only Questions (Stock, Profit, Sales, Points, Pricing)
        // Stock inquiries
        if (lower.contains("stock") || lower.contains("kitna hai") || lower.contains("bache")) {
            val matched = products.find { lower.contains(it.name.lowercase()) }
            if (matched != null) {
                return AiAssistantResponse.TextMessage(
                    "📦 ${matched.name}:\n• Current Stock: ${matched.currentStock} units\n• Selling Price: ₹%.2f\n• Purchase Cost: ₹%.2f\n• Points: %.2f pts".format(
                        matched.sellingPrice,
                        matched.finalPurchaseCost,
                        matched.points
                    )
                )
            } else {
                val totalStock = products.sumOf { it.currentStock }
                val summary = products.take(5).joinToString("\n") { "• ${it.name}: ${it.currentStock} units" }
                return AiAssistantResponse.TextMessage(
                    "📊 Total Inventory Stock: $totalStock units across ${products.size} products.\n\nQuick Overview:\n$summary"
                )
            }
        }

        // Profit inquiries
        if (lower.contains("profit") || lower.contains("munafa") || lower.contains("kamai")) {
            val cal = Calendar.getInstance()
            val currentMonth = cal.get(Calendar.MONTH)
            val currentYear = cal.get(Calendar.YEAR)

            val monthSales = sales.filter {
                val sCal = Calendar.getInstance().apply { timeInMillis = it.saleDate }
                sCal.get(Calendar.MONTH) == currentMonth && sCal.get(Calendar.YEAR) == currentYear
            }
            fun realizedProfit(sale: Sale): Double {
                val total = sale.totalSaleAmount
                if (total <= 0.001 || sale.profit == 0.0) return 0.0
                val received = sale.amountReceived.coerceIn(0.0, total)
                return (sale.profit * (received / total)).coerceIn(
                    minOf(0.0, sale.profit),
                    maxOf(0.0, sale.profit)
                )
            }

            val monthProfit = monthSales.sumOf(::realizedProfit)
            val lifetimeProfit = sales.sumOf(::realizedProfit)

            return AiAssistantResponse.TextMessage(
                "💰 Realized Profit Summary (Actual Database):\n• This Month's Profit Received: ₹%.2f (%d sales)\n• Lifetime Profit Received: ₹%.2f (%d total sales)".format(
                    monthProfit,
                    monthSales.size,
                    lifetimeProfit,
                    sales.size
                )
            )
        }

        // Points inquiries
        if (lower.contains("point") || lower.contains("points")) {
            val cal = Calendar.getInstance()
            val currentMonth = cal.get(Calendar.MONTH)
            val currentYear = cal.get(Calendar.YEAR)

            val monthSales = sales.filter {
                val sCal = Calendar.getInstance().apply { timeInMillis = it.saleDate }
                sCal.get(Calendar.MONTH) == currentMonth && sCal.get(Calendar.YEAR) == currentYear
            }
            val monthPoints = monthSales.sumOf { it.totalPoints }
            val lifetimePoints = sales.sumOf { it.totalPoints }

            return AiAssistantResponse.TextMessage(
                "⭐ Volume Points Summary:\n• This Month's Points: %.2f pts\n• Lifetime Volume Points: %.2f pts".format(
                    monthPoints,
                    lifetimePoints
                )
            )
        }

        // Sales inquiries
        if (lower.contains("sale") || lower.contains("kitni sale") || lower.contains("revenue") || lower.contains("bikri")) {
            val todayStart = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            val todaySales = sales.filter { it.saleDate >= todayStart }
            val todayRevenue = todaySales.sumOf { it.totalSaleAmount }
            val todayProfit = todaySales.sumOf {
                if (it.totalSaleAmount <= 0.001) 0.0
                else it.profit * (it.amountReceived.coerceIn(0.0, it.totalSaleAmount) / it.totalSaleAmount)
            }

            val lifetimeRevenue = sales.sumOf { it.totalSaleAmount }
            val lifetimeQty = sales.sumOf { it.quantity }

            return AiAssistantResponse.TextMessage(
                "📈 Sales Statistics:\n• Today's Sales: %d orders | Revenue: ₹%.2f | Profit: ₹%.2f\n• Lifetime Sales: %d units | Total Revenue: ₹%.2f".format(
                    todaySales.size,
                    todayRevenue,
                    todayProfit,
                    lifetimeQty,
                    lifetimeRevenue
                )
            )
        }

        // Price inquiry
        if (lower.contains("kitne mein pada") || lower.contains("purchase cost") || lower.contains("selling price") || lower.contains("rate")) {
            val matched = products.find { lower.contains(it.name.lowercase()) }
            if (matched != null) {
                return AiAssistantResponse.TextMessage(
                    "🏷️ ${matched.name} Pricing:\n• MRP: ₹%.2f\n• Base Cost: ₹%.2f\n• Final Purchase Cost: ₹%.2f\n• Selling Price: ₹%.2f\n• Net Margin: ₹%.2f per unit".format(
                        matched.mrp,
                        matched.purchasePrice,
                        matched.finalPurchaseCost,
                        matched.sellingPrice,
                        matched.sellingPrice - matched.finalPurchaseCost
                    )
                )
            }
        }

        // Product Usage / Personal consumption inquiry
        if (lower.contains("usage") || lower.contains("personal use") || lower.contains("consume") || lower.contains("khud use")) {
            return AiAssistantResponse.TextMessage(
                "🥤 Personal Product Usage:\nYou can track products consumed for personal use from your inventory. Volume points are preserved, and depending on your settings, costs can be accounted in net profit.\n\nOpen 'Product Usage' from the menu or dashboard to view or log new consumption."
            )
        }

        // Borrowed Stock inquiry
        if (lower.contains("borrow") || lower.contains("udhar") || lower.contains("lend") || lower.contains("lender")) {
            return AiAssistantResponse.TextMessage(
                "🤝 Borrowed Stock & Inventory Lending:\nYou can record stock borrowed from other club owners or distributors, manage partial and full returns, and track who owes what with exact transaction timestamps.\n\nOpen 'Borrowed Stock' to view pending returns or log borrowed items."
            )
        }

        return AiAssistantResponse.TextMessage(
            "Main aapke local database ko padh sakta hoon aur app ke saare features control kar sakta hoon. Aap stock, sales, profit, points, product usage, aur borrowed stock poochh sakte hain, bill scan kar sakte hain, ya sales/purchases add kar sakte hain."
        )
    }

    private fun tryParseSaleCommandLocally(
        input: String,
        products: List<Product>
    ): AiAssistantResponse.ConfirmSale? {
        val lower = input.lowercase()
        val hasSaleVerb = lower.contains("sold") || lower.contains("sell") || lower.contains("becha") ||
                lower.contains("bika") || lower.contains("sale") || lower.contains("bikri")
        if (!hasSaleVerb) return null

        // 1. Matched Product
        val matchedProduct = products.find { lower.contains(it.name.lowercase()) }
            ?: products.find { prod ->
                prod.name.lowercase().split(" ").any { word -> word.length > 3 && lower.contains(word) }
            }
            ?: products.firstOrNull()
            ?: return null

        // 2. Quantity
        val qtyMatch = Regex("(?i)\\b(?:sold|sell|sale|becha)\\s+(\\d+)\\b").find(input)
            ?: Regex("(?i)\\b(\\d+)\\s*(?:units?|pcs?|piece|pieces|dabbe|items?)\\b").find(input)
        val qty = qtyMatch?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("\\b(\\d+)\\b").find(input)?.groupValues?.get(1)?.toIntOrNull()
            ?: 1

        // 3. Customer Phone / Contact
        val phoneMatch = Regex("(?i)(?:phone|contact|mobile|ph|mob|call|cell|num|number)?\\s*[:=]?\\s*([6-9]\\d{9})").find(input)
            ?: Regex("\\b\\d{10}\\b").find(input)
        val customerContact = phoneMatch?.groupValues?.get(1) ?: phoneMatch?.value

        // 4. Customer Email
        val emailMatch = Regex("(?i)[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}").find(input)
        val customerEmail = emailMatch?.value

        // 5. Customer Address
        val addressMatch = Regex("(?i)(?:address|addr)\\s*[:=]?\\s*([^,]+?)(?:,|$|\\s+(?:for|at)\\s+\\d+)").find(input)
        val customerAddress = addressMatch?.groupValues?.get(1)?.trim()

        // 6. Customer Name
        val nameMatch = Regex("(?i)\\bto\\s+([A-Za-z\\s]+?)(?:,\\s*|\\s+phone|\\s+contact|\\s+email|\\s+address|\\s+for|\\s+at|\\s+with|$)").find(input)
            ?: Regex("(?i)\\bcustomer\\s*[:=]?\\s*([A-Za-z\\s]+?)(?:,\\s*|\\s+phone|\\s+email|$)").find(input)
        var customerName = nameMatch?.groupValues?.get(1)?.trim()
        if (customerName != null) {
            val stopWords = listOf("phone", "contact", "email", "address", "for", "at", "with", "rs", "inr")
            customerName = customerName.split(" ").filter { it.lowercase() !in stopWords }.joinToString(" ").trim()
            if (customerName.isBlank()) customerName = null
        }

        // 7. Selling Price / Total Sale
        val priceMatch = Regex("(?i)(?:for|at|rs\\.?|₹|rate|price|mein)\\s*(\\d+(\\.\\d+)?)").find(input)
        val parsedAmount = priceMatch?.groupValues?.get(1)?.toDoubleOrNull()

        // 8. Discount Percentage
        val discMatch = Regex("(?i)(?:discount|disc|chhoot)\\s*[:=]?\\s*(\\d+(\\.\\d+)?)\\s*%?").find(input)
            ?: Regex("(?i)(\\d+(\\.\\d+)?)\\s*%\\s*(?:discount|disc|off)").find(input)
        val discountPercentage = discMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

        // 9. GST / Tax details (Percentage or Fixed Amount)
        val gstFixedMatch = Regex("(?i)(?:gst|tax)\\s*[:=]?\\s*(?:rs\\.?|₹)?\\s*(\\d+(\\.\\d+)?)\\s*(?:rs|rupees|inr|flat|fixed)").find(input)
            ?: Regex("(?i)(?:rs\\.?|₹)\\s*(\\d+(\\.\\d+)?)\\s*(?:gst|tax)").find(input)
        val gstPercentMatch = Regex("(?i)(?:gst|tax)\\s*[:=]?\\s*(\\d+(\\.\\d+)?)\\s*%?").find(input)
            ?: Regex("(?i)(\\d+(\\.\\d+)?)\\s*%\\s*(?:gst|tax)").find(input)

        val gstType: String
        val gstFixedAmount: Double
        val gstPercentage: Double

        if (gstFixedMatch != null) {
            gstType = "FIXED_AMOUNT"
            gstFixedAmount = gstFixedMatch.groupValues.get(1).toDoubleOrNull() ?: 0.0
            gstPercentage = 0.0
        } else if (gstPercentMatch != null) {
            gstType = "PERCENTAGE"
            gstFixedAmount = 0.0
            gstPercentage = gstPercentMatch.groupValues.get(1).toDoubleOrNull() ?: 0.0
        } else {
            gstType = "PERCENTAGE"
            gstFixedAmount = 0.0
            gstPercentage = 0.0
        }

        val isEach = lower.contains("each") || lower.contains("per unit") || lower.contains("per piece")
        val baseUnitPrice = when {
            parsedAmount == null -> matchedProduct.sellingPrice
            isEach -> parsedAmount
            parsedAmount > matchedProduct.sellingPrice * 1.4 && qty > 1 -> parsedAmount / qty
            else -> parsedAmount
        }

        val discAmtUnit = baseUnitPrice * (discountPercentage / 100.0)
        val taxableUnit = (baseUnitPrice - discAmtUnit).coerceAtLeast(0.0)
        val unitGst = if (gstType == "FIXED_AMOUNT") gstFixedAmount else taxableUnit * (gstPercentage / 100.0)
        val finalUnitPrice = taxableUnit + unitGst
        val totalSaleAmount = finalUnitPrice * qty
        val totalGstAmount = unitGst * qty

        val unitCost = matchedProduct.finalPurchaseCost
        val totalCost = unitCost * qty
        val profit = (taxableUnit * qty) - totalCost
        val points = matchedProduct.points * qty
        val remStock = matchedProduct.currentStock - qty

        return AiAssistantResponse.ConfirmSale(
            draft = DraftSaleAction(
                productId = matchedProduct.id,
                productName = matchedProduct.name,
                quantity = qty,
                sellingPrice = baseUnitPrice,
                discountPercentage = discountPercentage,
                discountAmount = discAmtUnit * qty,
                gstType = gstType,
                gstPercentage = gstPercentage,
                gstFixedAmount = gstFixedAmount,
                gstAmount = totalGstAmount,
                finalSellingPrice = finalUnitPrice,
                totalSaleAmount = totalSaleAmount,
                unitPurchaseCost = unitCost,
                profit = profit,
                points = points,
                remainingStock = remStock,
                customerName = customerName,
                customerContact = customerContact,
                customerEmail = customerEmail,
                customerAddress = customerAddress
            ),
            message = "ACTION: Add Sale for ${matchedProduct.name}. Please review details and confirm:"
        )
    }

    private fun tryParsePurchaseCommandLocally(
        input: String,
        products: List<Product>
    ): AiAssistantResponse.ConfirmPurchase? {
        val lower = input.lowercase()
        val hasPurchaseVerb = lower.contains("bought") || lower.contains("buy") || lower.contains("purchased") ||
                lower.contains("purchase") || lower.contains("khareeda") || lower.contains("stock in")
        if (!hasPurchaseVerb) return null

        // 1. Matched Product
        val matchedProduct = products.find { lower.contains(it.name.lowercase()) }
            ?: products.find { prod ->
                prod.name.lowercase().split(" ").any { word -> word.length > 3 && lower.contains(word) }
            }

        val productName = matchedProduct?.name ?: run {
            val rawExtract = Regex("(?i)(?:bought|buy|purchased|purchase|khareeda)(?:\\s+\\d+)?\\s+(.*?)(?:\\s+at|\\s+with|\\s+for|$)").find(input)?.groupValues?.get(1)?.trim()
            if (!rawExtract.isNullOrBlank()) rawExtract else "Nutritional Supplement"
        }

        // 2. Quantity
        val qtyMatch = Regex("(?i)\\b(?:bought|buy|purchased|purchase|khareeda)\\s+(\\d+)\\b").find(input)
            ?: Regex("(?i)\\b(\\d+)\\s*(?:units?|pcs?|piece|pieces|bottles?|tubs?)\\b").find(input)
        val qty = qtyMatch?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("\\b(\\d+)\\b").find(input)?.groupValues?.get(1)?.toIntOrNull()
            ?: 1

        // 3. Original / Purchase price
        val priceMatch = Regex("(?i)(?:at|for|rs\\.?|₹|price|rate)\\s*(\\d+(\\.\\d+)?)").find(input)
        val parsedPrice = priceMatch?.groupValues?.get(1)?.toDoubleOrNull()
        val unitPrice = parsedPrice ?: matchedProduct?.purchasePrice ?: 2000.0

        // 4. GST type and value:
        // 'Bought 5 Whey Protein at 2000 each with 18% GST' -> Percentage GST: 18%
        // 'Bought 5 Whey Protein at 2000 each with 100 GST' -> Fixed Amount GST: 100
        val percentageGstMatch = Regex("(?i)(?:with|including|\\+)?\\s*(\\d+(\\.\\d+)?)\\s*%\\s*(?:gst|tax)").find(input)
            ?: Regex("(?i)(?:gst|tax)\\s*(?:of|@|:)?\\s*(\\d+(\\.\\d+)?)\\s*%").find(input)

        val fixedGstMatch = if (percentageGstMatch == null) {
            Regex("(?i)(?:with|including|\\+)?\\s*(\\d+(\\.\\d+)?)\\s*(?:rs|inr|₹)?\\s*(?:gst|tax)").find(input)
                ?: Regex("(?i)(?:gst|tax)\\s*(?:of|@|:)?\\s*(?:rs|inr|₹)?\\s*(\\d+(\\.\\d+)?)(?!%)").find(input)
        } else null

        val (gstType, gstFixed, taxPercent) = when {
            percentageGstMatch != null -> {
                val p = percentageGstMatch.groupValues[1].toDoubleOrNull() ?: 18.0
                Triple("PERCENTAGE", 0.0, p)
            }
            fixedGstMatch != null -> {
                val f = fixedGstMatch.groupValues[1].toDoubleOrNull() ?: 0.0
                Triple("FIXED_AMOUNT", f, 0.0)
            }
            matchedProduct != null -> {
                Triple(matchedProduct.gstType, matchedProduct.gstFixedAmount, matchedProduct.taxPercentage)
            }
            else -> {
                Triple("PERCENTAGE", 0.0, 18.0)
            }
        }

        // 5. Discount parsing: explicit discount in command or profile default
        val defaultProfileDiscount = settingsManager?.userProfile?.value?.defaultPurchaseDiscount ?: 25.0
        val discountMatch = Regex("(?i)(?:with|@)?\\s*(\\d+(\\.\\d+)?)\\s*%\\s*(?:disc|discount|off)").find(input)
            ?: Regex("(?i)(?:disc|discount|off)\\s*(?:of|@|:)?\\s*(\\d+(\\.\\d+)?)\\s*%").find(input)

        val discPercent = when {
            discountMatch != null -> (discountMatch.groupValues[1].toDoubleOrNull() ?: defaultProfileDiscount).coerceIn(0.0, 100.0)
            matchedProduct != null && matchedProduct.discountPercentage > 0 -> matchedProduct.discountPercentage
            else -> defaultProfileDiscount
        }

        val discAmt = unitPrice * (discPercent / 100.0)
        val afterDisc = unitPrice - discAmt
        val taxAmt = if (gstType == "FIXED_AMOUNT") gstFixed else afterDisc * (taxPercent / 100.0)
        val finalPricePerUnit = afterDisc + taxAmt
        val totalAmount = finalPricePerUnit * qty

        val draftItem = DraftPurchaseItem(
            productName = productName,
            quantity = qty,
            mrp = matchedProduct?.mrp ?: (unitPrice * 1.3),
            originalPrice = unitPrice,
            discountPercentage = discPercent,
            discountAmount = discAmt,
            gstType = gstType,
            gstFixedAmount = gstFixed,
            taxPercentage = taxPercent,
            taxAmount = taxAmt,
            finalPricePerUnit = finalPricePerUnit,
            totalAmount = totalAmount,
            matchedProductId = matchedProduct?.id
        )

        return AiAssistantResponse.ConfirmPurchase(
            draft = DraftPurchaseAction(
                items = listOf(draftItem),
                invoiceNumber = "INV-${System.currentTimeMillis() % 10000}"
            ),
            message = "ACTION: Add Purchase for $productName (Discount: %.2f%%). Please review before confirming:".format(discPercent)
        )
    }
}
