package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.AccountInfo
import com.example.data.auth.AuthManager
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ForestSecondary
import com.example.ui.theme.PointsGold
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AuthMode {
    LOGIN,
    REGISTER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    authManager: AuthManager,
    onAuthSuccess: (AccountInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    val hasExistingAccount = remember { authManager.hasAccount() }
    var currentMode by remember {
        mutableStateOf(if (hasExistingAccount) AuthMode.LOGIN else AuthMode.REGISTER)
    }

    // Form fields
    var fullName by remember { mutableStateOf("") }
    var usernameOrEmail by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(authManager.isRememberMeEnabled()) }

    // Security Question for Registration
    val defaultSecurityQuestions = listOf(
        "What is your primary store/business name?",
        "What is your favorite nutrition product?",
        "What is your birth city?",
        "What is your first vehicle or pet name?"
    )
    var selectedSecurityQuestion by remember { mutableStateOf(defaultSecurityQuestions[0]) }
    var securityAnswer by remember { mutableStateOf("") }
    var showQuestionDropdown by remember { mutableStateOf(false) }

    // State feedback
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Forgot Password dialog state
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    // Floating background animation
    val infiniteTransition = rememberInfiniteTransition(label = "background_orb_transition")
    val orbOffset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb1"
    )
    val orbOffset2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -35f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb2"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Animated Canvas Backdrop with Glowing Ambient Orbs
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Top-right glowing green orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ForestGreenPrimary.copy(alpha = 0.18f),
                        ForestGreenPrimary.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = Offset(canvasWidth * 0.85f, canvasHeight * 0.15f + orbOffset1),
                    radius = canvasWidth * 0.6f
                ),
                center = Offset(canvasWidth * 0.85f, canvasHeight * 0.15f + orbOffset1),
                radius = canvasWidth * 0.6f
            )

            // Bottom-left glowing golden/emerald orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        PointsGold.copy(alpha = 0.12f),
                        ForestSecondary.copy(alpha = 0.04f),
                        Color.Transparent
                    ),
                    center = Offset(canvasWidth * 0.15f, canvasHeight * 0.82f + orbOffset2),
                    radius = canvasWidth * 0.65f
                ),
                center = Offset(canvasWidth * 0.15f, canvasHeight * 0.82f + orbOffset2),
                radius = canvasWidth * 0.65f
            )

            // Subtle curved line
            drawCircle(
                color = ForestGreenPrimary.copy(alpha = 0.05f),
                center = Offset(canvasWidth * 0.5f, canvasHeight * 0.3f),
                radius = canvasWidth * 0.45f,
                style = Stroke(width = 2f)
            )
        }

        // Foreground Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Brand Header with Glowing Shield/Leaf Badge
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
                    .shadow(elevation = 8.dp, shape = CircleShape)
                    .border(3.dp, MaterialTheme.colorScheme.surface, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Spa,
                    contentDescription = "Onest Nutrition Logo",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ONEST NUTRITION",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.5.sp
            )

            Text(
                text = "Manager & Inventory Suite",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Mode Selector Tabs (Login / Create Account)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                tonalElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Login Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                if (currentMode == AuthMode.LOGIN) MaterialTheme.colorScheme.surface
                                else Color.Transparent
                            )
                            .clickable {
                                errorMessage = null
                                successMessage = null
                                currentMode = AuthMode.LOGIN
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Log In",
                            fontWeight = if (currentMode == AuthMode.LOGIN) FontWeight.Bold else FontWeight.Medium,
                            color = if (currentMode == AuthMode.LOGIN) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // Register Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                if (currentMode == AuthMode.REGISTER) MaterialTheme.colorScheme.surface
                                else Color.Transparent
                            )
                            .clickable {
                                errorMessage = null
                                successMessage = null
                                currentMode = AuthMode.REGISTER
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Create Account",
                            fontWeight = if (currentMode == AuthMode.REGISTER) FontWeight.Bold else FontWeight.Medium,
                            color = if (currentMode == AuthMode.REGISTER) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Card Container with Modern Rounded Styling
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Subtitle
                    Text(
                        text = if (currentMode == AuthMode.LOGIN) "Welcome Back" else "Set Up Your Local Account",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = if (currentMode == AuthMode.LOGIN)
                            "Enter your credentials to securely access your store data."
                        else
                            "Create your store administrator credentials stored safely on this device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    // Error Message Banner
                    AnimatedVisibility(
                        visible = errorMessage != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Success Message Banner
                    AnimatedVisibility(
                        visible = successMessage != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = ForestGreenPrimary.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = ForestGreenPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = successMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ForestGreenPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // REGISTER-ONLY: Full Name
                    if (currentMode == AuthMode.REGISTER) {
                        OutlinedTextField(
                            value = fullName,
                            onValueChange = {
                                fullName = it
                                errorMessage = null
                            },
                            label = { Text("Store Owner / Manager Name") },
                            placeholder = { Text("e.g. Yash Tyagi") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Next
                            ),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_name_input")
                        )
                    }

                    // Username / Email Field
                    OutlinedTextField(
                        value = usernameOrEmail,
                        onValueChange = {
                            usernameOrEmail = it
                            errorMessage = null
                        },
                        label = { Text("Username or Email") },
                        placeholder = { Text("e.g. admin or yash@onestnutrition.com") },
                        leadingIcon = {
                            Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Down) }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_username_input")
                    )

                    // Password Field
                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = null
                        },
                        label = { Text("Password") },
                        placeholder = { Text("••••••••") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { passwordVisible = !passwordVisible },
                                modifier = Modifier.testTag("login_toggle_password_visibility")
                            ) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = if (currentMode == AuthMode.LOGIN) ImeAction.Done else ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Down) },
                            onDone = { focusManager.clearFocus() }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_password_input")
                    )

                    // REGISTER-ONLY: Confirm Password & Security Question
                    if (currentMode == AuthMode.REGISTER) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = {
                                confirmPassword = it
                                errorMessage = null
                            },
                            label = { Text("Confirm Password") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = {
                                Icon(Icons.Default.LockReset, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            trailingIcon = {
                                IconButton(
                                    onClick = { confirmPasswordVisible = !confirmPasswordVisible }
                                ) {
                                    Icon(
                                        imageVector = if (confirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = if (confirmPasswordVisible) "Hide password" else "Show password"
                                    )
                                }
                            },
                            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Next
                            ),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_confirm_password_input")
                        )

                        // Security Question Dropdown
                        ExposedDropdownMenuBox(
                            expanded = showQuestionDropdown,
                            onExpandedChange = { showQuestionDropdown = !showQuestionDropdown },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedSecurityQuestion,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Security Recovery Question") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showQuestionDropdown) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = showQuestionDropdown,
                                onDismissRequest = { showQuestionDropdown = false }
                            ) {
                                defaultSecurityQuestions.forEach { question ->
                                    DropdownMenuItem(
                                        text = { Text(question, style = MaterialTheme.typography.bodySmall) },
                                        onClick = {
                                            selectedSecurityQuestion = question
                                            showQuestionDropdown = false
                                        }
                                    )
                                }
                            }
                        }

                        // Security Answer
                        OutlinedTextField(
                            value = securityAnswer,
                            onValueChange = {
                                securityAnswer = it
                                errorMessage = null
                            },
                            label = { Text("Security Answer (for password reset)") },
                            placeholder = { Text("Your answer...") },
                            leadingIcon = {
                                Icon(Icons.Default.Key, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { focusManager.clearFocus() }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_security_answer_input")
                        )
                    }

                    // Remember Me & Forgot Password Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { rememberMe = !rememberMe }
                                .padding(vertical = 4.dp, horizontal = 2.dp)
                        ) {
                            Checkbox(
                                checked = rememberMe,
                                onCheckedChange = { rememberMe = it },
                                modifier = Modifier.size(28.dp).testTag("login_remember_me_checkbox")
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Remember Me",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (currentMode == AuthMode.LOGIN) {
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    showForgotPasswordDialog = true
                                },
                                modifier = Modifier.testTag("login_forgot_password_btn")
                            ) {
                                Text(
                                    text = "Forgot Password?",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Primary Action Button [ LOGIN ] / [ CREATE ACCOUNT ]
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            errorMessage = null
                            successMessage = null
                            isLoading = true

                            coroutineScope.launch {
                                delay(200) // smooth interaction delay
                                if (currentMode == AuthMode.LOGIN) {
                                    if (usernameOrEmail.isBlank() || password.isBlank()) {
                                        errorMessage = "Please enter both username and password"
                                        isLoading = false
                                        return@launch
                                    }

                                    val result = authManager.login(
                                        username = usernameOrEmail,
                                        password = password,
                                        rememberMe = rememberMe
                                    )

                                    if (result.isSuccess) {
                                        val account = result.getOrNull()!!
                                        successMessage = "Welcome back, ${account.name}!"
                                        delay(300)
                                        onAuthSuccess(account)
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message ?: "Login failed"
                                    }
                                } else {
                                    // Registration Validation
                                    if (fullName.isBlank()) {
                                        errorMessage = "Please enter your name"
                                        isLoading = false
                                        return@launch
                                    }
                                    if (usernameOrEmail.isBlank()) {
                                        errorMessage = "Please choose a username or email"
                                        isLoading = false
                                        return@launch
                                    }
                                    if (password.length < 4) {
                                        errorMessage = "Password must be at least 4 characters long"
                                        isLoading = false
                                        return@launch
                                    }
                                    if (password != confirmPassword) {
                                        errorMessage = "Passwords do not match"
                                        isLoading = false
                                        return@launch
                                    }
                                    if (securityAnswer.isBlank()) {
                                        errorMessage = "Please answer the security question for password recovery"
                                        isLoading = false
                                        return@launch
                                    }

                                    val result = authManager.register(
                                        name = fullName,
                                        username = usernameOrEmail,
                                        password = password,
                                        securityQuestion = selectedSecurityQuestion,
                                        securityAnswer = securityAnswer,
                                        rememberMe = rememberMe
                                    )

                                    if (result.isSuccess) {
                                        val account = result.getOrNull()!!
                                        successMessage = "Account created successfully!"
                                        delay(300)
                                        onAuthSuccess(account)
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message ?: "Registration failed"
                                    }
                                }
                                isLoading = false
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp))
                            .testTag("login_submit_btn"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        enabled = !isLoading
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = if (currentMode == AuthMode.LOGIN) "LOGIN TO DASHBOARD" else "CREATE ACCOUNT & START",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Footer note
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Encrypted Local Storage • Zero Cloud Tracking",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Forgot Password Dialog Flow
    if (showForgotPasswordDialog) {
        ForgotPasswordDialog(
            authManager = authManager,
            onDismiss = { showForgotPasswordDialog = false },
            onPasswordResetSuccess = {
                showForgotPasswordDialog = false
                successMessage = "Password reset successfully! Please log in with your new password."
                currentMode = AuthMode.LOGIN
            }
        )
    }
}

@Composable
fun ForgotPasswordDialog(
    authManager: AuthManager,
    onDismiss: () -> Unit,
    onPasswordResetSuccess: () -> Unit
) {
    val existingAccount = remember { authManager.getAccount() }
    var username by remember { mutableStateOf(existingAccount?.username ?: "") }
    var securityAnswer by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmNewPassword by remember { mutableStateOf("") }
    var newPasswordVisible by remember { mutableStateOf(false) }

    var step by remember { mutableStateOf(1) } // 1 = Verify identity, 2 = Enter new password
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LockReset,
                    contentDescription = null,
                    tint = ForestGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (step == 1) "Reset Password" else "Set New Password",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (step == 1) {
                    Text(
                        text = "Answer your account security question to verify your identity.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            errorMessage = null
                        },
                        label = { Text("Username or Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reset_username_input")
                    )

                    val question = existingAccount?.securityQuestion ?: "Security Question"
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Security Question:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = question,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    OutlinedTextField(
                        value = securityAnswer,
                        onValueChange = {
                            securityAnswer = it
                            errorMessage = null
                        },
                        label = { Text("Your Security Answer") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reset_security_answer_input")
                    )
                } else {
                    Text(
                        text = "Identity verified. Enter your new password below:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = {
                            newPassword = it
                            errorMessage = null
                        },
                        label = { Text("New Password") },
                        visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { newPasswordVisible = !newPasswordVisible }) {
                                Icon(
                                    imageVector = if (newPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reset_new_password_input")
                    )

                    OutlinedTextField(
                        value = confirmNewPassword,
                        onValueChange = {
                            confirmNewPassword = it
                            errorMessage = null
                        },
                        label = { Text("Confirm New Password") },
                        visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reset_confirm_password_input")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    errorMessage = null
                    if (step == 1) {
                        if (username.isBlank() || securityAnswer.isBlank()) {
                            errorMessage = "Please enter both username and answer"
                            return@Button
                        }
                        val verified = authManager.verifySecurityAnswer(username, securityAnswer)
                        if (verified) {
                            step = 2
                        } else {
                            errorMessage = "Incorrect security answer or username"
                        }
                    } else {
                        if (newPassword.length < 4) {
                            errorMessage = "Password must be at least 4 characters"
                            return@Button
                        }
                        if (newPassword != confirmNewPassword) {
                            errorMessage = "Passwords do not match"
                            return@Button
                        }
                        val res = authManager.resetPassword(username, securityAnswer, newPassword)
                        if (res.isSuccess) {
                            onPasswordResetSuccess()
                        } else {
                            errorMessage = res.exceptionOrNull()?.message ?: "Password reset failed"
                        }
                    }
                },
                modifier = Modifier.testTag("reset_submit_btn")
            ) {
                Text(if (step == 1) "Verify & Next" else "Update Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
