package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_movements")
data class StockMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val movementType: String, // "PURCHASE", "SALE", "ADJUSTMENT"
    val quantityChange: Int,
    val remainingStock: Int,
    val referenceId: Long? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
