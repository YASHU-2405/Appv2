package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Sale
import com.example.data.model.SalePayment
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ProfitGreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerLedgerDialog(
    customerName: String,
    sales: List<Sale>,
    payments: List<SalePayment>,
    onDismiss: () -> Unit,
    onRecordPayment: (Sale) -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val customerSales = remember(sales, customerName) {
        sales.filter { it.customerName.equals(customerName, ignoreCase = true) }
            .sortedByDescending { it.saleDate }
    }
    val customerPayments = remember(payments, customerName) {
        payments.filter { it.customerName.equals(customerName, ignoreCase = true) }
            .sortedByDescending { it.paymentDate }
    }

    val totalBilled = customerSales.sumOf { it.totalSaleAmount }
    val totalReceived = customerSales.sumOf { it.amountReceived }
    val totalPending = customerSales.sumOf { it.amountPending }
    val contact = customerSales.firstOrNull { !it.customerContact.isNullOrBlank() }?.customerContact

    var selectedTab by remember { mutableStateOf(0) } // 0: Sales, 1: Payment History
    val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(customerName, fontWeight = FontWeight.Bold)
                                if (!contact.isNullOrBlank()) {
                                    Text(contact, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Ledger Summary Header Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Customer Financial Summary", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Purchases (${customerSales.size}):", style = MaterialTheme.typography.bodyMedium)
                                Text("₹%.2f".format(totalBilled), fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Amount Received:", style = MaterialTheme.typography.bodyMedium)
                                Text("₹%.2f".format(totalReceived), fontWeight = FontWeight.SemiBold, color = ProfitGreen)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Net Balance Due / Pending:", fontWeight = FontWeight.Bold)
                                Text(
                                    "₹%.2f".format(totalPending),
                                    fontWeight = FontWeight.Bold,
                                    color = if (totalPending > 0.001) Color(0xFFC62828) else ProfitGreen
                                )
                            }
                        }
                    }

                    // Tab Selector: Sales vs Payments
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Sales (${customerSales.size})") }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Payments (${customerPayments.size})") }
                        )
                    }

                    if (selectedTab == 0) {
                        // Sales List
                        if (customerSales.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No sales recorded for this customer.", color = MaterialTheme.colorScheme.outline)
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(customerSales, key = { it.id }) { sale ->
                                    Card(
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    ) {
                                        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(sale.productName, fontWeight = FontWeight.Bold)
                                                // Payment Badge
                                                val (statusBg, statusFg) = when (sale.paymentStatus) {
                                                    "PAID" -> Pair(ProfitGreen, Color.White)
                                                    "PARTIAL" -> Pair(Color(0xFFE65100), Color.White)
                                                    else -> Pair(MaterialTheme.colorScheme.error, Color.White)
                                                }
                                                Surface(color = statusBg, shape = RoundedCornerShape(6.dp)) {
                                                    Text(
                                                        sale.paymentStatus,
                                                        color = statusFg,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Text(
                                                "${sale.quantity} units • ${dateFormat.format(Date(sale.saleDate))}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Total: ₹%.2f".format(sale.totalSaleAmount), fontWeight = FontWeight.SemiBold)
                                                Text("Rec: ₹%.2f".format(sale.amountReceived), color = ProfitGreen, style = MaterialTheme.typography.bodySmall)
                                                Text(
                                                    "Pending: ₹%.2f".format(sale.amountPending),
                                                    color = if (sale.amountPending > 0.001) Color(0xFFC62828) else ProfitGreen,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }

                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (!sale.receiptImageUri.isNullOrBlank()) {
                                                    TextButton(onClick = { onViewReceipt(sale.receiptImageUri) }) {
                                                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("View Bill", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                                if (sale.amountPending > 0.001) {
                                                    Button(
                                                        onClick = { onRecordPayment(sale) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                        modifier = Modifier.height(32.dp)
                                                    ) {
                                                        Text("Record Payment", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Payment History List
                        if (customerPayments.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No payment receipts recorded.", color = MaterialTheme.colorScheme.outline)
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(customerPayments, key = { it.id }) { pay ->
                                    Card(
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    ) {
                                        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(
                                                    "Received ₹%.2f".format(pay.amount),
                                                    fontWeight = FontWeight.Bold,
                                                    color = ProfitGreen
                                                )
                                                Text(
                                                    pay.paymentMethod,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.outline
                                                )
                                            }
                                            Text(
                                                dateFormat.format(Date(pay.paymentDate)),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                            if (pay.notes.isNotBlank()) {
                                                Text("Note: ${pay.notes}", style = MaterialTheme.typography.bodySmall)
                                            }
                                            if (!pay.receiptImageUri.isNullOrBlank()) {
                                                TextButton(
                                                    onClick = { onViewReceipt(pay.receiptImageUri) },
                                                    modifier = Modifier.align(Alignment.End)
                                                ) {
                                                    Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Receipt Photo", style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
