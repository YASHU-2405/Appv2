package com.example.data.dao

import androidx.room.*
import com.example.data.model.AiLog
import kotlinx.coroutines.flow.Flow

@Dao
interface AiLogDao {
    @Query("SELECT * FROM ai_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AiLog>>

    @Query("SELECT * FROM ai_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentLogs(limit: Int): Flow<List<AiLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AiLog): Long

    @Query("DELETE FROM ai_logs")
    suspend fun clearAllLogs()
}
