package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.database.AppDatabase
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BillWithItems
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.Sale
import com.example.data.model.SaleLineItemDraft
import com.example.data.model.StockMovement
import kotlinx.coroutines.flow.Flow

class NutritionRepository(private val database: AppDatabase) {
    private val productDao = database.productDao()
    private val purchaseDao = database.purchaseDao()
    private val saleDao = database.saleDao()
    private val movementDao = database.stockMovementDao()
    private val aiLogDao = database.aiLogDao()
    private val productUsageDao = database.productUsageDao()
    private val borrowedProductDao = database.borrowedProductDao()
    private val salePaymentDao = database.salePaymentDao()
    private val purchaseOrderDao = database.purchaseOrderDao()
    private val billDao = database.billDao()

    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allPurchases: Flow<List<Purchase>> = purchaseDao.getAllPurchases()
    val allSales: Flow<List<Sale>> = saleDao.getAllSales()
    val allMovements: Flow<List<StockMovement>> = movementDao.getAllMovements()
    val allAiLogs: Flow<List<com.example.data.model.AiLog>> = aiLogDao.getAllLogs()
    val allProductUsages: Flow<List<com.example.data.model.ProductUsage>> = productUsageDao.getAllProductUsages()
    val allBorrowedProducts: Flow<List<com.example.data.model.BorrowedProduct>> = borrowedProductDao.getAllBorrowedProducts()
    val activeBorrowedProducts: Flow<List<com.example.data.model.BorrowedProduct>> = borrowedProductDao.getActiveBorrowedProducts()
    val allPayments: Flow<List<com.example.data.model.SalePayment>> = salePaymentDao.getAllPayments()
    val allPurchaseOrders: Flow<List<com.example.data.model.PurchaseOrder>> = purchaseOrderDao.getAllOrders()
    val allBillsWithItems: Flow<List<BillWithItems>> = billDao.getAllBillsWithItems()

    suspend fun insertAiLog(log: com.example.data.model.AiLog): Long = aiLogDao.insertLog(log)
    suspend fun clearAiLogs() = aiLogDao.clearAllLogs()

    fun getProductById(id: Long): Flow<Product?> = productDao.getProductById(id)
    suspend fun getProductByIdDirect(id: Long): Product? = productDao.getProductByIdDirect(id)
    suspend fun getPurchaseByIdDirect(id: Long): Purchase? = purchaseDao.getPurchaseById(id)
    suspend fun getSaleByIdDirect(id: Long): Sale? = saleDao.getSaleById(id)
    suspend fun findProductByName(name: String): Product? = productDao.findProductByName(name)

    suspend fun getAllProductsList(): List<Product> = productDao.getAllProductsList()
    suspend fun getAllPurchasesList(): List<Purchase> = purchaseDao.getAllPurchasesList()
    suspend fun getAllSalesList(): List<Sale> = saleDao.getAllSalesList()
    suspend fun getAllMovementsList(): List<StockMovement> = movementDao.getAllMovementsList()
    suspend fun getAllProductUsagesList(): List<com.example.data.model.ProductUsage> = productUsageDao.getAllProductUsagesList()
    suspend fun getAllBorrowedProductsList(): List<com.example.data.model.BorrowedProduct> = borrowedProductDao.getAllBorrowedProductsList()
    suspend fun getAllPaymentsList(): List<com.example.data.model.SalePayment> = salePaymentDao.getAllPaymentsList()
    suspend fun getAllPurchaseOrdersList(): List<com.example.data.model.PurchaseOrder> = purchaseOrderDao.getAllOrdersList()
    suspend fun getPurchaseOrderById(id: Long): com.example.data.model.PurchaseOrder? = purchaseOrderDao.getOrderById(id)

    fun getPaymentsForSale(saleId: Long): Flow<List<com.example.data.model.SalePayment>> =
        salePaymentDao.getPaymentsForSale(saleId)

    suspend fun getPaymentsForSaleList(saleId: Long): List<com.example.data.model.SalePayment> =
        salePaymentDao.getPaymentsForSaleList(saleId)

    fun getPaymentsForCustomer(customerName: String): Flow<List<com.example.data.model.SalePayment>> =
        salePaymentDao.getPaymentsForCustomer(customerName)

    fun getPurchasesForOrder(orderId: Long): Flow<List<Purchase>> =
        purchaseDao.getPurchasesForOrder(orderId)

    suspend fun getPurchasesForOrderList(orderId: Long): List<Purchase> =
        purchaseDao.getPurchasesForOrderList(orderId)

    fun getPurchasesForProduct(productId: Long): Flow<List<Purchase>> =
        purchaseDao.getPurchasesForProduct(productId)

    fun getSalesForProduct(productId: Long): Flow<List<Sale>> =
        saleDao.getSalesForProduct(productId)

    fun getMovementsForProduct(productId: Long): Flow<List<StockMovement>> =
        movementDao.getMovementsForProduct(productId)

    fun getUsagesForProduct(productId: Long): Flow<List<com.example.data.model.ProductUsage>> =
        productUsageDao.getUsagesForProduct(productId)

    fun getBorrowedForProduct(productId: Long): Flow<List<com.example.data.model.BorrowedProduct>> =
        borrowedProductDao.getBorrowedForProduct(productId)

    suspend fun insertProduct(product: Product): Long {
        return database.withTransaction {
            val id = productDao.insert(product)
            if (product.currentStock > 0) {
                movementDao.insert(
                    StockMovement(
                        productId = id,
                        productName = product.name,
                        movementType = "INITIAL_STOCK",
                        quantityChange = product.currentStock,
                        remainingStock = product.currentStock,
                        notes = "Initial inventory setup"
                    )
                )
            }
            id
        }
    }

    suspend fun updateProduct(product: Product) {
        productDao.update(product)
    }

    suspend fun deleteProduct(product: Product) {
        database.withTransaction {
            if (product.currentStock > 0) {
                movementDao.insert(
                    StockMovement(
                        productId = product.id,
                        productName = product.name,
                        movementType = "PRODUCT_DELETED",
                        quantityChange = -product.currentStock,
                        remainingStock = 0,
                        notes = "Product deleted from catalog with ${product.currentStock} units"
                    )
                )
            }
            productDao.delete(product)
        }
    }

    suspend fun recordPurchase(purchase: Purchase): Result<Long> {
        return try {
            val purchaseId = database.withTransaction {
                val id = purchaseDao.insert(purchase)
                val product = productDao.getProductByIdDirect(purchase.productId)
                if (product != null) {
                    val newStock = product.currentStock + purchase.quantity
                    productDao.updateStock(product.id, newStock)
                    movementDao.insert(
                        StockMovement(
                            productId = product.id,
                            productName = product.name,
                            movementType = "PURCHASE",
                            quantityChange = purchase.quantity,
                            remainingStock = newStock,
                            referenceId = id,
                            timestamp = purchase.purchaseDate,
                            notes = "Purchased (Invoice: ${purchase.invoiceNumber})"
                        )
                    )
                }
                id
            }
            Result.success(purchaseId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordSale(sale: Sale): Result<Long> {
        return try {
            val saleId = database.withTransaction {
                val product = productDao.getProductByIdDirect(sale.productId)
                    ?: throw IllegalArgumentException("Product not found")

                if (sale.quantity > product.currentStock) {
                    throw IllegalStateException(
                        "Cannot sell ${sale.quantity} units. Only ${product.currentStock} in stock for '${product.name}'."
                    )
                }

                val newStock = product.currentStock - sale.quantity
                val id = saleDao.insert(sale)
                productDao.updateStock(product.id, newStock)
                movementDao.insert(
                    StockMovement(
                        productId = product.id,
                        productName = product.name,
                        movementType = "SALE",
                        quantityChange = -sale.quantity,
                        remainingStock = newStock,
                        referenceId = id,
                        timestamp = sale.saleDate,
                        notes = "Sold to ${sale.customerName ?: "Walk-in customer"}"
                    )
                )

                // If customer made an upfront payment, record SalePayment
                if (sale.amountReceived > 0) {
                    salePaymentDao.insert(
                        com.example.data.model.SalePayment(
                            saleId = id,
                            customerName = sale.customerName,
                            customerContact = sale.customerContact,
                            amount = sale.amountReceived,
                            paymentDate = sale.paymentDate ?: sale.saleDate,
                            paymentMethod = sale.paymentMethod,
                            notes = if (sale.paymentNote.isNotBlank()) sale.paymentNote else "Initial sale payment",
                            receiptImageUri = sale.receiptImageUri
                        )
                    )
                }
                id
            }
            Result.success(saleId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordMultiProductSale(
        items: List<SaleLineItemDraft>,
        customerName: String?,
        customerContact: String?,
        customerEmail: String?,
        customerAddress: String?,
        saleInvoiceNumber: String = "",
        saleDate: Long,
        notes: String,
        amountReceived: Double,
        paymentMethod: String = "Cash",
        paymentDate: Long = saleDate,
        paymentNote: String = ""
    ): Result<List<Long>> {
        return try {
            val saleIds = database.withTransaction {
                if (items.isEmpty()) {
                    throw IllegalArgumentException("Please add at least one product to the sale.")
                }

                // 1. Strict Stock validation for EVERY product before modifying anything
                for (item in items) {
                    val currentProd = productDao.getProductByIdDirect(item.product.id)
                        ?: throw IllegalArgumentException("Product '${item.product.name}' was not found in catalog.")
                    if (item.quantity > currentProd.currentStock) {
                        throw IllegalStateException(
                            "INSUFFICIENT STOCK: Product '${item.product.name}' (Available: ${currentProd.currentStock}, Requested: ${item.quantity}). Cannot confirm sale."
                        )
                    }
                }

                val finalSaleTotal = items.sumOf { it.lineTotal }
                val invNo = saleInvoiceNumber.ifBlank { "SALE-${System.currentTimeMillis() % 1000000}" }
                val results = mutableListOf<Long>()

                var remainingReceivedToAllocate = amountReceived

                for ((index, item) in items.withIndex()) {
                    val currentProd = productDao.getProductByIdDirect(item.product.id)!!
                    val newStock = currentProd.currentStock - item.quantity
                    productDao.updateStock(currentProd.id, newStock)

                    // Allocate payment across items proportionately
                    val itemReceived = if (index == items.lastIndex) {
                        remainingReceivedToAllocate.coerceAtMost(item.lineTotal)
                    } else {
                        val ratio = if (finalSaleTotal > 0) item.lineTotal / finalSaleTotal else 0.0
                        val allocated = (amountReceived * ratio).coerceAtMost(item.lineTotal)
                        remainingReceivedToAllocate -= allocated
                        allocated
                    }
                    val itemPending = (item.lineTotal - itemReceived).coerceAtLeast(0.0)
                    val itemStatus = if (itemReceived >= item.lineTotal - 0.01) "PAID" else if (itemReceived <= 0.01) "PENDING" else "PARTIAL"

                    val sale = Sale(
                        productId = currentProd.id,
                        productName = currentProd.name,
                        quantity = item.quantity,
                        sellingPrice = item.baseSellingPrice,
                        discountType = item.discountType,
                        discountPercentage = if (item.discountType == "PERCENTAGE") item.discountValue else 0.0,
                        discountFixedAmount = if (item.discountType == "FIXED_AMOUNT") item.discountValue else 0.0,
                        discountAmount = item.totalDiscountAmount,
                        gstType = item.gstType,
                        taxPercentage = if (item.gstType == "PERCENTAGE") item.gstValue else 0.0,
                        gstFixedAmount = if (item.gstType == "FIXED_AMOUNT") item.gstValue else 0.0,
                        gstAmount = item.totalGstAmount,
                        finalSellingPrice = item.finalPricePerUnit,
                        totalSaleAmount = item.lineTotal,
                        unitPurchaseCost = item.unitPurchaseCost,
                        totalPurchaseCost = item.totalPurchaseCost,
                        profit = item.lineProfit,
                        pointsPerUnit = 0.0, // Business rule: SALES DO NOT EARN VOLUME POINTS
                        totalPoints = 0.0,   // Business rule: SALES DO NOT EARN VOLUME POINTS
                        customerName = customerName?.takeIf { it.isNotBlank() },
                        customerContact = customerContact?.takeIf { it.isNotBlank() },
                        customerEmail = customerEmail?.takeIf { it.isNotBlank() },
                        customerAddress = customerAddress?.takeIf { it.isNotBlank() },
                        saleDate = saleDate,
                        notes = notes,
                        paymentStatus = itemStatus,
                        amountReceived = itemReceived,
                        amountPending = itemPending,
                        paymentMethod = paymentMethod,
                        paymentDate = paymentDate,
                        paymentNote = paymentNote,
                        receiptImageUri = null,
                        saleInvoiceNumber = invNo
                    )

                    val sId = saleDao.insert(sale)
                    results.add(sId)

                    movementDao.insert(
                        StockMovement(
                            productId = currentProd.id,
                            productName = currentProd.name,
                            movementType = "SALE",
                            quantityChange = -item.quantity,
                            remainingStock = newStock,
                            referenceId = sId,
                            timestamp = saleDate,
                            notes = "Sale #$invNo to ${customerName ?: "Walk-in"}"
                        )
                    )

                    if (itemReceived > 0) {
                        salePaymentDao.insert(
                            com.example.data.model.SalePayment(
                                saleId = sId,
                                customerName = customerName,
                                customerContact = customerContact,
                                amount = itemReceived,
                                paymentDate = paymentDate,
                                paymentMethod = paymentMethod,
                                notes = "Payment for #$saleInvoiceNumber (${currentProd.name})"
                            )
                        )
                    }
                }
                results
            }
            Result.success(saleIds)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordAdditionalPayment(
        saleId: Long,
        amount: Double,
        paymentMethod: String = "Cash",
        paymentDate: Long = System.currentTimeMillis(),
        notes: String = "",
        receiptImageUri: String? = null
    ): Result<Long> {
        return try {
            val paymentId = database.withTransaction {
                val sale = saleDao.getSaleById(saleId)
                    ?: throw IllegalArgumentException("Sale not found")
                val newAmountReceived = (sale.amountReceived + amount).coerceAtMost(sale.totalSaleAmount)
                val newAmountPending = (sale.totalSaleAmount - newAmountReceived).coerceAtLeast(0.0)
                val newStatus = if (newAmountPending <= 0.001) "PAID" else "PARTIAL"

                val payment = com.example.data.model.SalePayment(
                    saleId = saleId,
                    customerName = sale.customerName,
                    customerContact = sale.customerContact,
                    amount = amount,
                    paymentDate = paymentDate,
                    paymentMethod = paymentMethod,
                    notes = notes,
                    receiptImageUri = receiptImageUri
                )
                val pId = salePaymentDao.insert(payment)
                saleDao.update(
                    sale.copy(
                        amountReceived = newAmountReceived,
                        amountPending = newAmountPending,
                        paymentStatus = newStatus,
                        paymentMethod = paymentMethod,
                        paymentDate = paymentDate
                    )
                )
                pId
            }
            Result.success(paymentId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordPurchaseOrder(
        order: com.example.data.model.PurchaseOrder,
        items: List<Purchase>
    ): Result<Long> {
        return try {
            val orderId = database.withTransaction {
                val oId = purchaseOrderDao.insert(order)
                for (item in items) {
                    val purchaseWithOrder = item.copy(
                        orderId = oId,
                        invoiceNumber = if (item.invoiceNumber.isNotBlank()) item.invoiceNumber else order.invoiceNumber,
                        supplierName = if (item.supplierName.isNotBlank()) item.supplierName else order.supplierName,
                        receiptImageUri = item.receiptImageUri ?: order.receiptImageUri
                    )
                    val pId = purchaseDao.insert(purchaseWithOrder)
                    val product = productDao.getProductByIdDirect(item.productId)
                    if (product != null) {
                        val newStock = product.currentStock + item.quantity
                        productDao.updateStock(product.id, newStock)
                        movementDao.insert(
                            StockMovement(
                                productId = product.id,
                                productName = product.name,
                                movementType = "PURCHASE",
                                quantityChange = item.quantity,
                                remainingStock = newStock,
                                referenceId = pId,
                                timestamp = item.purchaseDate,
                                notes = "Order #${order.orderNumber} (Invoice: ${order.invoiceNumber})"
                            )
                        )
                    }
                }
                oId
            }
            Result.success(orderId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePurchaseOrder(orderId: Long): Result<Unit> {
        return try {
            database.withTransaction {
                val order = purchaseOrderDao.getOrderById(orderId) ?: return@withTransaction
                val purchases = purchaseDao.getPurchasesForOrderList(orderId)
                for (purchase in purchases) {
                    val product = productDao.getProductByIdDirect(purchase.productId)
                    if (product != null) {
                        val newStock = (product.currentStock - purchase.quantity).coerceAtLeast(0)
                        productDao.updateStock(product.id, newStock)
                        movementDao.insert(
                            StockMovement(
                                productId = product.id,
                                productName = product.name,
                                movementType = "PURCHASE_REVERSAL",
                                quantityChange = -purchase.quantity,
                                remainingStock = newStock,
                                referenceId = purchase.id,
                                notes = "Deleted Purchase Order #${order.orderNumber} reversal"
                            )
                        )
                    }
                    purchaseDao.delete(purchase)
                }
                purchaseOrderDao.delete(order)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateSale(oldSale: Sale, updatedSale: Sale): Result<Unit> {
        return try {
            database.withTransaction {
                val qtyDiff = updatedSale.quantity - oldSale.quantity
                if (qtyDiff != 0) {
                    val product = productDao.getProductByIdDirect(updatedSale.productId)
                        ?: throw IllegalArgumentException("Product not found")
                    if (qtyDiff > 0 && product.currentStock < qtyDiff) {
                        throw IllegalStateException(
                            "Cannot increase sale by $qtyDiff units. Only ${product.currentStock} available in stock."
                        )
                    }
                    val newStock = product.currentStock - qtyDiff
                    productDao.updateStock(product.id, newStock)
                    movementDao.insert(
                        StockMovement(
                            productId = product.id,
                            productName = product.name,
                            movementType = "SALE_EDIT",
                            quantityChange = -qtyDiff,
                            remainingStock = newStock,
                            referenceId = updatedSale.id,
                            notes = "Sale #${updatedSale.id} updated"
                        )
                    )
                }
                saleDao.update(updatedSale)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePurchase(purchase: Purchase): Result<Unit> {
        return try {
            database.withTransaction {
                val product = productDao.getProductByIdDirect(purchase.productId)
                if (product != null) {
                    val newStock = (product.currentStock - purchase.quantity).coerceAtLeast(0)
                    productDao.updateStock(product.id, newStock)
                    movementDao.insert(
                        StockMovement(
                            productId = product.id,
                            productName = product.name,
                            movementType = "PURCHASE_REVERSAL",
                            quantityChange = -purchase.quantity,
                            remainingStock = newStock,
                            referenceId = purchase.id,
                            notes = "Deleted purchase record reversal"
                        )
                    )
                }
                purchaseDao.delete(purchase)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteSale(sale: Sale): Result<Unit> {
        return try {
            database.withTransaction {
                val product = productDao.getProductByIdDirect(sale.productId)
                if (product != null) {
                    val newStock = product.currentStock + sale.quantity
                    productDao.updateStock(product.id, newStock)
                    movementDao.insert(
                        StockMovement(
                            productId = product.id,
                            productName = product.name,
                            movementType = "SALE_REVERSAL",
                            quantityChange = sale.quantity,
                            remainingStock = newStock,
                            referenceId = sale.id,
                            notes = "Deleted sale record reversal"
                        )
                    )
                }
                saleDao.delete(sale)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProductStockDirect(productId: Long, newStock: Int, reason: String) {
        database.withTransaction {
            val product = productDao.getProductByIdDirect(productId) ?: return@withTransaction
            val diff = newStock - product.currentStock
            productDao.updateStock(productId, newStock)
            movementDao.insert(
                StockMovement(
                    productId = productId,
                    productName = product.name,
                    movementType = "ADJUSTMENT",
                    quantityChange = diff,
                    remainingStock = newStock,
                    notes = reason.ifBlank { "Manual stock adjustment" }
                )
            )
        }
    }

    suspend fun updateProductSellingPrice(productId: Long, newPrice: Double) {
        productDao.updateSellingPrice(productId, newPrice)
    }

    suspend fun updateProductPoints(productId: Long, points: Double) {
        productDao.updatePoints(productId, points)
    }

    suspend fun updateProductDiscount(productId: Long, discount: Double) {
        productDao.updateDiscount(productId, discount)
    }

    suspend fun updateProductTax(productId: Long, tax: Double) {
        productDao.updateTax(productId, tax)
    }

    suspend fun recordProductUsage(usage: com.example.data.model.ProductUsage): Result<Long> {
        return try {
            val usageId = database.withTransaction {
                val product = productDao.getProductByIdDirect(usage.productId)
                    ?: throw IllegalArgumentException("Product not found")

                if (usage.quantity > product.currentStock) {
                    throw IllegalStateException(
                        "INSUFFICIENT STOCK\nAvailable: ${product.currentStock} units, Requested: ${usage.quantity} units for '${product.name}'."
                    )
                }

                val newStock = product.currentStock - usage.quantity
                val id = productUsageDao.insert(usage)
                productDao.updateStock(product.id, newStock)
                movementDao.insert(
                    StockMovement(
                        productId = product.id,
                        productName = product.name,
                        movementType = "PRODUCT_USAGE",
                        quantityChange = -usage.quantity,
                        remainingStock = newStock,
                        referenceId = id,
                        timestamp = usage.usageDate,
                        notes = if (usage.notes.isNotBlank()) "Used: ${usage.notes}" else "Product usage / personal consumption"
                    )
                )
                id
            }
            Result.success(usageId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteProductUsage(usage: com.example.data.model.ProductUsage): Result<Unit> {
        return try {
            database.withTransaction {
                val product = productDao.getProductByIdDirect(usage.productId)
                if (product != null) {
                    val newStock = product.currentStock + usage.quantity
                    productDao.updateStock(product.id, newStock)
                    movementDao.insert(
                        StockMovement(
                            productId = product.id,
                            productName = product.name,
                            movementType = "PRODUCT_USAGE_REVERSAL",
                            quantityChange = usage.quantity,
                            remainingStock = newStock,
                            referenceId = usage.id,
                            notes = "Reversed product usage #${usage.id}"
                        )
                    )
                }
                productUsageDao.delete(usage)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordBorrowedProduct(borrowed: com.example.data.model.BorrowedProduct): Result<Long> {
        return try {
            val borrowedId = database.withTransaction {
                val id = borrowedProductDao.insert(borrowed)
                val product = productDao.getProductByIdDirect(borrowed.productId)
                movementDao.insert(
                    StockMovement(
                        productId = borrowed.productId,
                        productName = borrowed.productName,
                        movementType = "BORROWED_IN",
                        quantityChange = borrowed.quantityBorrowed,
                        remainingStock = (product?.currentStock ?: 0),
                        referenceId = id,
                        timestamp = borrowed.dateReceived,
                        notes = "Borrowed ${borrowed.quantityBorrowed} units from ${borrowed.personOrBusinessName}"
                    )
                )
                id
            }
            Result.success(borrowedId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun returnBorrowedProduct(borrowedId: Long, returnQuantity: Int, returnNotes: String = ""): Result<Unit> {
        return try {
            database.withTransaction {
                val item = borrowedProductDao.getBorrowedProductById(borrowedId)
                    ?: throw IllegalArgumentException("Borrowed record not found")

                val remaining = item.remainingQuantity
                if (returnQuantity > remaining) {
                    throw IllegalStateException(
                        "Cannot return $returnQuantity units. Only $remaining units are remaining on loan from '${item.personOrBusinessName}'."
                    )
                }

                val newReturned = item.quantityReturned + returnQuantity
                val isFullyReturned = (newReturned + item.quantitySold) >= item.quantityBorrowed
                val updatedStatus = if (isFullyReturned) "RETURNED" else "PARTIALLY_RETURNED"

                val updatedItem = item.copy(
                    quantityReturned = newReturned,
                    status = updatedStatus,
                    notes = if (returnNotes.isNotBlank()) "${item.notes}\n[Return: $returnNotes]".trim() else item.notes
                )
                borrowedProductDao.update(updatedItem)

                val product = productDao.getProductByIdDirect(item.productId)
                movementDao.insert(
                    StockMovement(
                        productId = item.productId,
                        productName = item.productName,
                        movementType = "BORROWED_RETURN",
                        quantityChange = -returnQuantity,
                        remainingStock = (product?.currentStock ?: 0),
                        referenceId = item.id,
                        notes = "Returned $returnQuantity units to ${item.personOrBusinessName}"
                    )
                )
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun settleBorrowedProduct(borrowedId: Long, settlementAmount: Double, notes: String = ""): Result<Unit> {
        return try {
            database.withTransaction {
                val item = borrowedProductDao.getBorrowedProductById(borrowedId)
                    ?: throw IllegalArgumentException("Borrowed record not found")

                val updatedItem = item.copy(
                    status = "SETTLED",
                    settlementAmount = settlementAmount,
                    settlementDate = System.currentTimeMillis(),
                    settlementNotes = notes
                )
                borrowedProductDao.update(updatedItem)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteBorrowedProduct(borrowed: com.example.data.model.BorrowedProduct) {
        database.withTransaction {
            borrowedProductDao.delete(borrowed)
        }
    }

    suspend fun getAllBillsWithItemsList(): List<BillWithItems> = billDao.getAllBillsWithItemsList()
    suspend fun getBillWithItemsById(id: Long): BillWithItems? = billDao.getBillWithItemsById(id)
    suspend fun getBillById(id: Long): Bill? = billDao.getBillById(id)

    suspend fun insertBillWithItems(
        bill: Bill,
        items: List<BillItem>,
        createPurchaseStock: Boolean = false
    ): Result<Long> {
        return try {
            val billId = database.withTransaction {
                val bId = billDao.insertBill(bill)
                val itemsWithBillId = items.map { it.copy(billId = bId) }
                billDao.insertBillItems(itemsWithBillId)

                // ONLY if explicitly requested by user in UI, create corresponding purchase order & purchases
                if (createPurchaseStock) {
                    val po = com.example.data.model.PurchaseOrder(
                        orderNumber = bill.billNumber,
                        invoiceNumber = bill.billNumber,
                        supplierName = bill.supplierName,
                        purchaseDate = bill.billDate,
                        totalProducts = items.size,
                        totalQuantity = items.sumOf { it.quantity },
                        totalOriginalAmount = bill.totalOriginalAmount,
                        totalDiscountAmount = bill.totalDiscountAmount,
                        totalGstAmount = bill.totalGstAmount,
                        finalPurchaseAmount = bill.finalAmount,
                        totalPoints = 0.0,
                        notes = "Created from Bill #${bill.billNumber}",
                        receiptImageUri = bill.billImageUri
                    )
                    val poId = purchaseOrderDao.insert(po)
                    billDao.updateBill(bill.copy(id = bId, linkedPurchaseOrderId = poId))

                    for (item in items) {
                        var targetProduct = if (item.productId != null) {
                            productDao.getProductByIdDirect(item.productId)
                        } else {
                            productDao.findProductByName(item.productName)
                        }

                        if (targetProduct == null) {
                            val newProd = Product(
                                name = item.productName,
                                purchasePrice = item.originalPrice,
                                discountPercentage = item.discountPercentage,
                                taxPercentage = item.taxPercentage,
                                finalPurchaseCost = item.finalPricePerUnit,
                                sellingPrice = item.finalPricePerUnit * 1.25,
                                currentStock = 0
                            )
                            val newProdId = productDao.insert(newProd)
                            targetProduct = productDao.getProductByIdDirect(newProdId)!!
                        }

                        val purchase = Purchase(
                            productId = targetProduct.id,
                            productName = targetProduct.name,
                            quantity = item.quantity,
                            originalPrice = item.originalPrice,
                            discountPercentage = item.discountPercentage,
                            discountAmount = item.discountAmount,
                            taxPercentage = item.taxPercentage,
                            taxAmount = item.taxAmount,
                            finalPricePerUnit = item.finalPricePerUnit,
                            totalAmount = item.totalAmount,
                            purchaseDate = bill.billDate,
                            invoiceNumber = bill.billNumber,
                            supplierName = bill.supplierName,
                            receiptImageUri = bill.billImageUri,
                            orderId = poId,
                            paymentStatus = bill.paymentStatus,
                            amountPaid = bill.amountPaid,
                            amountPending = bill.amountPending
                        )
                        val purchaseId = purchaseDao.insert(purchase)
                        val updatedStock = targetProduct.currentStock + item.quantity
                        productDao.updateStock(targetProduct.id, updatedStock)
                        movementDao.insert(
                            StockMovement(
                                productId = targetProduct.id,
                                productName = targetProduct.name,
                                movementType = "PURCHASE",
                                quantityChange = item.quantity,
                                remainingStock = updatedStock,
                                referenceId = purchaseId,
                                timestamp = bill.billDate,
                                notes = "Stock added from Bill #${bill.billNumber}"
                            )
                        )
                    }
                }
                bId
            }
            Result.success(billId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateBill(bill: Bill, items: List<BillItem>): Result<Unit> {
        return try {
            database.withTransaction {
                billDao.updateBill(bill)
                billDao.deleteBillItemsForBill(bill.id)
                val itemsWithBillId = items.map { it.copy(billId = bill.id) }
                billDao.insertBillItems(itemsWithBillId)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteBill(bill: Bill): Result<Unit> {
        return try {
            billDao.deleteBill(bill)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreAllData(
        products: List<Product>,
        purchases: List<Purchase>,
        sales: List<Sale>,
        movements: List<StockMovement>,
        usages: List<com.example.data.model.ProductUsage> = emptyList(),
        borrowed: List<com.example.data.model.BorrowedProduct> = emptyList(),
        payments: List<com.example.data.model.SalePayment> = emptyList(),
        purchaseOrders: List<com.example.data.model.PurchaseOrder> = emptyList(),
        billsWithItems: List<BillWithItems> = emptyList()
    ) {
        database.withTransaction {
            productDao.deleteAll()
            purchaseDao.deleteAll()
            saleDao.deleteAll()
            movementDao.deleteAll()
            productUsageDao.deleteAll()
            borrowedProductDao.deleteAll()
            salePaymentDao.deleteAll()
            purchaseOrderDao.deleteAll()
            billDao.deleteAll()

            if (products.isNotEmpty()) productDao.insertAll(products)
            if (purchases.isNotEmpty()) purchaseDao.insertAll(purchases)
            if (sales.isNotEmpty()) saleDao.insertAll(sales)
            if (movements.isNotEmpty()) movementDao.insertAll(movements)
            if (usages.isNotEmpty()) productUsageDao.insertAll(usages)
            if (borrowed.isNotEmpty()) borrowedProductDao.insertAll(borrowed)
            if (payments.isNotEmpty()) salePaymentDao.insertAll(payments)
            if (purchaseOrders.isNotEmpty()) purchaseOrderDao.insertAll(purchaseOrders)
            for (bwi in billsWithItems) {
                val bId = billDao.insertBill(bwi.bill)
                if (bwi.items.isNotEmpty()) {
                    billDao.insertBillItems(bwi.items.map { it.copy(billId = bId) })
                }
            }
        }
    }

    suspend fun restoreMergeData(
        products: List<Product>,
        purchases: List<Purchase>,
        sales: List<Sale>,
        movements: List<StockMovement>,
        usages: List<com.example.data.model.ProductUsage> = emptyList(),
        borrowed: List<com.example.data.model.BorrowedProduct> = emptyList(),
        payments: List<com.example.data.model.SalePayment> = emptyList(),
        purchaseOrders: List<com.example.data.model.PurchaseOrder> = emptyList(),
        billsWithItems: List<BillWithItems> = emptyList()
    ) {
        database.withTransaction {
            if (products.isNotEmpty()) productDao.insertAll(products)
            if (purchases.isNotEmpty()) purchaseDao.insertAll(purchases)
            if (sales.isNotEmpty()) saleDao.insertAll(sales)
            if (movements.isNotEmpty()) movementDao.insertAll(movements)
            if (usages.isNotEmpty()) productUsageDao.insertAll(usages)
            if (borrowed.isNotEmpty()) borrowedProductDao.insertAll(borrowed)
            if (payments.isNotEmpty()) salePaymentDao.insertAll(payments)
            if (purchaseOrders.isNotEmpty()) purchaseOrderDao.insertAll(purchaseOrders)
            for (bwi in billsWithItems) {
                val bId = billDao.insertBill(bwi.bill)
                if (bwi.items.isNotEmpty()) {
                    billDao.insertBillItems(bwi.items.map { it.copy(billId = bId) })
                }
            }
        }
    }
}
