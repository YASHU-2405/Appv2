package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.SalePayment
import kotlinx.coroutines.flow.Flow

@Dao
interface SalePaymentDao {
    @Query("SELECT * FROM sale_payments ORDER BY paymentDate DESC")
    fun getAllPayments(): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments ORDER BY paymentDate DESC")
    suspend fun getAllPaymentsList(): List<SalePayment>

    @Query("SELECT * FROM sale_payments WHERE saleId = :saleId ORDER BY paymentDate DESC")
    fun getPaymentsForSale(saleId: Long): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments WHERE saleId = :saleId ORDER BY paymentDate DESC")
    suspend fun getPaymentsForSaleList(saleId: Long): List<SalePayment>

    @Query("SELECT * FROM sale_payments WHERE customerName = :customerName ORDER BY paymentDate DESC")
    fun getPaymentsForCustomer(customerName: String): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments WHERE customerName = :customerName ORDER BY paymentDate DESC")
    suspend fun getPaymentsForCustomerList(customerName: String): List<SalePayment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payment: SalePayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(payments: List<SalePayment>): List<Long>

    @Delete
    suspend fun delete(payment: SalePayment)

    @Query("DELETE FROM sale_payments")
    suspend fun deleteAll()
}
