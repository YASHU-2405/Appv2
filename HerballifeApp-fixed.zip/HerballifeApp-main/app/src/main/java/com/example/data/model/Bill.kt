package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billNumber: String,
    val billDate: Long = System.currentTimeMillis(),
    val supplierName: String = "",
    val billImageUri: String? = null,
    val totalOriginalAmount: Double = 0.0,
    val totalDiscountAmount: Double = 0.0,
    val totalGstAmount: Double = 0.0,
    val finalAmount: Double = 0.0,
    val amountPaid: Double = 0.0,
    val amountPending: Double = 0.0,
    val paymentStatus: String = "PAID", // "PAID", "PARTIAL", "PENDING"
    val notes: String = "",
    val linkedPurchaseOrderId: Long? = null
)
