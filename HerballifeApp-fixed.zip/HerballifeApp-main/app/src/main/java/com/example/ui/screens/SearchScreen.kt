package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SearchScreen(
    viewModel: NutritionViewModel,
    onProductClick: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val purchaseOrders by viewModel.purchaseOrders.collectAsStateWithLifecycle()
    val borrowedProducts by viewModel.borrowedProducts.collectAsStateWithLifecycle()

    var selectedCategory by remember { mutableStateOf("ALL") } // ALL, PRODUCTS, SALES, PURCHASES, ORDERS, BORROWED

    val q = searchQuery.trim().lowercase()

    val matchedProducts = remember(products, q) {
        if (q.isBlank()) emptyList()
        else products.filter {
            it.name.lowercase().contains(q) ||
            it.sku.lowercase().contains(q) ||
            it.variant.lowercase().contains(q) ||
            it.notes.lowercase().contains(q)
        }
    }

    val matchedSales = remember(sales, q) {
        if (q.isBlank()) emptyList()
        else sales.filter {
            it.productName.lowercase().contains(q) ||
            (it.customerName?.lowercase()?.contains(q) == true) ||
            (it.customerContact?.lowercase()?.contains(q) == true) ||
            (it.customerEmail?.lowercase()?.contains(q) == true) ||
            it.paymentStatus.lowercase().contains(q)
        }
    }

    val matchedPurchases = remember(purchases, q) {
        if (q.isBlank()) emptyList()
        else purchases.filter {
            it.productName.lowercase().contains(q) ||
            it.invoiceNumber.lowercase().contains(q) ||
            it.supplierName.lowercase().contains(q)
        }
    }

    val matchedOrders = remember(purchaseOrders, q) {
        if (q.isBlank()) emptyList()
        else purchaseOrders.filter {
            it.orderNumber.lowercase().contains(q) ||
            it.invoiceNumber.lowercase().contains(q) ||
            it.supplierName.lowercase().contains(q)
        }
    }

    val matchedBorrowed = remember(borrowedProducts, q) {
        if (q.isBlank()) emptyList()
        else borrowedProducts.filter {
            it.productName.lowercase().contains(q) ||
            it.personOrBusinessName.lowercase().contains(q)
        }
    }

    val totalMatches = matchedProducts.size + matchedSales.size + matchedPurchases.size + matchedOrders.size + matchedBorrowed.size

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("global_search_screen")
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search products, customers, suppliers, invoices...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = if (searchQuery.isNotEmpty()) {
                {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            } else null,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )

        // Filter chips row
        if (searchQuery.isNotBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == "ALL",
                    onClick = { selectedCategory = "ALL" },
                    label = { Text("All ($totalMatches)") }
                )
                if (matchedProducts.isNotEmpty()) {
                    FilterChip(
                        selected = selectedCategory == "PRODUCTS",
                        onClick = { selectedCategory = "PRODUCTS" },
                        label = { Text("Products (${matchedProducts.size})") }
                    )
                }
                if (matchedSales.isNotEmpty()) {
                    FilterChip(
                        selected = selectedCategory == "SALES",
                        onClick = { selectedCategory = "SALES" },
                        label = { Text("Sales (${matchedSales.size})") }
                    )
                }
                if (matchedPurchases.isNotEmpty()) {
                    FilterChip(
                        selected = selectedCategory == "PURCHASES",
                        onClick = { selectedCategory = "PURCHASES" },
                        label = { Text("Purchases (${matchedPurchases.size})") }
                    )
                }
                if (matchedOrders.isNotEmpty()) {
                    FilterChip(
                        selected = selectedCategory == "ORDERS",
                        onClick = { selectedCategory = "ORDERS" },
                        label = { Text("Orders (${matchedOrders.size})") }
                    )
                }
                if (matchedBorrowed.isNotEmpty()) {
                    FilterChip(
                        selected = selectedCategory == "BORROWED",
                        onClick = { selectedCategory = "BORROWED" },
                        label = { Text("Borrowed (${matchedBorrowed.size})") }
                    )
                }
            }
        }

        if (searchQuery.isBlank()) {
            EmptyStateCard(
                icon = Icons.Default.Search,
                title = "Global Search",
                description = "Type product name, invoice number, customer name, supplier, or SKU to search across your whole business."
            )
        } else if (totalMatches == 0) {
            EmptyStateCard(
                icon = Icons.Default.SearchOff,
                title = "No Results Found",
                description = "No matching products, sales, purchases, orders, or borrowed records found for '$searchQuery'."
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp, top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Products matches
                if (matchedProducts.isNotEmpty() && (selectedCategory == "ALL" || selectedCategory == "PRODUCTS")) {
                    item {
                        Text(
                            text = "Products (${matchedProducts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary
                        )
                    }
                    items(matchedProducts, key = { "prod_${it.id}" }) { prod ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onProductClick(prod) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        "Stock: ${prod.currentStock} units • Price: ₹%.2f".format(prod.sellingPrice),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text("%.2f pts".format(prod.points), fontWeight = FontWeight.Bold, color = PointsGold)
                            }
                        }
                    }
                }

                // Purchase Orders matches
                if (matchedOrders.isNotEmpty() && (selectedCategory == "ALL" || selectedCategory == "ORDERS")) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Purchase Orders (${matchedOrders.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StockBlue
                        )
                    }
                    items(matchedOrders, key = { "order_${it.id}" }) { o ->
                        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(o.purchaseDate))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("#${o.orderNumber}", fontWeight = FontWeight.Bold)
                                        if (o.invoiceNumber.isNotBlank()) {
                                            Surface(color = StockBlue.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp)) {
                                                Text("Inv: ${o.invoiceNumber}", style = MaterialTheme.typography.labelSmall, color = StockBlue, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                            }
                                        }
                                    }
                                    Text("$dateStr • Supplier: ${o.supplierName.ifBlank { "Direct" }} • ${o.totalProducts} items", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                                Text("₹%.2f".format(o.finalPurchaseAmount), fontWeight = FontWeight.Bold, color = StockBlue)
                            }
                        }
                    }
                }

                // Purchases matches
                if (matchedPurchases.isNotEmpty() && (selectedCategory == "ALL" || selectedCategory == "PURCHASES")) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Stock Purchases (${matchedPurchases.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StockBlue
                        )
                    }
                    items(matchedPurchases, key = { "pur_${it.id}" }) { p ->
                        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(p.purchaseDate))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.productName, fontWeight = FontWeight.Bold)
                                    Text(
                                        "$dateStr • ${p.quantity} units" +
                                                if (p.supplierName.isNotBlank()) " • ${p.supplierName}" else "" +
                                                if (p.invoiceNumber.isNotBlank()) " • Inv: ${p.invoiceNumber}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Text("₹%.2f".format(p.totalAmount), fontWeight = FontWeight.Bold, color = StockBlue)
                            }
                        }
                    }
                }

                // Sales matches
                if (matchedSales.isNotEmpty() && (selectedCategory == "ALL" || selectedCategory == "SALES")) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Customer Sales (${matchedSales.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ProfitGreen
                        )
                    }
                    items(matchedSales, key = { "sale_${it.id}" }) { s ->
                        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(s.saleDate))
                        val statusColor = when (s.paymentStatus.uppercase()) {
                            "PAID" -> ProfitGreen
                            "PARTIAL" -> Color(0xFFE65100)
                            else -> MaterialTheme.colorScheme.error
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(s.productName, fontWeight = FontWeight.Bold)
                                        Surface(color = statusColor.copy(alpha = 0.12f), shape = RoundedCornerShape(4.dp)) {
                                            Text(s.paymentStatus.uppercase(), style = MaterialTheme.typography.labelSmall, color = statusColor, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                        }
                                    }
                                    Text("$dateStr • Customer: ${s.customerName ?: "Walk-in"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("₹%.2f".format(s.totalSaleAmount), fontWeight = FontWeight.Bold)
                                    if (s.amountPending > 0.01) {
                                        Text("Due: ₹%.2f".format(s.amountPending), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Borrowed Products matches
                if (matchedBorrowed.isNotEmpty() && (selectedCategory == "ALL" || selectedCategory == "BORROWED")) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Borrowed / Loaned Items (${matchedBorrowed.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PointsGold
                        )
                    }
                    items(matchedBorrowed, key = { "borrowed_${it.id}" }) { b ->
                        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(b.dateReceived))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(b.productName, fontWeight = FontWeight.Bold)
                                    Text("$dateStr • Party: ${b.personOrBusinessName} • ${b.quantityBorrowed} units", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                                Surface(
                                    color = if (b.status == "BORROWED") PointsGold.copy(alpha = 0.12f) else ProfitGreen.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = b.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (b.status == "BORROWED") PointsGold else ProfitGreen,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
