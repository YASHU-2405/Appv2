package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.*
import com.example.ui.components.AiActionLogDialog
import com.example.util.ReceiptImageStorage
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.MessageSender
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AiAssistantScreen(
    viewModel: AiAssistantViewModel,
    onNavigateToDestination: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isSearchingWeb by viewModel.isSearchingWeb.collectAsStateWithLifecycle()
    val inputQuery by viewModel.inputQuery.collectAsStateWithLifecycle()
    val selectedImage by viewModel.selectedImageBitmap.collectAsStateWithLifecycle()
    val aiLogs by viewModel.allAiLogs.collectAsStateWithLifecycle(emptyList())

    val listState = rememberLazyListState()
    var showAiLogDialog by remember { mutableStateOf(false) }

    // Navigation events triggered by AI
    LaunchedEffect(Unit) {
        viewModel.navigationEvent.collectLatest { destination ->
            onNavigateToDestination(destination)
        }
    }

    // Auto-scroll to latest message
    val isImeVisible = WindowInsets.isImeVisible
    LaunchedEffect(messages.size, isLoading, isImeVisible) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Voice recognition launcher
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.setInputQuery(spokenText)
                viewModel.sendMessage(spokenText)
            }
        }
    }

    // Full-resolution camera capture. TakePicturePreview is intentionally avoided
    // because its low-resolution preview is poor for receipt OCR.
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        pendingCameraUri = null

        if (success && uri != null) {
            val bitmap = loadBitmapFromUri(context, uri)
            if (bitmap != null) {
                viewModel.setSelectedImage(bitmap)
            }
        } else if (uri != null) {
            try {
                context.contentResolver.delete(uri, null, null)
            } catch (_: Exception) {
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                val (uri, _) = ReceiptImageStorage.createTempPictureUri(context)
                pendingCameraUri = uri
                cameraLauncher.launch(uri)
            } catch (_: Exception) {
                pendingCameraUri = null
            }
        }
    }

    // Photo picker (Gallery) launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = loadBitmapFromUri(context, uri)
            if (bitmap != null) {
                viewModel.setSelectedImage(bitmap)
            }
        }
    }

    val samplePrompts = listOf(
        "🌐 Herbalife Formula 1 Official Info & MRP",
        "🌐 Afresh Drink ingredients & directions",
        "🌐 Personalized Protein Powder facts",
        "Formula 1 ka stock kitna hai?",
        "Aaj kitni sale hui?",
        "Is month ka profit batao",
        "Sell 2 Formula 1 at 1800"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
            .testTag("ai_assistant_screen")
    ) {
        // Top action bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(ForestGreenPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = ForestGreenPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "AI Business Assistant",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Reads local DB • Live Official Web Research • Strict Confirmation",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = { showAiLogDialog = true },
                    modifier = Modifier.testTag("ai_history_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "AI History Log",
                        tint = ForestGreenPrimary
                    )
                }
            }
        }

        // Suggestion Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            samplePrompts.forEach { prompt ->
                SuggestionChip(
                    onClick = { viewModel.sendMessage(prompt) },
                    label = { Text(prompt, style = MaterialTheme.typography.labelSmall) },
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageItem(
                    message = msg,
                    onConfirmReceipt = { draft -> viewModel.confirmReceiptReviewDraft(draft, msg.id) },
                    onUpdateReceiptItem = { idx, item -> viewModel.updateReceiptDraftItem(msg.id, idx, item) },
                    onConfirmPurchase = { draft -> viewModel.confirmPurchaseDraft(draft, msg.id) },
                    onConfirmSale = { draft -> viewModel.confirmSaleDraft(draft, msg.id) },
                    onConfirmCreateProduct = { draft -> viewModel.confirmCreateProductDraft(draft, msg.id) },
                    onConfirmEdit = { draft -> viewModel.confirmEditDraft(draft, msg.id) },
                    onConfirmDelete = { draft -> viewModel.confirmDeleteDraft(draft, msg.id) },
                    onConfirmSettings = { draft -> viewModel.confirmSettingsDraft(draft, msg.id) },
                    onCancel = { title -> viewModel.cancelDraft(msg.id, title) }
                )
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSearchingWeb) ForestGreenPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSearchingWeb) BorderStroke(1.dp, ForestGreenPrimary.copy(alpha = 0.5f)) else null,
                            modifier = Modifier.testTag(if (isSearchingWeb) "ai_web_research_indicator" else "ai_loading_indicator")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = if (isSearchingWeb) ForestGreenPrimary else MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (isSearchingWeb) "🌐 Web Research: Searching herbalife.co.in & official sources..." else "Analyzing receipt / query...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isSearchingWeb) ForestGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (isSearchingWeb) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }

        // Image Attachment Preview Banner (if image is selected)
        selectedImage?.let { attachedBitmap ->
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            bitmap = attachedBitmap.asImageBitmap(),
                            contentDescription = "Selected Receipt",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, ForestGreenPrimary, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Receipt image attached",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "Tap Send to extract items & stock",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.clearSelectedImage() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove attached image",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // Input bar positioned directly above bottom navigation or keyboard with a clean small gap
        Surface(
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 4.dp)
                .testTag("ai_input_bar_surface")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Camera Button
                IconButton(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED

                        if (granted) {
                            try {
                                val (uri, _) = ReceiptImageStorage.createTempPictureUri(context)
                                pendingCameraUri = uri
                                cameraLauncher.launch(uri)
                            } catch (_: Exception) {
                                pendingCameraUri = null
                            }
                        } else {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ForestGreenPrimary.copy(alpha = 0.12f))
                        .testTag("ai_camera_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Capture Invoice",
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Gallery Button
                IconButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ForestGreenPrimary.copy(alpha = 0.12f))
                        .testTag("ai_gallery_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Upload Receipt Image",
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Voice Mic Button
                IconButton(
                    onClick = {
                        try {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye (Speak in Hindi/English)...")
                            }
                            voiceLauncher.launch(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ForestGreenPrimary.copy(alpha = 0.12f))
                        .testTag("ai_mic_button")
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Text Input
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { viewModel.setInputQuery(it) },
                    placeholder = {
                        Text(
                            text = if (selectedImage != null) "Optional prompt or tap send..." else "Ask or command...",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 3,
                    singleLine = false
                )

                // Send Button
                val canSend = inputQuery.isNotBlank() || selectedImage != null
                IconButton(
                    onClick = {
                        if (canSend) {
                            viewModel.sendMessage(inputQuery)
                        }
                    },
                    enabled = canSend,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (canSend) ForestGreenPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
                        .testTag("ai_send_button")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (canSend) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    // AI Activity Log Dialog
    if (showAiLogDialog) {
        AiActionLogDialog(
            logs = aiLogs,
            onDismiss = { showAiLogDialog = false },
            onClearLogs = {
                coroutineScope.launch {
                    // Logs can be cleared from settings or repository
                }
            }
        )
    }
}

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    onConfirmReceipt: (ReceiptReviewDraft) -> Unit,
    onUpdateReceiptItem: (Int, DraftPurchaseItem) -> Unit,
    onConfirmPurchase: (DraftPurchaseAction) -> Unit,
    onConfirmSale: (DraftSaleAction) -> Unit,
    onConfirmCreateProduct: (DraftCreateProductAction) -> Unit,
    onConfirmEdit: (DraftEditProductAction) -> Unit,
    onConfirmDelete: (DraftDeleteAction) -> Unit,
    onConfirmSettings: (DraftUpdateSettingsAction) -> Unit,
    onCancel: (String) -> Unit
) {
    val isUser = message.sender == MessageSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) ForestGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 1.dp,
            modifier = Modifier.widthIn(max = 350.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Attached image thumbnail in message
                if (message.imageBitmap != null) {
                    Image(
                        bitmap = message.imageBitmap.asImageBitmap(),
                        contentDescription = "Attached receipt",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Web Researched Badge
                if (message.isWebResearched) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ForestGreenPrimary.copy(alpha = 0.12f),
                        modifier = Modifier
                            .padding(bottom = 6.dp)
                            .testTag("ai_web_researched_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = "Web Researched",
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Live Web Research • Official Sources",
                                style = MaterialTheme.typography.labelSmall,
                                color = ForestGreenPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Sources Section
                if (message.citations.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    WebSourcesSection(citations = message.citations)
                }

                // Interactive Confirmation Action Cards
                val actionToRender = message.actionResponse ?: message.suggestedCatalogAction
                when (val action = actionToRender) {
                    is AiAssistantResponse.ConfirmReceiptReview -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        ReceiptReviewConfirmationCard(
                            draft = action.receiptDraft,
                            onConfirm = { onConfirmReceipt(action.receiptDraft) },
                            onEditItem = { idx, item -> onUpdateReceiptItem(idx, item) },
                            onCancel = { onCancel("Receipt Purchase") }
                        )
                    }
                    is AiAssistantResponse.ConfirmPurchase -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        PurchaseConfirmationCard(
                            draft = action.draft,
                            onConfirm = { onConfirmPurchase(action.draft) },
                            onCancel = { onCancel("Purchase Import") }
                        )
                    }
                    is AiAssistantResponse.ConfirmSale -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        SaleConfirmationCard(
                            draft = action.draft,
                            onConfirm = { onConfirmSale(action.draft) },
                            onCancel = { onCancel("Sale Entry") }
                        )
                    }
                    is AiAssistantResponse.ConfirmCreateProduct -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        CreateProductConfirmationCard(
                            draft = action.draft,
                            onConfirm = { onConfirmCreateProduct(action.draft) },
                            onCancel = { onCancel("Create Product") }
                        )
                    }
                    is AiAssistantResponse.ConfirmEdit -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        EditConfirmationCard(
                            draft = action.draft,
                            onConfirm = { onConfirmEdit(action.draft) },
                            onCancel = { onCancel("Edit Product") }
                        )
                    }
                    is AiAssistantResponse.ConfirmDelete -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        DeleteConfirmationActionCard(
                            draft = action.draft,
                            onConfirm = { onConfirmDelete(action.draft) },
                            onCancel = { onCancel("Delete Item") }
                        )
                    }
                    is AiAssistantResponse.ConfirmSettingsChange -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        SettingsConfirmationCard(
                            draft = action.draft,
                            onConfirm = { onConfirmSettings(action.draft) },
                            onCancel = { onCancel("Settings Change") }
                        )
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun WebSourcesSection(citations: List<WebCitation>) {
    val context = LocalContext.current
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_sources_card")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = null,
                    tint = ForestGreenPrimary,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "Sources & Official Links",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            citations.forEachIndexed { index, citation ->
                Surface(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(citation.url))
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .testTag("ai_source_link_${index}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = citation.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${citation.sourceName} • ${citation.url.take(45)}...",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Open Source Link",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

// 4. Receipt / Invoice Reading Confirmation Card
@Composable
fun ReceiptReviewConfirmationCard(
    draft: ReceiptReviewDraft,
    onConfirm: () -> Unit,
    onEditItem: (Int, DraftPurchaseItem) -> Unit,
    onCancel: () -> Unit
) {
    var editingItemIndex by remember { mutableStateOf<Int?>(null) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_receipt_confirmation_card")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🧾 Scanned Invoice Review",
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary,
                    style = MaterialTheme.typography.titleSmall
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ForestGreenPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = draft.invoiceNumber,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreenPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = "Supplier: ${draft.detectedStoreOrSupplier}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            // Detected items list
            draft.items.forEachIndexed { index, item ->
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.needsReview) Color(0xFFFFF8E1) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${index + 1}. ${item.productName}",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            if (item.needsReview) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFF9800)
                                ) {
                                    Text(
                                        text = "Needs Review",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Qty: ${item.quantity} | MRP: ₹%.2f".format(item.mrp), style = MaterialTheme.typography.labelSmall)
                            Text("Disc: %.0f%% | GST: %.0f%%".format(item.discountPercentage, item.taxPercentage), style = MaterialTheme.typography.labelSmall)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Unit: ₹%.2f • Total: ₹%.2f".format(item.finalPricePerUnit, item.totalAmount),
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenPrimary,
                                style = MaterialTheme.typography.bodySmall
                            )

                            TextButton(
                                onClick = { editingItemIndex = index },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Edit", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            HorizontalDivider()

            val grandTotal = draft.items.sumOf { it.totalAmount }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Total Payable:", fontWeight = FontWeight.Bold)
                Text("₹%.2f".format(grandTotal), fontWeight = FontWeight.ExtraBold, color = ForestGreenPrimary)
            }

            val canConfirm = draft.items.isNotEmpty() && draft.items.none { it.needsReview }

            if (!canConfirm) {
                Text(
                    text = "⚠️ Highlighted rows need review. Edit them before adding anything to stock.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onConfirm,
                    enabled = canConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("ai_confirm_receipt_btn")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Confirm & Add to Stock", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    // Dialog to edit detected receipt item values
    editingItemIndex?.let { idx ->
        if (idx in draft.items.indices) {
            EditReceiptItemDialog(
                item = draft.items[idx],
                onDismiss = { editingItemIndex = null },
                onSave = { updatedItem ->
                    onEditItem(idx, updatedItem)
                    editingItemIndex = null
                }
            )
        }
    }
}

@Composable
fun EditReceiptItemDialog(
    item: DraftPurchaseItem,
    onDismiss: () -> Unit,
    onSave: (DraftPurchaseItem) -> Unit
) {
    var name by remember { mutableStateOf(item.productName) }
    var qtyStr by remember { mutableStateOf(item.quantity.toString()) }
    var mrpStr by remember { mutableStateOf(item.mrp.toString()) }
    var discStr by remember { mutableStateOf(item.discountPercentage.toString()) }
    var taxStr by remember { mutableStateOf(item.taxPercentage.toString()) }
    var finalPriceStr by remember { mutableStateOf(item.finalPricePerUnit.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Scanned Item", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyStr,
                        onValueChange = { qtyStr = it },
                        label = { Text("Quantity") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = mrpStr,
                        onValueChange = { mrpStr = it },
                        label = { Text("MRP (₹)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = discStr,
                        onValueChange = { discStr = it },
                        label = { Text("Discount %") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = taxStr,
                        onValueChange = { taxStr = it },
                        label = { Text("Tax %") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = finalPriceStr,
                    onValueChange = { finalPriceStr = it },
                    label = { Text("Final Unit Cost (₹)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = qtyStr.toIntOrNull() ?: item.quantity
                    val m = mrpStr.toDoubleOrNull() ?: item.mrp
                    val d = discStr.toDoubleOrNull() ?: item.discountPercentage
                    val t = taxStr.toDoubleOrNull() ?: item.taxPercentage
                    val fp = finalPriceStr.toDoubleOrNull() ?: item.finalPricePerUnit
                    val total = fp * q

                    onSave(
                        item.copy(
                            productName = name.trim().ifBlank { item.productName },
                            quantity = q,
                            mrp = m,
                            discountPercentage = d,
                            taxPercentage = t,
                            finalPricePerUnit = fp,
                            totalAmount = total,
                            needsReview = false
                        )
                    )
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateProductConfirmationCard(
    draft: DraftCreateProductAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_create_product_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("📦 Confirm New Product", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
            Text("Product: ${draft.name}", fontWeight = FontWeight.SemiBold)
            Text("Selling Price: ₹%.2f | MRP: ₹%.2f".format(draft.sellingPrice, draft.mrp), style = MaterialTheme.typography.bodySmall)
            Text("Initial Stock: ${draft.currentStock} units | Points: %.2f".format(draft.points), style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("ai_confirm_create_btn")
                ) {
                    Text("Confirm Create", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun SettingsConfirmationCard(
    draft: DraftUpdateSettingsAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_settings_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("⚙️ Confirm Settings Change", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
            Text("Setting: ${draft.settingName}", fontWeight = FontWeight.SemiBold)
            Text("Change to: ${draft.newValue}", color = ForestGreenPrimary, fontWeight = FontWeight.Bold)

            HorizontalDivider()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Apply Setting", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun PurchaseConfirmationCard(
    draft: DraftPurchaseAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_purchase_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📦 Review Purchase Entry", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                if (draft.invoiceNumber.isNotBlank()) {
                    Surface(
                        color = ForestGreenPrimary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = draft.invoiceNumber,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            draft.items.forEachIndexed { idx, item ->
                HorizontalDivider()
                Text("${idx + 1}. ${item.productName}", fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Qty: ${item.quantity} units | MRP: ₹%.2f".format(item.mrp), style = MaterialTheme.typography.bodySmall)
                    if (item.discountPercentage > 0) {
                        Text("Disc: %.1f%% (-₹%.2f)".format(item.discountPercentage, item.discountAmount), style = MaterialTheme.typography.bodySmall)
                    }
                }

                // Selected GST Type & Tax Details
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("GST Type:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (item.gstType == "FIXED_AMOUNT") "Fixed Amount (₹)" else "Percentage (%)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("GST Value:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (item.gstType == "FIXED_AMOUNT") "₹%.2f".format(item.gstFixedAmount) else "%.1f%%".format(item.taxPercentage),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Calculated Tax Amount:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹%.2f".format(item.taxAmount), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Final Unit Cost: ₹%.2f".format(item.finalPricePerUnit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Text("Total Amount: ₹%.2f".format(item.totalAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                }
            }

            HorizontalDivider()

            val grandTotal = draft.items.sumOf { it.totalAmount }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total Purchase Amount:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text("₹%.2f".format(grandTotal), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = ForestGreenPrimary)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("ai_confirm_purchase_btn")
                ) {
                    Text("Confirm Purchase", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun SaleConfirmationCard(
    draft: DraftSaleAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_sale_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("💰 Review Sale Entry", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)

            // Customer Details section
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(14.dp))
                        Text(
                            text = "Customer: ${draft.customerName ?: "Walk-in Customer"}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (!draft.customerContact.isNullOrBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                            Text("Phone: ${draft.customerContact}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (!draft.customerEmail.isNullOrBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                            Text("Email: ${draft.customerEmail}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (!draft.customerAddress.isNullOrBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                            Text("Address: ${draft.customerAddress}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Text("Product: ${draft.productName}", fontWeight = FontWeight.SemiBold)
            Text("Quantity: ${draft.quantity} units", style = MaterialTheme.typography.bodySmall)
            Text("Selling Price: ₹%.2f per unit".format(draft.sellingPrice), style = MaterialTheme.typography.bodySmall)
            if (draft.discountPercentage > 0) {
                Text("Discount: %.1f%% (-₹%.2f)".format(draft.discountPercentage, draft.discountAmount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
            if (draft.gstAmount > 0) {
                val gstLabel = if (draft.gstType == "FIXED_AMOUNT") "Fixed GST ₹%.2f".format(draft.gstFixedAmount) else "GST %.1f%%".format(draft.gstPercentage)
                Text("Tax: $gstLabel (+₹%.2f)".format(draft.gstAmount), style = MaterialTheme.typography.bodySmall, color = ForestGreenPrimary)
            }
            Text("Final Unit Price: ₹%.2f".format(draft.finalSellingPrice), style = MaterialTheme.typography.bodySmall)
            Text("Total Sale Amount: ₹%.2f".format(draft.totalSaleAmount), fontWeight = FontWeight.Bold, color = ForestGreenPrimary)

            HorizontalDivider()

            Text("Purchase Cost: ₹%.2f".format(draft.unitPurchaseCost * draft.quantity), style = MaterialTheme.typography.bodySmall)
            Text("Net Profit: ₹%.2f".format(draft.profit), fontWeight = FontWeight.Bold, color = ProfitGreen)
            Text("Points Earned: %.2f pts".format(draft.points), fontWeight = FontWeight.SemiBold, color = PointsGold)
            Text("Remaining Stock: ${draft.remainingStock} units", style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("ai_confirm_sale_btn")
                ) {
                    Text("Confirm Sale", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun EditConfirmationCard(
    draft: DraftEditProductAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_edit_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("✏️ Confirm Product Change", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)

            Text("Product: ${draft.productName}", fontWeight = FontWeight.SemiBold)
            Text("Field: ${draft.fieldName}", style = MaterialTheme.typography.bodySmall)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Old Value: ${draft.oldValue}", color = MaterialTheme.colorScheme.outline)
                Text("➡️", style = MaterialTheme.typography.bodySmall)
                Text("New Value: ${draft.newValue}", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
            }

            HorizontalDivider()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("ai_confirm_edit_btn")
                ) {
                    Text("Confirm Change", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun DeleteConfirmationActionCard(
    draft: DraftDeleteAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("⚠️ Confirm Deletion", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            Text("Target: ${draft.title}")
            Text("Quantity: ${draft.quantityStr} | Amount: ${draft.amountStr}", style = MaterialTheme.typography.bodySmall)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.height(36.dp)) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Confirm Delete", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return try {
        val maxDim = 1600
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.isMutableRequired = true
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                if (w > maxDim || h > maxDim) {
                    val sample = maxOf(1, maxOf(w / maxDim, h / maxDim))
                    decoder.setTargetSampleSize(sample)
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, bounds)
            }
            val sample = if (bounds.outWidth > maxDim || bounds.outHeight > maxDim) {
                maxOf(1, maxOf(bounds.outWidth / maxDim, bounds.outHeight / maxDim))
            } else 1
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, opts)
            }
        }
    } catch (_: Throwable) {
        null
    }
}
