package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.StockMovement
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class HistoryTab(val label: String) {
    PURCHASES("Purchases"),
    SALES("Sales"),
    STOCK("Stock Movements"),
    PROFIT("Profit History"),
    POINTS("Points History")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: NutritionViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(HistoryTab.SALES) }
    var searchQuery by remember { mutableStateOf("") }
    var sortDescending by remember { mutableStateOf(true) }

    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val movements by viewModel.movements.collectAsStateWithLifecycle()

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("history_screen")
    ) {
        // Scrollable Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab.ordinal,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = ForestGreenPrimary
        ) {
            HistoryTab.values().forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    text = {
                        Text(
                            text = tab.label,
                            fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        // Search and Sort controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter history...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            IconButton(
                onClick = { sortDescending = !sortDescending }
            ) {
                Icon(
                    if (sortDescending) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    contentDescription = "Sort order"
                )
            }
        }

        // Content
        when (selectedTab) {
            HistoryTab.PURCHASES -> {
                val list = purchases
                    .filter { it.productName.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { if (sortDescending) -it.purchaseDate else it.purchaseDate }

                if (list.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Default.History,
                        title = "No Purchase Records",
                        description = "Purchase transactions will appear here."
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.id }) { p ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(p.productName, fontWeight = FontWeight.Bold)
                                        Text(dateFormat.format(Date(p.purchaseDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                        Text("Qty: ${p.quantity} @ ₹%.2f".format(p.finalPricePerUnit), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("₹%.2f".format(p.totalAmount), fontWeight = FontWeight.Bold, color = StockBlue)
                                        if (p.invoiceNumber.isNotBlank()) {
                                            Text("Inv: ${p.invoiceNumber}", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HistoryTab.SALES -> {
                val list = sales
                    .filter { it.productName.contains(searchQuery, ignoreCase = true) || (it.customerName?.contains(searchQuery, ignoreCase = true) == true) }
                    .sortedBy { if (sortDescending) -it.saleDate else it.saleDate }

                if (list.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Default.History,
                        title = "No Sales Records",
                        description = "Sales transactions will appear here."
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.id }) { s ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(s.productName, fontWeight = FontWeight.Bold)
                                        Text("${dateFormat.format(Date(s.saleDate))} • ${s.customerName ?: "Customer"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                        Text("Qty: ${s.quantity} • Profit: ₹%.2f".format(s.profit), style = MaterialTheme.typography.bodySmall, color = ProfitGreen)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("₹%.2f".format(s.totalSaleAmount), fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                        Text("%.2f pts".format(s.totalPoints), style = MaterialTheme.typography.labelSmall, color = PointsGold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HistoryTab.STOCK -> {
                val list = movements
                    .filter { it.productName.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { if (sortDescending) -it.timestamp else it.timestamp }

                if (list.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Default.SwapVert,
                        title = "No Stock Movements",
                        description = "Stock changes from purchases and sales will appear here."
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.id }) { m ->
                            val isAddition = m.quantityChange > 0
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(m.productName, fontWeight = FontWeight.Bold)
                                        Text(dateFormat.format(Date(m.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                        Text("Type: ${m.movementType} ${if (m.notes.isNotBlank()) "• ${m.notes}" else ""}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${if (isAddition) "+" else ""}${m.quantityChange} units",
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAddition) ForestGreenPrimary else MaterialTheme.colorScheme.error
                                        )
                                        Text("Bal: ${m.remainingStock}", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HistoryTab.PROFIT -> {
                val list = sales
                    .filter { it.productName.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { if (sortDescending) -it.profit else it.profit }

                val totalProfit = list.sumOf { it.profit }

                Column(modifier = Modifier.fillMaxSize()) {
                    Surface(color = ProfitGreen.copy(alpha = 0.1f), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Net Profit", fontWeight = FontWeight.Bold, color = ProfitGreen)
                            Text("₹%.2f".format(totalProfit), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = ProfitGreen)
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.id }) { s ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(s.productName, fontWeight = FontWeight.Bold)
                                        Text(dateFormat.format(Date(s.saleDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                        Text("Sale: ₹%.2f - Cost: ₹%.2f".format(s.totalSaleAmount, s.totalPurchaseCost), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text("Profit: ₹%.2f".format(s.profit), fontWeight = FontWeight.Bold, color = ProfitGreen)
                                }
                            }
                        }
                    }
                }
            }

            HistoryTab.POINTS -> {
                val list = purchases
                    .filter { it.productName.contains(searchQuery, ignoreCase = true) || it.invoiceNumber.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { if (sortDescending) -it.totalPoints else it.totalPoints }

                val totalPts = list.sumOf { it.totalPoints }

                Column(modifier = Modifier.fillMaxSize()) {
                    Surface(color = PointsGold.copy(alpha = 0.12f), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Volume Points Earned", fontWeight = FontWeight.Bold, color = PointsGold)
                                Text("Accumulated from stock purchases", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("%.2f pts".format(totalPts), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = PointsGold)
                        }
                    }

                    if (list.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.Stars,
                            title = "No Purchase Points Records",
                            description = "Purchases with Volume Points will appear here"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(list, key = { it.id }) { p ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(p.productName, fontWeight = FontWeight.Bold)
                                            Text(dateFormat.format(Date(p.purchaseDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                            Text("Qty: ${p.quantity} @ %.2f pts/unit".format(p.pointsPerUnit), style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text("%.2f pts".format(p.totalPoints), fontWeight = FontWeight.Bold, color = PointsGold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
