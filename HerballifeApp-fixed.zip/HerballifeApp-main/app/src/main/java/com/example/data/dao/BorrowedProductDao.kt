package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BorrowedProduct
import kotlinx.coroutines.flow.Flow

@Dao
interface BorrowedProductDao {
    @Query("SELECT * FROM borrowed_products ORDER BY dateReceived DESC")
    fun getAllBorrowedProducts(): Flow<List<BorrowedProduct>>

    @Query("SELECT * FROM borrowed_products ORDER BY dateReceived DESC")
    suspend fun getAllBorrowedProductsList(): List<BorrowedProduct>

    @Query("SELECT * FROM borrowed_products WHERE id = :id LIMIT 1")
    suspend fun getBorrowedProductById(id: Long): BorrowedProduct?

    @Query("SELECT * FROM borrowed_products WHERE productId = :productId ORDER BY dateReceived DESC")
    fun getBorrowedForProduct(productId: Long): Flow<List<BorrowedProduct>>

    @Query("SELECT * FROM borrowed_products WHERE productId = :productId ORDER BY dateReceived DESC")
    suspend fun getBorrowedForProductList(productId: Long): List<BorrowedProduct>

    @Query("SELECT * FROM borrowed_products WHERE status != 'RETURNED' AND status != 'SETTLED' ORDER BY dateReceived DESC")
    fun getActiveBorrowedProducts(): Flow<List<BorrowedProduct>>

    @Query("SELECT * FROM borrowed_products WHERE status != 'RETURNED' AND status != 'SETTLED' ORDER BY dateReceived DESC")
    suspend fun getActiveBorrowedProductsList(): List<BorrowedProduct>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(borrowed: BorrowedProduct): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(borrowedList: List<BorrowedProduct>): List<Long>

    @Update
    suspend fun update(borrowed: BorrowedProduct)

    @Delete
    suspend fun delete(borrowed: BorrowedProduct)

    @Query("DELETE FROM borrowed_products")
    suspend fun deleteAll()
}
