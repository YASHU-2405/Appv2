package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiAssistantResponse
import com.example.data.ai.DraftCreateProductAction
import com.example.data.ai.DraftDeleteAction
import com.example.data.ai.DraftEditProductAction
import com.example.data.ai.DraftPurchaseAction
import com.example.data.ai.DraftPurchaseItem
import com.example.data.ai.DraftSaleAction
import com.example.data.ai.DraftUpdateSettingsAction
import com.example.data.ai.NaturalLanguageProcessor
import com.example.data.ai.ReceiptReviewDraft
import com.example.data.ai.WebCitation
import com.example.data.database.AppDatabase
import com.example.data.model.AiLog
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.PurchaseOrder
import com.example.data.model.Sale
import com.example.data.preferences.AppSettingsManager
import com.example.data.preferences.ThemeMode
import com.example.data.repository.NutritionRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionResponse: AiAssistantResponse? = null,
    val imageBitmap: Bitmap? = null,
    val citations: List<WebCitation> = emptyList(),
    val isWebResearched: Boolean = false,
    val suggestedCatalogAction: AiAssistantResponse? = null
)

enum class MessageSender { USER, AI }

class AiAssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NutritionRepository
    private val nlp: NaturalLanguageProcessor
    private val settingsManager: AppSettingsManager

    init {
        val db = AppDatabase.getDatabase(application)
        repository = NutritionRepository(db)
        settingsManager = AppSettingsManager.getInstance(application)
        nlp = NaturalLanguageProcessor(repository, settingsManager)
    }

    val allAiLogs: Flow<List<AiLog>> = repository.allAiLogs

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.AI,
                text = "Namaste! I am your Onest Nutrition Business AI Assistant.\n\n" +
                        "• 🌐 Web Research: Ask about any Herbalife product for official Indian specs, live price (MRP), ingredients, directions, & label warnings.\n" +
                        "• 📷 Scan Invoices: Upload purchase bills to auto-extract items & stock with confirmation.\n" +
                        "• 📊 Real-time Data: Query your real stock, sales, revenue, profit, & points.\n" +
                        "• 🔒 Full Safety: Read-only live web search; data changes require explicit [CONFIRM] tap."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSearchingWeb = MutableStateFlow(false)
    val isSearchingWeb: StateFlow<Boolean> = _isSearchingWeb.asStateFlow()

    private val _inputQuery = MutableStateFlow("")
    val inputQuery: StateFlow<String> = _inputQuery.asStateFlow()

    private val _selectedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedImageBitmap: StateFlow<Bitmap?> = _selectedImageBitmap.asStateFlow()

    private val _navigationEvent = MutableSharedFlow<String>()
    val navigationEvent: SharedFlow<String> = _navigationEvent.asSharedFlow()

    fun setInputQuery(q: String) {
        _inputQuery.value = q
    }

    fun setSelectedImage(bitmap: Bitmap?) {
        _selectedImageBitmap.value = bitmap
    }

    fun clearSelectedImage() {
        _selectedImageBitmap.value = null
    }

    fun sendMessage(query: String) {
        val q = query.trim()
        val currentImage = _selectedImageBitmap.value
        if (q.isEmpty() && currentImage == null) return

        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = if (q.isNotEmpty()) q else "Uploaded receipt image for scanning",
            imageBitmap = currentImage
        )
        _messages.value = _messages.value + userMsg
        _inputQuery.value = ""
        _selectedImageBitmap.value = null

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = if (currentImage != null) {
                    nlp.processUserCommandWithImage(q, currentImage)
                } else {
                    nlp.processUserCommand(q, onSearchingWeb = { _isSearchingWeb.value = it })
                }

                when (response) {
                    is AiAssistantResponse.TextMessage -> {
                        _messages.value = _messages.value + ChatMessage(
                            sender = MessageSender.AI,
                            text = response.message,
                            citations = response.citations,
                            isWebResearched = response.isWebResearched,
                            suggestedCatalogAction = response.suggestedCatalogAction
                        )
                        repository.insertAiLog(
                            AiLog(
                                userCommand = if (q.isNotBlank()) q else "Image inquiry",
                                detectedAction = if (response.isWebResearched) "Web Research" else "Read-only Query",
                                status = "Read-only",
                                resultSummary = response.message.take(120)
                            )
                        )
                    }
                    is AiAssistantResponse.Navigate -> {
                        _messages.value = _messages.value + ChatMessage(
                            sender = MessageSender.AI,
                            text = response.action.message
                        )
                        _navigationEvent.emit(response.action.destination)
                        repository.insertAiLog(
                            AiLog(
                                userCommand = q,
                                detectedAction = "Navigate -> ${response.action.destination}",
                                status = "Executed",
                                resultSummary = "Navigated to ${response.action.destination}"
                            )
                        )
                    }
                    else -> {
                        // Actions requiring explicit confirmation
                        val actionName = when (response) {
                            is AiAssistantResponse.ConfirmPurchase -> "Add Purchase"
                            is AiAssistantResponse.ConfirmReceiptReview -> "Scan Receipt & Purchase"
                            is AiAssistantResponse.ConfirmSale -> "Add Sale"
                            is AiAssistantResponse.ConfirmCreateProduct -> "Create Product"
                            is AiAssistantResponse.ConfirmEdit -> "Edit Product"
                            is AiAssistantResponse.ConfirmDelete -> "Delete Item"
                            is AiAssistantResponse.ConfirmSettingsChange -> "Update Settings"
                            else -> "Action"
                        }
                        val promptText = when (response) {
                            is AiAssistantResponse.ConfirmPurchase -> response.message
                            is AiAssistantResponse.ConfirmReceiptReview -> response.message
                            is AiAssistantResponse.ConfirmSale -> response.message
                            is AiAssistantResponse.ConfirmCreateProduct -> response.message
                            is AiAssistantResponse.ConfirmEdit -> response.message
                            is AiAssistantResponse.ConfirmDelete -> response.message
                            is AiAssistantResponse.ConfirmSettingsChange -> response.message
                            else -> "Action requires your confirmation:"
                        }

                        _messages.value = _messages.value + ChatMessage(
                            sender = MessageSender.AI,
                            text = promptText,
                            actionResponse = response
                        )
                    }
                }
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "Koshish mein error aayi: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateReceiptDraftItem(messageId: String, itemIndex: Int, updatedItem: DraftPurchaseItem) {
        val currentMsg = _messages.value.find { it.id == messageId } ?: return
        val currentReceiptAction = currentMsg.actionResponse as? AiAssistantResponse.ConfirmReceiptReview ?: return
        val currentDraft = currentReceiptAction.receiptDraft

        val newItems = currentDraft.items.toMutableList()
        if (itemIndex in newItems.indices) {
            newItems[itemIndex] = updatedItem
            val updatedDraft = currentDraft.copy(items = newItems)
            updateMessageAction(
                messageId,
                AiAssistantResponse.ConfirmReceiptReview(updatedDraft, currentReceiptAction.message)
            )
        }
    }

    fun confirmReceiptReviewDraft(draft: ReceiptReviewDraft, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val allProds = repository.getAllProductsList()
                val purchases = mutableListOf<Purchase>()

                for (item in draft.items) {
                    // A receipt import is allowed to change stock only after every
                    // required value has been reviewed and the item maps to a real
                    // catalog product. Never invent a product or a selling price here.
                    if (item.needsReview) {
                        throw IllegalStateException(
                            "Review required for '${item.productName}'. Edit the highlighted receipt row before confirming."
                        )
                    }
                    if (item.quantity <= 0 || item.finalPricePerUnit <= 0.0 || item.totalAmount <= 0.0) {
                        throw IllegalStateException(
                            "Invalid quantity/price for '${item.productName}'. Please edit the receipt row."
                        )
                    }

                    var prodId = item.matchedProductId
                    if (prodId == null && item.sku.isNotBlank()) {
                        prodId = allProds.firstOrNull {
                            it.sku.equals(item.sku, ignoreCase = true)
                        }?.id
                    }
                    if (prodId == null) {
                        prodId = allProds.firstOrNull {
                            it.name.equals(item.productName, ignoreCase = true)
                        }?.id
                    }
                    if (prodId == null) {
                        throw IllegalStateException(
                            "Product '${item.productName}' is not in your catalog. Add/select the product first; receipt import will not create guessed catalog data."
                        )
                    }

                    val catalogProduct = allProds.firstOrNull { it.id == prodId }
                        ?: throw IllegalStateException("Selected product no longer exists.")

                    val purchase = Purchase(
                        productId = prodId,
                        productName = catalogProduct.name,
                        quantity = item.quantity,
                        mrp = item.mrp,
                        originalPrice = item.originalPrice,
                        discountPercentage = item.discountPercentage,
                        discountAmount = item.discountAmount,
                        gstType = item.gstType,
                        gstFixedAmount = item.gstFixedAmount,
                        taxPercentage = item.taxPercentage,
                        taxAmount = item.taxAmount,
                        finalPricePerUnit = item.finalPricePerUnit,
                        totalAmount = item.totalAmount,
                        invoiceNumber = draft.invoiceNumber,
                        supplierName = draft.detectedStoreOrSupplier,
                        notes = "Receipt Scan (${draft.detectedStoreOrSupplier})"
                    )
                    purchases.add(purchase)
                }

                if (purchases.isEmpty()) {
                    throw IllegalStateException("No verified receipt items were available to add.")
                }

                val totalQuantity = purchases.sumOf { it.quantity }
                val totalOriginalAmount = purchases.sumOf { it.originalPrice * it.quantity }
                val totalDiscountAmount = purchases.sumOf { it.discountAmount * it.quantity }
                val totalGstAmount = purchases.sumOf { it.taxAmount * it.quantity }
                val finalPurchaseAmount = purchases.sumOf { it.totalAmount }
                val totalPoints = purchases.sumOf { it.totalPoints }

                val order = PurchaseOrder(
                    orderNumber = "PO-${System.currentTimeMillis() % 100000}",
                    invoiceNumber = draft.invoiceNumber,
                    supplierName = draft.detectedStoreOrSupplier,
                    purchaseDate = System.currentTimeMillis(),
                    totalProducts = purchases.size,
                    totalQuantity = totalQuantity,
                    totalOriginalAmount = totalOriginalAmount,
                    totalDiscountAmount = totalDiscountAmount,
                    totalGstAmount = totalGstAmount,
                    finalPurchaseAmount = finalPurchaseAmount,
                    totalPoints = totalPoints,
                    notes = "Scanned receipt import"
                )

                val result = repository.recordPurchaseOrder(order, purchases)
                result.getOrThrow()

                updateMessageAction(messageId, null)

                val summary = "Scanned ${purchases.size} verified item(s) from invoice ${draft.invoiceNumber}. Stock updated."
                repository.insertAiLog(
                    AiLog(
                        userCommand = "Receipt scan confirm: ${draft.invoiceNumber}",
                        detectedAction = "Add Purchase (Receipt)",
                        status = "Confirmed",
                        resultSummary = summary
                    )
                )

                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "✅ **Receipt Confirmed & Stock Added!**\n" +
                        "• Invoice: ${draft.invoiceNumber.ifBlank { "Not detected" }}\n" +
                        "• Products Stocked: ${purchases.size}\n" +
                        "• Total Amount: ₹%.2f".format(finalPurchaseAmount)
                )
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Stock was not changed. ${e.message ?: "Please review the receipt data and try again."}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmPurchaseDraft(draft: DraftPurchaseAction, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val allProds = repository.getAllProductsList()
                for (item in draft.items) {
                    var prodId = item.matchedProductId
                    if (prodId == null) {
                        val existing = allProds.find { it.name.equals(item.productName, ignoreCase = true) }
                        if (existing != null) {
                            prodId = existing.id
                        } else {
                            val newProd = Product(
                                name = item.productName,
                                mrp = item.mrp,
                                purchasePrice = item.originalPrice,
                                discountPercentage = item.discountPercentage,
                                gstType = item.gstType,
                                gstFixedAmount = item.gstFixedAmount,
                                taxPercentage = item.taxPercentage,
                                taxAmount = item.taxAmount,
                                finalPurchaseCost = item.finalPricePerUnit,
                                sellingPrice = item.mrp,
                                currentStock = 0,
                                notes = "Imported via AI Assistant"
                            )
                            prodId = repository.insertProduct(newProd)
                        }
                    }

                    val purchase = Purchase(
                        productId = prodId,
                        productName = item.productName,
                        quantity = item.quantity,
                        mrp = item.mrp,
                        originalPrice = item.originalPrice,
                        discountPercentage = item.discountPercentage,
                        discountAmount = item.discountAmount,
                        gstType = item.gstType,
                        gstFixedAmount = item.gstFixedAmount,
                        taxPercentage = item.taxPercentage,
                        taxAmount = item.taxAmount,
                        finalPricePerUnit = item.finalPricePerUnit,
                        totalAmount = item.totalAmount,
                        invoiceNumber = draft.invoiceNumber,
                        notes = "Imported via AI"
                    )
                    repository.recordPurchase(purchase)
                }

                updateMessageAction(messageId, null)

                val summary = "Added ${draft.items.size} product(s) to stock. Total ₹%.2f".format(draft.items.sumOf { it.totalAmount })
                repository.insertAiLog(
                    AiLog(
                        userCommand = "Add purchase draft",
                        detectedAction = "Add Purchase",
                        status = "Confirmed",
                        resultSummary = summary
                    )
                )

                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "✅ **Purchase Successfully Saved!**\n${draft.items.size} products added to purchase history & stock increased."
                )
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Error saving purchase: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmSaleDraft(draft: DraftSaleAction, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val sale = Sale(
                    productId = draft.productId,
                    productName = draft.productName,
                    quantity = draft.quantity,
                    sellingPrice = draft.sellingPrice,
                    discountPercentage = draft.discountPercentage,
                    discountAmount = draft.discountAmount,
                    gstType = draft.gstType,
                    taxPercentage = draft.gstPercentage,
                    gstFixedAmount = draft.gstFixedAmount,
                    gstAmount = draft.gstAmount,
                    finalSellingPrice = draft.finalSellingPrice,
                    totalSaleAmount = draft.totalSaleAmount,
                    unitPurchaseCost = draft.unitPurchaseCost,
                    totalPurchaseCost = draft.unitPurchaseCost * draft.quantity,
                    profit = draft.profit,
                    pointsPerUnit = if (draft.quantity > 0) draft.points / draft.quantity else 0.0,
                    totalPoints = draft.points,
                    customerName = draft.customerName,
                    customerContact = draft.customerContact,
                    customerEmail = draft.customerEmail,
                    customerAddress = draft.customerAddress,
                    notes = "Added via AI Assistant"
                )

                val result = repository.recordSale(sale)
                if (result.isSuccess) {
                    updateMessageAction(messageId, null)

                    val summary = "Sold ${draft.quantity}x ${draft.productName}. Profit: ₹%.2f, Points: %.2f".format(draft.profit, draft.points)
                    repository.insertAiLog(
                        AiLog(
                            userCommand = "Sell ${draft.quantity} ${draft.productName}",
                            detectedAction = "Add Sale",
                            status = "Confirmed",
                            resultSummary = summary
                        )
                    )

                    _messages.value = _messages.value + ChatMessage(
                        sender = MessageSender.AI,
                        text = "✅ **Sale Confirmed & Saved!**\n" +
                                "- Product: ${draft.productName}\n" +
                                "- Quantity: ${draft.quantity}\n" +
                                "- Total Sale: ₹%.2f\n".format(draft.totalSaleAmount) +
                                "- Net Profit: ₹%.2f\n".format(draft.profit) +
                                "- Points Earned: %.2f pts\n".format(draft.points) +
                                "- Remaining Stock: ${draft.remainingStock} units"
                    )
                } else {
                    _messages.value = _messages.value + ChatMessage(
                        sender = MessageSender.AI,
                        text = "❌ Sale failed: ${result.exceptionOrNull()?.message}"
                    )
                }
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Sale failed: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmCreateProductDraft(draft: DraftCreateProductAction, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val newProd = Product(
                    name = draft.name,
                    sku = draft.sku,
                    variant = if (draft.variant.isNotBlank()) draft.variant else "${draft.category} ${draft.size}".trim(),
                    mrp = draft.mrp,
                    purchasePrice = draft.purchasePrice,
                    discountPercentage = draft.discountPercentage,
                    taxPercentage = draft.taxPercentage,
                    finalPurchaseCost = draft.finalPurchaseCost,
                    sellingPrice = draft.sellingPrice,
                    points = draft.points,
                    currentStock = draft.currentStock,
                    minStockAlert = draft.minStockAlert,
                    notes = "Created via AI Assistant"
                )
                val id = repository.insertProduct(newProd)
                updateMessageAction(messageId, null)

                repository.insertAiLog(
                    AiLog(
                        userCommand = "Create product: ${draft.name}",
                        detectedAction = "Create Product",
                        status = "Confirmed",
                        resultSummary = "Product #${id} created: ${draft.name}, Stock: ${draft.currentStock}"
                    )
                )

                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "✅ **Product Added Successfully!**\n" +
                            "• Name: ${draft.name}\n" +
                            "• Selling Price: ₹%.2f\n".format(draft.sellingPrice) +
                            "• Stock: ${draft.currentStock} units\n" +
                            "• Points: %.2f pts".format(draft.points)
                )
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Product creation failed: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmEditDraft(draft: DraftEditProductAction, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                if (draft.newSellingPrice != null) {
                    repository.updateProductSellingPrice(draft.productId, draft.newSellingPrice)
                }
                if (draft.newStock != null) {
                    repository.updateProductStockDirect(draft.productId, draft.newStock, "Updated via AI Assistant")
                }
                if (draft.newPoints != null) {
                    repository.updateProductPoints(draft.productId, draft.newPoints)
                }
                if (draft.newDiscount != null) {
                    repository.updateProductDiscount(draft.productId, draft.newDiscount)
                }
                if (draft.newTax != null) {
                    repository.updateProductTax(draft.productId, draft.newTax)
                }
                if (draft.newMrp != null) {
                    val p = repository.getProductByIdDirect(draft.productId)
                    if (p != null) repository.updateProduct(p.copy(mrp = draft.newMrp))
                }

                updateMessageAction(messageId, null)

                val summary = "Updated ${draft.productName} -> ${draft.fieldName}: ${draft.oldValue} to ${draft.newValue}"
                repository.insertAiLog(
                    AiLog(
                        userCommand = "Edit ${draft.productName} ${draft.fieldName}",
                        detectedAction = "Edit Product",
                        status = "Confirmed",
                        resultSummary = summary
                    )
                )

                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "✅ **${draft.productName}** updated!\n${draft.fieldName}: ${draft.oldValue} ➡️ ${draft.newValue}"
                )
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Update failed: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmDeleteDraft(draft: DraftDeleteAction, messageId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                when (draft.targetType) {
                    "PRODUCT" -> {
                        val prod = repository.getProductByIdDirect(draft.id)
                        if (prod != null) repository.deleteProduct(prod)
                    }
                    "PURCHASE" -> {
                        val purchase = repository.getPurchaseByIdDirect(draft.id)
                        if (purchase != null) repository.deletePurchase(purchase)
                    }
                    "SALE" -> {
                        val sale = repository.getSaleByIdDirect(draft.id)
                        if (sale != null) repository.deleteSale(sale)
                    }
                }
                updateMessageAction(messageId, null)

                repository.insertAiLog(
                    AiLog(
                        userCommand = "Delete ${draft.targetType}: ${draft.title}",
                        detectedAction = "Delete ${draft.targetType}",
                        status = "Confirmed",
                        resultSummary = "Deleted ${draft.title}"
                    )
                )

                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "🗑️ Deleted '${draft.title}' successfully."
                )
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.AI,
                    text = "❌ Delete failed: ${e.message}"
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun confirmSettingsDraft(draft: DraftUpdateSettingsAction, messageId: String) {
        viewModelScope.launch {
            if (draft.newThemeMode != null) {
                val mode = when (draft.newThemeMode.uppercase()) {
                    "DARK" -> ThemeMode.DARK
                    "LIGHT" -> ThemeMode.LIGHT
                    else -> ThemeMode.SYSTEM
                }
                settingsManager.setThemeMode(mode)
            }
            if (draft.newAnimationsEnabled != null) {
                settingsManager.setAnimationsEnabled(draft.newAnimationsEnabled)
            }

            updateMessageAction(messageId, null)

            val summary = "Updated ${draft.settingName} to ${draft.newValue}"
            repository.insertAiLog(
                AiLog(
                    userCommand = "Settings change ${draft.settingName}",
                    detectedAction = "Settings Update",
                    status = "Confirmed",
                    resultSummary = summary
                )
            )

            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.AI,
                text = "✅ **Settings Updated!**\n${draft.settingName} is now set to **${draft.newValue}**."
            )
        }
    }

    fun cancelDraft(messageId: String, commandTitle: String = "Action") {
        updateMessageAction(messageId, null)
        viewModelScope.launch {
            repository.insertAiLog(
                AiLog(
                    userCommand = commandTitle,
                    detectedAction = commandTitle,
                    status = "Cancelled",
                    resultSummary = "User cancelled pending action."
                )
            )
        }
        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.AI,
            text = "Action cancelled. Database mein koi badlaav nahi kiya gaya (No changes made to database)."
        )
    }

    private fun updateMessageAction(messageId: String, newAction: AiAssistantResponse?) {
        _messages.value = _messages.value.map { msg ->
            if (msg.id == messageId) msg.copy(actionResponse = newAction) else msg
        }
    }
}
