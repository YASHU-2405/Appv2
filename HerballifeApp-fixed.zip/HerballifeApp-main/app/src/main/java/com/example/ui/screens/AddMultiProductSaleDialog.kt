package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.SaleLineItemDraft
import com.example.ui.components.DiscountTypeSelector
import com.example.ui.components.GstTypeSelector
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import java.text.SimpleDateFormat
import java.util.*

class MutableSaleDraftItem(
    val product: Product,
    initialQty: Int = 1,
    initialPrice: Double = product.sellingPrice,
    initialDiscType: String = "PERCENTAGE",
    initialDiscVal: Double = 0.0,
    initialGstType: String = product.gstType,
    initialGstVal: Double = if (product.gstType == "PERCENTAGE") product.taxPercentage else product.gstFixedAmount
) {
    var quantityStr by mutableStateOf(initialQty.toString())
    var baseSellingPriceStr by mutableStateOf(if (initialPrice > 0) "%.2f".format(initialPrice) else "%.2f".format(product.mrp))
    var discountType by mutableStateOf(initialDiscType)
    var discountValueStr by mutableStateOf(if (initialDiscVal > 0) "%.2f".format(initialDiscVal) else "0")
    var gstType by mutableStateOf(initialGstType)
    var gstValueStr by mutableStateOf(if (initialGstVal > 0) "%.2f".format(initialGstVal) else "0")

    val quantity: Int get() = (quantityStr.toIntOrNull() ?: 1).coerceAtLeast(1)
    val baseSellingPrice: Double get() = (baseSellingPriceStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val discountValue: Double get() = (discountValueStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val gstValue: Double get() = (gstValueStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    val exceedsStock: Boolean get() = quantity > product.currentStock

    fun toDraft(): SaleLineItemDraft {
        return SaleLineItemDraft(
            product = product,
            quantity = quantity,
            baseSellingPrice = baseSellingPrice,
            discountType = discountType,
            discountValue = discountValue,
            gstType = gstType,
            gstValue = gstValue
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMultiProductSaleDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (
        items: List<SaleLineItemDraft>,
        customerName: String,
        customerContact: String,
        customerEmail: String,
        customerAddress: String,
        saleInvoiceNumber: String,
        saleDateMs: Long,
        amountReceived: Double,
        paymentMethod: String,
        paymentNote: String,
        notes: String
    ) -> Unit
) {
    val context = LocalContext.current

    var customerName by remember { mutableStateOf("") }
    var customerContact by remember { mutableStateOf("") }
    var customerEmail by remember { mutableStateOf("") }
    var customerAddress by remember { mutableStateOf("") }
    var saleInvoiceNumber by remember { mutableStateOf("INV-${System.currentTimeMillis() % 1000000}") }
    var saleDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var notes by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var paymentNote by remember { mutableStateOf("") }

    val cartItems = remember { mutableStateListOf<MutableSaleDraftItem>() }
    var showProductPicker by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Computations
    val drafts = cartItems.map { it.toDraft() }
    val totalOriginalSubtotal = drafts.sumOf { it.baseSubtotal }
    val totalDiscount = drafts.sumOf { it.totalDiscountAmount }
    val totalGst = drafts.sumOf { it.totalGstAmount }
    val grandTotalSale = drafts.sumOf { it.lineTotal }
    val totalProfit = drafts.sumOf { it.lineProfit }
    val totalUnits = drafts.sumOf { it.quantity }

    var amountReceivedStr by remember { mutableStateOf("") }
    var userModifiedReceived by remember { mutableStateOf(false) }

    val receivedAmount = if (userModifiedReceived) {
        amountReceivedStr.toDoubleOrNull() ?: 0.0
    } else {
        grandTotalSale
    }
    val pendingAmount = (grandTotalSale - receivedAmount).coerceAtLeast(0.0)

    val paymentStatus = when {
        receivedAmount >= grandTotalSale - 0.01 -> "PAID"
        receivedAmount <= 0.01 -> "PENDING"
        else -> "PARTIAL"
    }

    val anyItemExceedsStock = cartItems.any { it.exceedsStock }
    val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(saleDateMs))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("New Multi-Product Sale", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Customer purchase & invoice", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = Color.White
                        ),
                        actions = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Total Sale: ₹%.2f".format(grandTotalSale),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "$totalUnits unit(s) in cart",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }

                                Surface(
                                    color = when (paymentStatus) {
                                        "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                        "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                                        else -> Color(0xFFC62828).copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = paymentStatus,
                                        color = when (paymentStatus) {
                                            "PAID" -> Color(0xFF2E7D32)
                                            "PARTIAL" -> Color(0xFFF57F17)
                                            else -> Color(0xFFC62828)
                                        },
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (cartItems.isEmpty()) {
                                        errorMessage = "Please add at least one product to the sale."
                                        return@Button
                                    }
                                    if (anyItemExceedsStock) {
                                        errorMessage = "Cannot complete sale: one or more items exceed current in-stock quantity."
                                        return@Button
                                    }

                                    onSave(
                                        drafts,
                                        customerName.trim(),
                                        customerContact.trim(),
                                        customerEmail.trim(),
                                        customerAddress.trim(),
                                        saleInvoiceNumber.trim(),
                                        saleDateMs,
                                        receivedAmount,
                                        paymentMethod,
                                        paymentNote.trim(),
                                        notes.trim()
                                    )
                                },
                                enabled = cartItems.isNotEmpty() && !anyItemExceedsStock,
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("confirm_sale_button")
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Complete Sale (₹%.2f)".format(grandTotalSale), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (errorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(errorMessage ?: "", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    // Section 1: Customer Details
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Text("Customer Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            }

                            OutlinedTextField(
                                value = customerName,
                                onValueChange = { customerName = it },
                                label = { Text("Customer Name (Optional / Walk-in)") },
                                modifier = Modifier.fillMaxWidth().testTag("sale_customer_name_input")
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customerContact,
                                    onValueChange = { customerContact = it },
                                    label = { Text("Phone / Contact") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier.weight(1f).testTag("sale_customer_contact_input")
                                )
                                OutlinedTextField(
                                    value = customerEmail,
                                    onValueChange = { customerEmail = it },
                                    label = { Text("Email (Optional)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            OutlinedTextField(
                                value = customerAddress,
                                onValueChange = { customerAddress = it },
                                label = { Text("Delivery / Street Address (Optional)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Section 2: Invoice & Date
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = saleInvoiceNumber,
                            onValueChange = { saleInvoiceNumber = it },
                            label = { Text("Invoice / Receipt No.") },
                            modifier = Modifier.weight(1.2f).testTag("sale_invoice_number_input")
                        )

                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance().apply { timeInMillis = saleDateMs }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, day ->
                                        val newCal = Calendar.getInstance().apply { set(year, month, day) }
                                        saleDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(dateDisplay, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // Section 3: Cart / Multi-Product Line Items
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(18.dp))
                                    Text("Products in Sale (${cartItems.size})", fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { showProductPicker = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                    modifier = Modifier.testTag("add_product_to_sale_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Product")
                                }
                            }

                            if (cartItems.isEmpty()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(36.dp))
                                        Text("No products added yet", fontWeight = FontWeight.Bold)
                                        Text("Tap '+ Add Product' to select from inventory.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    }
                                }
                            } else {
                                cartItems.forEachIndexed { index, draftItem ->
                                    SaleLineItemRow(
                                        index = index + 1,
                                        item = draftItem,
                                        onDelete = { cartItems.removeAt(index) }
                                    )
                                }
                            }
                        }
                    }

                    // Section 4: Live Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Sale Financial Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal (Base):", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(totalOriginalSubtotal), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Discount Given:", style = MaterialTheme.typography.bodySmall, color = ProfitGreen)
                                Text("-₹%.2f".format(totalDiscount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total GST Charged:", style = MaterialTheme.typography.bodySmall)
                                Text("+₹%.2f".format(totalGst), style = MaterialTheme.typography.bodySmall)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Grand Total Sale Amount:", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(grandTotalSale), fontWeight = FontWeight.Bold, color = ForestGreenPrimary, style = MaterialTheme.typography.titleMedium)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated Profit:", style = MaterialTheme.typography.bodySmall, color = ProfitGreen, fontWeight = FontWeight.SemiBold)
                                Text("₹%.2f".format(totalProfit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                            }

                            // Volume points notice rule: Sales do not earn volume points
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = PointsGold, modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "Volume Points: 0.0 pts (Sales do not earn volume points)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Section 5: Payment & Settlement
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment Collection", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = when (paymentStatus) {
                                        "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                        "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                                        else -> Color(0xFFC62828).copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = paymentStatus,
                                        color = when (paymentStatus) {
                                            "PAID" -> Color(0xFF2E7D32)
                                            "PARTIAL" -> Color(0xFFF57F17)
                                            else -> Color(0xFFC62828)
                                        },
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = if (userModifiedReceived) amountReceivedStr else if (grandTotalSale > 0) "%.2f".format(grandTotalSale) else "",
                                onValueChange = {
                                    userModifiedReceived = true
                                    amountReceivedStr = it
                                },
                                label = { Text("Amount Received from Customer (₹)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth().testTag("sale_amount_received_input")
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Customer Balance Pending:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "₹%.2f".format(pendingAmount),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (pendingAmount > 0.01) Color(0xFFC62828) else Color(0xFF2E7D32)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Cash", "UPI", "Card", "Bank Transfer").forEach { method ->
                                    FilterChip(
                                        selected = paymentMethod == method,
                                        onClick = { paymentMethod = method },
                                        label = { Text(method) },
                                        modifier = Modifier.testTag("pay_method_$method")
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = paymentNote,
                                onValueChange = { paymentNote = it },
                                label = { Text("Payment / Transaction Reference (Optional)") },
                                placeholder = { Text("e.g. UPI Ref #, Google Pay") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Order Notes / Remarks (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Product Picker Dialog
    if (showProductPicker) {
        ProductSelectorDialog(
            products = products,
            onDismiss = { showProductPicker = false },
            onProductSelected = { selected ->
                cartItems.add(MutableSaleDraftItem(selected))
                showProductPicker = false
            }
        )
    }
}

@Composable
fun ProductSelectorDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onProductSelected: (Product) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(products, query) {
        if (query.isBlank()) products
        else {
            val q = query.trim().lowercase()
            products.filter { it.name.lowercase().contains(q) || it.sku.lowercase().contains(q) }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Product for Sale", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search catalog") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (filtered.isEmpty()) {
                    Text("No matching products found.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                } else {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filtered) { product ->
                            Card(
                                onClick = { onProductSelected(product) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (product.currentStock <= 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(product.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                        Text("Price: ₹%.2f".format(product.sellingPrice), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    }

                                    Surface(
                                        color = if (product.currentStock > 0) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFC62828).copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = if (product.currentStock > 0) "Stock: ${product.currentStock}" else "Out of Stock",
                                            color = if (product.currentStock > 0) Color(0xFF2E7D32) else Color(0xFFC62828),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SaleLineItemRow(
    index: Int,
    item: MutableSaleDraftItem,
    onDelete: () -> Unit
) {
    val draft = item.toDraft()
    val availableStock = item.product.currentStock

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.exceedsStock) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
        ),
        border = if (item.exceedsStock) BorderStroke(1.5.dp, MaterialTheme.colorScheme.error) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Row 1: Header (Name, Stock status, and Delete)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("#$index  ${item.product.name}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text("In Stock: $availableStock units", style = MaterialTheme.typography.labelSmall, color = if (item.exceedsStock) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline)
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove Item", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
            }

            if (item.exceedsStock) {
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(4.dp)) {
                    Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Quantity exceeds available stock ($availableStock)!",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Row 2: Quantity Stepper & Base Selling Price
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1.1f)
                ) {
                    IconButton(
                        onClick = {
                            val cur = item.quantity
                            if (cur > 1) item.quantityStr = (cur - 1).toString()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease")
                    }
                    OutlinedTextField(
                        value = item.quantityStr,
                        onValueChange = { item.quantityStr = it },
                        label = { Text("Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(64.dp)
                    )
                    IconButton(
                        onClick = {
                            val cur = item.quantity
                            item.quantityStr = (cur + 1).toString()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase")
                    }
                }

                OutlinedTextField(
                    value = item.baseSellingPriceStr,
                    onValueChange = { item.baseSellingPriceStr = it },
                    label = { Text("Unit Price (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
            }

            // Row 3: Discount & GST adjustments
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Discount
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Discount", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = if (item.discountType == "PERCENTAGE") "%" else "₹",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary,
                            modifier = Modifier.clickable {
                                item.discountType = if (item.discountType == "PERCENTAGE") "FIXED_AMOUNT" else "PERCENTAGE"
                            }
                        )
                    }
                    OutlinedTextField(
                        value = item.discountValueStr,
                        onValueChange = { item.discountValueStr = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // GST
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("GST", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = if (item.gstType == "PERCENTAGE") "%" else "₹",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StockBlue,
                            modifier = Modifier.clickable {
                                item.gstType = if (item.gstType == "PERCENTAGE") "FIXED_AMOUNT" else "PERCENTAGE"
                            }
                        )
                    }
                    OutlinedTextField(
                        value = item.gstValueStr,
                        onValueChange = { item.gstValueStr = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Row 4: Live line item summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Unit: ₹%.2f".format(draft.finalPricePerUnit),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Profit: ₹%.2f".format(draft.lineProfit),
                    style = MaterialTheme.typography.bodySmall,
                    color = ProfitGreen,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Total: ₹%.2f".format(draft.lineTotal),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary
                )
            }
        }
    }
}
