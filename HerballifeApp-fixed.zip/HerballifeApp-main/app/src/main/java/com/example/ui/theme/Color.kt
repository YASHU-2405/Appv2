package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Green Palette
val ForestGreenPrimary = Color(0xFF0D5C3A)
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val ForestGreenPrimaryContainer = Color(0xFFA5F2CA)
val ForestGreenOnPrimaryContainer = Color(0xFF002111)

val ForestSecondary = Color(0xFF236546)
val ForestOnSecondary = Color(0xFFFFFFFF)
val ForestSecondaryContainer = Color(0xFFD3E8D9)
val ForestOnSecondaryContainer = Color(0xFF0A2015)

val EmeraldTertiary = Color(0xFF007A5E)
val EmeraldOnTertiary = Color(0xFFFFFFFF)
val EmeraldTertiaryContainer = Color(0xFF98F7D7)
val EmeraldOnTertiaryContainer = Color(0xFF002117)

val SurfaceLight = Color(0xFFFCFDF9)
val SurfaceVariantLight = Color(0xFFEDF2EC)
val BackgroundLight = Color(0xFFF6FAF6)
val OnSurfaceLight = Color(0xFF191C1A)
val OnSurfaceVariantLight = Color(0xFF414942)
val OutlineLight = Color(0xFF717972)

// Dark Theme Palette
val ForestGreenPrimaryDark = Color(0xFF89D6AF)
val ForestGreenOnPrimaryDark = Color(0xFF003820)
val ForestGreenPrimaryContainerDark = Color(0xFF005231)
val ForestGreenOnPrimaryContainerDark = Color(0xFFA5F2CA)

val SurfaceDark = Color(0xFF111412)
val SurfaceVariantDark = Color(0xFF1E2420)
val BackgroundDark = Color(0xFF111412)
val OnSurfaceDark = Color(0xFFE2E3DF)
val OnSurfaceVariantDark = Color(0xFFC1C8C2)
val OutlineDark = Color(0xFF8B938C)

// Accents
val ProfitGreen = Color(0xFF16A34A)
val LossRed = Color(0xFFDC2626)
val PointsGold = Color(0xFFD97706)
val StockBlue = Color(0xFF2563EB)
val CardBorder = Color(0xFFE2E8E4)
