package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AiLogDao
import com.example.data.dao.BillDao
import com.example.data.dao.BorrowedProductDao
import com.example.data.dao.ProductDao
import com.example.data.dao.ProductUsageDao
import com.example.data.dao.PurchaseDao
import com.example.data.dao.PurchaseOrderDao
import com.example.data.dao.SaleDao
import com.example.data.dao.SalePaymentDao
import com.example.data.dao.StockMovementDao
import com.example.data.model.AiLog
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BorrowedProduct
import com.example.data.model.Product
import com.example.data.model.ProductUsage
import com.example.data.model.Purchase
import com.example.data.model.PurchaseOrder
import com.example.data.model.Sale
import com.example.data.model.SalePayment
import com.example.data.model.StockMovement

@Database(
    entities = [
        Product::class,
        Purchase::class,
        Sale::class,
        StockMovement::class,
        AiLog::class,
        ProductUsage::class,
        BorrowedProduct::class,
        SalePayment::class,
        PurchaseOrder::class,
        Bill::class,
        BillItem::class
    ],
    version = 8,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun saleDao(): SaleDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun aiLogDao(): AiLogDao
    abstract fun productUsageDao(): ProductUsageDao
    abstract fun borrowedProductDao(): BorrowedProductDao
    abstract fun salePaymentDao(): SalePaymentDao
    abstract fun purchaseOrderDao(): PurchaseOrderDao
    abstract fun billDao(): BillDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE sales ADD COLUMN customerContact TEXT")
                db.execSQL("ALTER TABLE sales ADD COLUMN customerEmail TEXT")
                db.execSQL("ALTER TABLE sales ADD COLUMN customerAddress TEXT")

                db.execSQL("ALTER TABLE products ADD COLUMN gstType TEXT NOT NULL DEFAULT 'PERCENTAGE'")
                db.execSQL("ALTER TABLE products ADD COLUMN gstFixedAmount REAL NOT NULL DEFAULT 0.0")

                db.execSQL("ALTER TABLE purchases ADD COLUMN gstType TEXT NOT NULL DEFAULT 'PERCENTAGE'")
                db.execSQL("ALTER TABLE purchases ADD COLUMN gstFixedAmount REAL NOT NULL DEFAULT 0.0")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE sales ADD COLUMN gstType TEXT NOT NULL DEFAULT 'PERCENTAGE'")
                db.execSQL("ALTER TABLE sales ADD COLUMN taxPercentage REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN gstFixedAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN gstAmount REAL NOT NULL DEFAULT 0.0")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS product_usages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        productId INTEGER NOT NULL,
                        productName TEXT NOT NULL,
                        quantity INTEGER NOT NULL,
                        unitCost REAL NOT NULL DEFAULT 0.0,
                        totalCost REAL NOT NULL DEFAULT 0.0,
                        usageDate INTEGER NOT NULL,
                        notes TEXT NOT NULL DEFAULT ''
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS borrowed_products (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        personOrBusinessName TEXT NOT NULL,
                        contactNumber TEXT,
                        productId INTEGER NOT NULL,
                        productName TEXT NOT NULL,
                        quantityBorrowed INTEGER NOT NULL,
                        quantityReturned INTEGER NOT NULL DEFAULT 0,
                        quantitySold INTEGER NOT NULL DEFAULT 0,
                        unitValue REAL NOT NULL DEFAULT 0.0,
                        totalValue REAL NOT NULL DEFAULT 0.0,
                        dateReceived INTEGER NOT NULL,
                        expectedReturnDate INTEGER,
                        notes TEXT NOT NULL DEFAULT '',
                        status TEXT NOT NULL DEFAULT 'BORROWED',
                        settlementAmount REAL,
                        settlementDate INTEGER,
                        settlementNotes TEXT
                    )
                    """.trimIndent()
                )
                db.execSQL("ALTER TABLE purchases ADD COLUMN discountType TEXT NOT NULL DEFAULT 'PERCENTAGE'")
                db.execSQL("ALTER TABLE purchases ADD COLUMN discountFixedAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN discountType TEXT NOT NULL DEFAULT 'PERCENTAGE'")
                db.execSQL("ALTER TABLE sales ADD COLUMN discountFixedAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN fromBorrowedId INTEGER")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE purchases ADD COLUMN pointsPerUnit REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE purchases ADD COLUMN totalPoints REAL NOT NULL DEFAULT 0.0")
                // Populate historical purchase points from existing products if available
                db.execSQL("UPDATE purchases SET pointsPerUnit = COALESCE((SELECT points FROM products WHERE products.id = purchases.productId), 0.0) WHERE pointsPerUnit = 0.0")
                db.execSQL("UPDATE purchases SET totalPoints = pointsPerUnit * quantity WHERE totalPoints = 0.0")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Add payment columns to sales table
                db.execSQL("ALTER TABLE sales ADD COLUMN paymentStatus TEXT NOT NULL DEFAULT 'PAID'")
                db.execSQL("ALTER TABLE sales ADD COLUMN amountReceived REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN amountPending REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE sales ADD COLUMN paymentMethod TEXT NOT NULL DEFAULT 'Cash'")
                db.execSQL("ALTER TABLE sales ADD COLUMN paymentDate INTEGER")
                db.execSQL("ALTER TABLE sales ADD COLUMN paymentNote TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE sales ADD COLUMN receiptImageUri TEXT")
                // Populate historical sales with full payment so past records remain consistent
                db.execSQL("UPDATE sales SET amountReceived = totalSaleAmount, amountPending = 0.0, paymentStatus = 'PAID'")

                // Add orderId, supplierName and receiptImageUri to purchases table
                db.execSQL("ALTER TABLE purchases ADD COLUMN orderId INTEGER")
                db.execSQL("ALTER TABLE purchases ADD COLUMN supplierName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE purchases ADD COLUMN receiptImageUri TEXT")

                // Add receiptImageUri to product_usages and borrowed_products
                db.execSQL("ALTER TABLE product_usages ADD COLUMN receiptImageUri TEXT")
                db.execSQL("ALTER TABLE borrowed_products ADD COLUMN receiptImageUri TEXT")

                // Create sale_payments table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS sale_payments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        saleId INTEGER NOT NULL,
                        customerName TEXT,
                        customerContact TEXT,
                        amount REAL NOT NULL,
                        paymentDate INTEGER NOT NULL,
                        paymentMethod TEXT NOT NULL DEFAULT 'Cash',
                        notes TEXT NOT NULL DEFAULT '',
                        receiptImageUri TEXT
                    )
                """.trimIndent())

                // Create purchase_orders table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS purchase_orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        orderNumber TEXT NOT NULL,
                        invoiceNumber TEXT NOT NULL DEFAULT '',
                        supplierName TEXT NOT NULL DEFAULT '',
                        purchaseDate INTEGER NOT NULL,
                        totalProducts INTEGER NOT NULL DEFAULT 0,
                        totalQuantity INTEGER NOT NULL DEFAULT 0,
                        totalOriginalAmount REAL NOT NULL DEFAULT 0.0,
                        totalDiscountAmount REAL NOT NULL DEFAULT 0.0,
                        totalGstAmount REAL NOT NULL DEFAULT 0.0,
                        finalPurchaseAmount REAL NOT NULL DEFAULT 0.0,
                        totalPoints REAL NOT NULL DEFAULT 0.0,
                        notes TEXT NOT NULL DEFAULT '',
                        receiptImageUri TEXT
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create bills table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS bills (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        billNumber TEXT NOT NULL,
                        billDate INTEGER NOT NULL,
                        supplierName TEXT NOT NULL DEFAULT '',
                        billImageUri TEXT,
                        totalOriginalAmount REAL NOT NULL DEFAULT 0.0,
                        totalDiscountAmount REAL NOT NULL DEFAULT 0.0,
                        totalGstAmount REAL NOT NULL DEFAULT 0.0,
                        finalAmount REAL NOT NULL DEFAULT 0.0,
                        amountPaid REAL NOT NULL DEFAULT 0.0,
                        amountPending REAL NOT NULL DEFAULT 0.0,
                        paymentStatus TEXT NOT NULL DEFAULT 'PAID',
                        notes TEXT NOT NULL DEFAULT '',
                        linkedPurchaseOrderId INTEGER
                    )
                """.trimIndent())

                // Create bill_items table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS bill_items (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        billId INTEGER NOT NULL,
                        productId INTEGER,
                        productName TEXT NOT NULL,
                        quantity INTEGER NOT NULL,
                        originalPrice REAL NOT NULL DEFAULT 0.0,
                        discountPercentage REAL NOT NULL DEFAULT 0.0,
                        discountAmount REAL NOT NULL DEFAULT 0.0,
                        taxPercentage REAL NOT NULL DEFAULT 0.0,
                        taxAmount REAL NOT NULL DEFAULT 0.0,
                        finalPricePerUnit REAL NOT NULL DEFAULT 0.0,
                        totalAmount REAL NOT NULL DEFAULT 0.0,
                        needsReview INTEGER NOT NULL DEFAULT 0,
                        FOREIGN KEY(billId) REFERENCES bills(id) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_items_billId ON bill_items(billId)")

                // Add payment columns to purchases table
                db.execSQL("ALTER TABLE purchases ADD COLUMN paymentStatus TEXT NOT NULL DEFAULT 'PAID'")
                db.execSQL("ALTER TABLE purchases ADD COLUMN amountPaid REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE purchases ADD COLUMN amountPending REAL NOT NULL DEFAULT 0.0")
                db.execSQL("UPDATE purchases SET amountPaid = totalAmount, amountPending = 0.0, paymentStatus = 'PAID'")

                // Add saleInvoiceNumber to sales table
                db.execSQL("ALTER TABLE sales ADD COLUMN saleInvoiceNumber TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "onest_nutrition_manager.db"
                )
                    .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
