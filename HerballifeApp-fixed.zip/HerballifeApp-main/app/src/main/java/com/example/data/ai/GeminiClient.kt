package com.example.data.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val MODEL_NAME = "gemini-3.5-flash"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    suspend fun generateContent(systemPrompt: String, userMessage: String): Result<String> =
        withContext(Dispatchers.IO) {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (!isConfigured()) {
                return@withContext Result.failure(IllegalStateException("API key not configured"))
            }

            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"

                val root = JSONObject()

                // system instruction
                val sysContent = JSONObject()
                val sysParts = JSONArray()
                sysParts.put(JSONObject().put("text", systemPrompt))
                sysContent.put("parts", sysParts)
                root.put("systemInstruction", sysContent)

                // contents
                val contents = JSONArray()
                val userContent = JSONObject()
                val userParts = JSONArray()
                userParts.put(JSONObject().put("text", userMessage))
                userContent.put("parts", userParts)
                contents.put(userContent)
                root.put("contents", contents)

                // generationConfig
                val genConfig = JSONObject()
                genConfig.put("temperature", 0.2)
                root.put("generationConfig", genConfig)

                val body = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .post(body)
                    .build()

                val (respBody, isSuccessful, statusCode) = client.newCall(request).execute().use { response ->
                    Triple(response.body?.string() ?: "", response.isSuccessful, response.code)
                }

                if (!isSuccessful) {
                    return@withContext Result.failure(Exception("Gemini error $statusCode: $respBody"))
                }

                val respJson = JSONObject(respBody)
                val candidates = respJson.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val contentObj = firstCandidate?.optJSONObject("content")
                val parts = contentObj?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text") ?: ""

                Result.success(text)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun generateMultimodalContent(
        systemPrompt: String,
        userMessage: String,
        bitmap: Bitmap
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!isConfigured()) {
            return@withContext Result.failure(IllegalStateException("API key not configured"))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"

            // Convert bitmap to base64 jpeg
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val root = JSONObject()

            // system instruction
            val sysContent = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemPrompt))
            sysContent.put("parts", sysParts)
            root.put("systemInstruction", sysContent)

            // contents with text and image part
            val contents = JSONArray()
            val userContent = JSONObject()
            val userParts = JSONArray()

            val textPart = JSONObject().put("text", userMessage)
            val inlineDataObj = JSONObject()
                .put("mimeType", "image/jpeg")
                .put("data", base64Image)
            val imagePart = JSONObject().put("inlineData", inlineDataObj)

            userParts.put(textPart)
            userParts.put(imagePart)
            userContent.put("parts", userParts)
            contents.put(userContent)
            root.put("contents", contents)

            val genConfig = JSONObject()
            genConfig.put("temperature", 0.0)
            genConfig.put("responseMimeType", "application/json")
            root.put("generationConfig", genConfig)

            val body = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val (respBody, isSuccessful, statusCode) = client.newCall(request).execute().use { response ->
                Triple(response.body?.string() ?: "", response.isSuccessful, response.code)
            }

            if (!isSuccessful) {
                return@withContext Result.failure(Exception("Gemini error $statusCode: $respBody"))
            }

            val respJson = JSONObject(respBody)
            val candidates = respJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val contentObj = firstCandidate?.optJSONObject("content")
            val parts = contentObj?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    data class GeminiSearchResult(
        val text: String,
        val citations: List<WebCitation> = emptyList()
    )

    suspend fun generateContentWithSearch(
        systemPrompt: String,
        userMessage: String
    ): Result<GeminiSearchResult> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!isConfigured()) {
            return@withContext Result.failure(IllegalStateException("API key not configured"))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"

            val root = JSONObject()

            // system instruction
            val sysContent = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemPrompt))
            sysContent.put("parts", sysParts)
            root.put("systemInstruction", sysContent)

            // contents
            val contents = JSONArray()
            val userContent = JSONObject()
            val userParts = JSONArray()
            userParts.put(JSONObject().put("text", userMessage))
            userContent.put("parts", userParts)
            contents.put(userContent)
            root.put("contents", contents)

            // tools for Google Search Grounding
            val tools = JSONArray()
            val googleSearchTool = JSONObject().put("googleSearch", JSONObject())
            tools.put(googleSearchTool)
            root.put("tools", tools)

            val genConfig = JSONObject()
            genConfig.put("temperature", 0.1)
            root.put("generationConfig", genConfig)

            val body = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val (respBody, isSuccessful, statusCode) = client.newCall(request).execute().use { response ->
                Triple(response.body?.string() ?: "", response.isSuccessful, response.code)
            }

            if (!isSuccessful) {
                // If Google Search tool is unsupported or failed, gracefully fall back to standard generation
                val fallbackText = generateContent(systemPrompt, userMessage).getOrNull()
                if (fallbackText != null) {
                    return@withContext Result.success(GeminiSearchResult(fallbackText, emptyList()))
                }
                return@withContext Result.failure(Exception("Gemini search error $statusCode: $respBody"))
            }

            val respJson = JSONObject(respBody)
            val candidates = respJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val contentObj = firstCandidate?.optJSONObject("content")
            val parts = contentObj?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            // Parse grounding metadata
            val citations = mutableListOf<WebCitation>()
            val groundingMetadata = firstCandidate?.optJSONObject("groundingMetadata")
            if (groundingMetadata != null) {
                val chunks = groundingMetadata.optJSONArray("groundingChunks")
                if (chunks != null) {
                    for (i in 0 until chunks.length()) {
                        val chunk = chunks.optJSONObject(i)
                        val web = chunk?.optJSONObject("web")
                        if (web != null) {
                            val uri = web.optString("uri", "")
                            val title = web.optString("title", "Herbalife Product Information")
                            if (uri.isNotBlank()) {
                                val isHerbalife = uri.contains("herbalife", ignoreCase = true)
                                citations.add(
                                    WebCitation(
                                        title = title,
                                        url = uri,
                                        sourceName = if (isHerbalife) "Herbalife India Official" else "Web Source",
                                        snippet = "Official web source verified live via Google Search"
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Result.success(GeminiSearchResult(text, citations.distinctBy { it.url }))
        } catch (e: Exception) {
            // Fall back to standard content generation if available
            val fallback = generateContent(systemPrompt, userMessage).getOrNull()
            if (fallback != null) {
                Result.success(GeminiSearchResult(fallback, emptyList()))
            } else {
                Result.failure(e)
            }
        }
    }
}
