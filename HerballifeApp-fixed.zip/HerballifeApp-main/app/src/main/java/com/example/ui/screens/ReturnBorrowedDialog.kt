package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.BorrowedProduct
import com.example.ui.theme.ForestGreenPrimary
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReturnBorrowedDialog(
    borrowedProduct: BorrowedProduct,
    currentAvailableStock: Int,
    onDismiss: () -> Unit,
    onConfirmReturn: (returnQty: Int, returnDateMs: Long, notes: String) -> Unit
) {
    val remainingToReturn = (borrowedProduct.quantity - borrowedProduct.returnedQuantity).coerceAtLeast(0)
    var quantityStr by remember { mutableStateOf(remainingToReturn.toString()) }
    var returnDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var returnNotes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val returnDateDisplay = dateFormat.format(Date(returnDateMs))

    val qty = quantityStr.toIntOrNull() ?: 1

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Return Borrowed Stock", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Borrowed Item: ${borrowedProduct.productName}", fontWeight = FontWeight.Bold)
                        Text("Lender: ${borrowedProduct.personName}", style = MaterialTheme.typography.bodySmall)
                        Text("Total Borrowed: ${borrowedProduct.quantity} units", style = MaterialTheme.typography.bodySmall)
                        Text("Already Returned: ${borrowedProduct.returnedQuantity} units", style = MaterialTheme.typography.bodySmall)
                        Text("Remaining to Return: $remainingToReturn units", fontWeight = FontWeight.SemiBold, color = ForestGreenPrimary)
                        Text("Your Current Stock: $currentAvailableStock units", style = MaterialTheme.typography.bodySmall)
                    }
                }

                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = {
                        quantityStr = it
                        errorMessage = null
                    },
                    label = { Text("Quantity Returning *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("return_quantity_input")
                )

                OutlinedTextField(
                    value = returnDateDisplay,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Return Date") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val cal = Calendar.getInstance().apply { timeInMillis = returnDateMs }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val c = Calendar.getInstance().apply { set(y, m, d) }
                                    returnDateMs = c.timeInMillis
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = returnNotes,
                    onValueChange = { returnNotes = it },
                    label = { Text("Notes (Optional)") },
                    placeholder = { Text("e.g. Returned in original condition") },
                    modifier = Modifier.fillMaxWidth().testTag("return_notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (qty <= 0) {
                        errorMessage = "Quantity must be at least 1"
                        return@Button
                    }
                    if (qty > remainingToReturn) {
                        errorMessage = "Cannot return more than remaining ($remainingToReturn units)"
                        return@Button
                    }
                    if (qty > currentAvailableStock) {
                        errorMessage = "You only have $currentAvailableStock units in current stock to return"
                        return@Button
                    }

                    onConfirmReturn(qty, returnDateMs, returnNotes.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                modifier = Modifier.testTag("confirm_return_button")
            ) {
                Text("Confirm Return")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
