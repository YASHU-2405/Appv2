package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.backup.BackupManager
import com.example.data.database.AppDatabase
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BillWithItems
import com.example.data.model.BorrowedProduct
import com.example.data.model.Product
import com.example.data.model.ProductUsage
import com.example.data.model.Purchase
import com.example.data.model.PurchaseOrder
import com.example.data.model.Sale
import com.example.data.model.SaleLineItemDraft
import com.example.data.model.SalePayment
import com.example.data.model.StockMovement
import com.example.data.preferences.AppSettingsManager
import com.example.data.repository.NutritionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class DateRangeFilter(val label: String) {
    TODAY("Today"),
    YESTERDAY("Yesterday"),
    THIS_WEEK("This Week"),
    THIS_MONTH("This Month"),
    THIS_YEAR("This Year"),
    LIFETIME("Lifetime"),
    CUSTOM("Custom")
}

data class DashboardMetrics(
    val currentTotalStock: Int = 0,
    val totalOwnedStock: Int = 0,
    val totalBorrowedStock: Int = 0,
    val totalProducts: Int = 0,
    val lowStockCount: Int = 0,

    // Today
    val todayPurchasesAmount: Double = 0.0,
    val todaySalesCount: Int = 0,
    val todayRevenue: Double = 0.0,
    val todayProfit: Double = 0.0, // Gross sales profit
    val todayRealizedProfit: Double = 0.0, // Profit attributable to payments actually received
    val todayPoints: Double = 0.0,
    val todayUsageUnits: Int = 0,
    val todayUsageCost: Double = 0.0,

    // Monthly
    val monthlySalesCount: Int = 0,
    val monthlyRevenue: Double = 0.0,
    val monthlyProfit: Double = 0.0, // Gross sales profit
    val monthlyRealizedProfit: Double = 0.0,
    val monthlyPoints: Double = 0.0,
    val monthlyUsageCost: Double = 0.0,

    // Yearly
    val thisYearPoints: Double = 0.0,

    // Lifetime
    val lifetimeSalesCount: Int = 0,
    val lifetimeRevenue: Double = 0.0,
    val lifetimeProfit: Double = 0.0, // Gross sales profit
    val lifetimeRealizedProfit: Double = 0.0,
    val lifetimePoints: Double = 0.0,
    val lifetimeUsageUnits: Int = 0,
    val lifetimeUsageCost: Double = 0.0,

    // Filtered Period
    val periodPurchasesAmount: Double = 0.0,
    val periodSalesCount: Int = 0,
    val periodRevenue: Double = 0.0,
    val periodProfit: Double = 0.0, // Gross sales profit
    val periodRealizedProfit: Double = 0.0,
    val periodPoints: Double = 0.0,
    val periodUsageUnits: Int = 0,
    val periodUsageCost: Double = 0.0,
    val periodAmountReceived: Double = 0.0,
    val periodAmountPending: Double = 0.0,
    val periodPaidSalesCount: Int = 0,
    val periodPartialSalesCount: Int = 0,
    val periodPendingSalesCount: Int = 0,

    // Accounting & Net Result
    val subtractUsageCostFromRevenue: Boolean = false,
    val periodNetResult: Double = 0.0, // If subtractUsageCostFromRevenue is true: periodProfit - periodUsageCost; else periodProfit

    // Borrowed Stock Metrics
    val totalBorrowedUnits: Int = 0,
    val outstandingBorrowedUnits: Int = 0,
    val outstandingBorrowedValue: Double = 0.0,

    // Lifetime Payments
    val lifetimeAmountReceived: Double = 0.0,
    val lifetimeAmountPending: Double = 0.0,
    val lifetimePaidSalesCount: Int = 0,
    val lifetimePartialSalesCount: Int = 0,
    val lifetimePendingSalesCount: Int = 0
) {
    val activeBorrowedUnits: Int get() = outstandingBorrowedUnits
}

data class ProductProfitStat(
    val productId: Long,
    val productName: String,
    val unitsSold: Int,
    val totalRevenue: Double,
    val totalCost: Double,
    val totalProfit: Double,
    val totalPoints: Double,
    val unitsUsed: Int = 0,
    val totalUsageCost: Double = 0.0
)

class NutritionViewModel(application: Application) : AndroidViewModel(application) {

    val repository: NutritionRepository
    val backupManager: BackupManager
    val settingsManager: AppSettingsManager

    init {
        val db = AppDatabase.getDatabase(application)
        repository = NutritionRepository(db)
        backupManager = BackupManager(repository)
        settingsManager = AppSettingsManager.getInstance(application)
    }

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchases: StateFlow<List<Purchase>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movements: StateFlow<List<StockMovement>> = repository.allMovements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val productUsages: StateFlow<List<ProductUsage>> = repository.allProductUsages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val borrowedProducts: StateFlow<List<BorrowedProduct>> = repository.allBorrowedProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeBorrowedProducts: StateFlow<List<BorrowedProduct>> = repository.activeBorrowedProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<SalePayment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchaseOrders: StateFlow<List<PurchaseOrder>> = repository.allPurchaseOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bills: StateFlow<List<BillWithItems>> = repository.allBillsWithItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subtractUsageCostSetting: StateFlow<Boolean> = settingsManager.subtractUsageCostFromRevenue

    // Selected Date Filter for Dashboard and Reports
    private val _selectedDateRange = MutableStateFlow(DateRangeFilter.THIS_MONTH)
    val selectedDateRange: StateFlow<DateRangeFilter> = _selectedDateRange.asStateFlow()

    private val _customStartMs = MutableStateFlow(System.currentTimeMillis() - 7 * 24 * 3600 * 1000L)
    val customStartMs: StateFlow<Long> = _customStartMs.asStateFlow()

    private val _customEndMs = MutableStateFlow(System.currentTimeMillis())
    val customEndMs: StateFlow<Long> = _customEndMs.asStateFlow()

    // Global Search State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setDateRange(filter: DateRangeFilter) {
        _selectedDateRange.value = filter
    }

    fun setCustomDateRange(startMs: Long, endMs: Long) {
        val startCal = Calendar.getInstance().apply {
            timeInMillis = startMs
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endCal = Calendar.getInstance().apply {
            timeInMillis = endMs
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        _customStartMs.value = startCal.timeInMillis
        _customEndMs.value = endCal.timeInMillis
        _selectedDateRange.value = DateRangeFilter.CUSTOM
    }

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    // Dashboard metrics derived reactively
    @Suppress("UNCHECKED_CAST")
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        products,
        purchases,
        sales,
        productUsages,
        borrowedProducts,
        subtractUsageCostSetting,
        selectedDateRange,
        combine(customStartMs, customEndMs) { s, e -> s to e }
    ) { args: Array<Any?> ->
        val prods = args[0] as List<Product>
        val purs = args[1] as List<Purchase>
        val sls = args[2] as List<Sale>
        val usgs = args[3] as List<ProductUsage>
        val brwd = args[4] as List<BorrowedProduct>
        val subtractSetting = args[5] as Boolean
        val range = args[6] as DateRangeFilter
        val customRange = args[7] as Pair<Long, Long>
        computeMetrics(
            prods,
            purs,
            sls,
            usgs,
            brwd,
            subtractSetting,
            range,
            customRange.first,
            customRange.second
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    private fun computeMetrics(
        prods: List<Product>,
        purs: List<Purchase>,
        sls: List<Sale>,
        usgs: List<ProductUsage>,
        brwd: List<BorrowedProduct>,
        subtractUsageSetting: Boolean,
        range: DateRangeFilter,
        cStart: Long,
        cEnd: Long
    ): DashboardMetrics {
        val totalOwnedStock = prods.sumOf { it.currentStock }
        val outstandingBorrowedUnits = brwd.sumOf { it.remainingQuantity }
        val outstandingBorrowedValue = brwd.sumOf { it.outstandingValue }
        val totalPhysicalStock = totalOwnedStock + outstandingBorrowedUnits
        val totalProducts = prods.size
        val lowStock = prods.count { it.currentStock <= it.minStockAlert }

        // Start & end bounds for Today
        val todayCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfToday = todayCal.timeInMillis
        val endOfToday = startOfToday + 24 * 3600 * 1000L - 1

        val todaySales = sls.filter { it.saleDate in startOfToday..endOfToday }
        val todayPurchases = purs.filter { it.purchaseDate in startOfToday..endOfToday }
        val todayUsages = usgs.filter { it.usageDate in startOfToday..endOfToday }

        // Start of Month
        val monthCal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfMonth = monthCal.timeInMillis
        val monthSales = sls.filter { it.saleDate >= startOfMonth }
        val monthPurchases = purs.filter { it.purchaseDate >= startOfMonth }
        val monthUsages = usgs.filter { it.usageDate >= startOfMonth }
        val monthlyPoints = monthPurchases.sumOf { it.totalPoints }

        // Start of Year
        val yearCal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfYear = yearCal.timeInMillis
        val yearPurchases = purs.filter { it.purchaseDate >= startOfYear }
        val thisYearPoints = yearPurchases.sumOf { it.totalPoints }

        // Lifetime
        val lifetimeRevenue = sls.sumOf { it.totalSaleAmount }
        val lifetimeProfit = sls.sumOf { it.profit }
        val lifetimePoints = purs.sumOf { it.totalPoints }
        val lifetimeSalesCount = sls.size
        val lifetimeUsageUnits = usgs.sumOf { it.quantity }
        val lifetimeUsageCost = usgs.sumOf { it.totalCost }

        // Period calculations based on selected DateRangeFilter
        val (pStart, pEnd) = getRangeTimestamps(range, cStart, cEnd)
        val periodSales = sls.filter { it.saleDate in pStart..pEnd }
        val periodPurchases = purs.filter { it.purchaseDate in pStart..pEnd }
        val periodUsages = usgs.filter { it.usageDate in pStart..pEnd }

        fun realizedProfit(sale: Sale): Double {
            val total = sale.totalSaleAmount
            if (total <= 0.001 || sale.profit == 0.0) return 0.0
            val received = sale.amountReceived.coerceIn(0.0, total)
            return (sale.profit * (received / total)).coerceIn(
                minOf(0.0, sale.profit),
                maxOf(0.0, sale.profit)
            )
        }

        val periodProfit = periodSales.sumOf { it.profit }
        val periodRealizedProfit = periodSales.sumOf(::realizedProfit)
        val periodUsageCost = periodUsages.sumOf { it.totalCost }
        val periodNetResult = if (subtractUsageSetting) {
            periodRealizedProfit - periodUsageCost
        } else {
            periodRealizedProfit
        }

        val periodAmountReceived = periodSales.sumOf { it.amountReceived }
        val periodAmountPending = periodSales.sumOf { it.amountPending }
        val periodPaidCount = periodSales.count { it.paymentStatus == "PAID" }
        val periodPartialCount = periodSales.count { it.paymentStatus == "PARTIAL" }
        val periodPendingCount = periodSales.count { it.paymentStatus == "PENDING" }

        val lifetimeAmountReceived = sls.sumOf { it.amountReceived }
        val lifetimeAmountPending = sls.sumOf { it.amountPending }
        val lifetimePaidCount = sls.count { it.paymentStatus == "PAID" }
        val lifetimePartialCount = sls.count { it.paymentStatus == "PARTIAL" }
        val lifetimePendingCount = sls.count { it.paymentStatus == "PENDING" }

        return DashboardMetrics(
            currentTotalStock = totalPhysicalStock,
            totalOwnedStock = totalOwnedStock,
            totalBorrowedStock = outstandingBorrowedUnits,
            totalProducts = totalProducts,
            lowStockCount = lowStock,

            todayPurchasesAmount = todayPurchases.sumOf { it.totalAmount },
            todaySalesCount = todaySales.size,
            todayRevenue = todaySales.sumOf { it.totalSaleAmount },
            todayProfit = todaySales.sumOf { it.profit },
            todayRealizedProfit = todaySales.sumOf(::realizedProfit),
            todayPoints = todayPurchases.sumOf { it.totalPoints },
            todayUsageUnits = todayUsages.sumOf { it.quantity },
            todayUsageCost = todayUsages.sumOf { it.totalCost },

            monthlySalesCount = monthSales.size,
            monthlyRevenue = monthSales.sumOf { it.totalSaleAmount },
            monthlyProfit = monthSales.sumOf { it.profit },
            monthlyRealizedProfit = monthSales.sumOf(::realizedProfit),
            monthlyPoints = monthlyPoints,
            monthlyUsageCost = monthUsages.sumOf { it.totalCost },

            thisYearPoints = thisYearPoints,

            lifetimeSalesCount = lifetimeSalesCount,
            lifetimeRevenue = lifetimeRevenue,
            lifetimeProfit = lifetimeProfit,
            lifetimeRealizedProfit = sls.sumOf(::realizedProfit),
            lifetimePoints = lifetimePoints,
            lifetimeUsageUnits = lifetimeUsageUnits,
            lifetimeUsageCost = lifetimeUsageCost,

            periodPurchasesAmount = periodPurchases.sumOf { it.totalAmount },
            periodSalesCount = periodSales.size,
            periodRevenue = periodSales.sumOf { it.totalSaleAmount },
            periodProfit = periodProfit,
            periodRealizedProfit = periodRealizedProfit,
            periodPoints = periodPurchases.sumOf { it.totalPoints },
            periodUsageUnits = periodUsages.sumOf { it.quantity },
            periodUsageCost = periodUsageCost,
            periodAmountReceived = periodAmountReceived,
            periodAmountPending = periodAmountPending,
            periodPaidSalesCount = periodPaidCount,
            periodPartialSalesCount = periodPartialCount,
            periodPendingSalesCount = periodPendingCount,

            subtractUsageCostFromRevenue = subtractUsageSetting,
            periodNetResult = periodNetResult,

            totalBorrowedUnits = brwd.sumOf { it.quantityBorrowed },
            outstandingBorrowedUnits = outstandingBorrowedUnits,
            outstandingBorrowedValue = outstandingBorrowedValue,

            lifetimeAmountReceived = lifetimeAmountReceived,
            lifetimeAmountPending = lifetimeAmountPending,
            lifetimePaidSalesCount = lifetimePaidCount,
            lifetimePartialSalesCount = lifetimePartialCount,
            lifetimePendingSalesCount = lifetimePendingCount
        )
    }

    fun getRangeTimestamps(range: DateRangeFilter, cStart: Long, cEnd: Long): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis

        return when (range) {
            DateRangeFilter.TODAY -> {
                val start = cal.timeInMillis
                start to endOfToday
            }
            DateRangeFilter.YESTERDAY -> {
                val yCal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val start = yCal.timeInMillis
                val end = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -1)
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                    set(Calendar.SECOND, 59)
                    set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                start to end
            }
            DateRangeFilter.THIS_WEEK -> {
                val wCal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val start = wCal.timeInMillis
                start to endOfToday
            }
            DateRangeFilter.THIS_MONTH -> {
                val mCal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val start = mCal.timeInMillis
                start to endOfToday
            }
            DateRangeFilter.THIS_YEAR -> {
                val yrCal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val start = yrCal.timeInMillis
                start to endOfToday
            }
            DateRangeFilter.LIFETIME -> 0L to Long.MAX_VALUE
            DateRangeFilter.CUSTOM -> cStart to cEnd
        }
    }

    // Product actions
    fun addProduct(product: Product, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.insertProduct(product)
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Failed to add product")
            }
        }
    }

    fun updateProduct(product: Product, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.updateProduct(product)
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Failed to update product")
            }
        }
    }

    fun deleteProduct(product: Product, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.deleteProduct(product)
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Failed to delete product")
            }
        }
    }

    // Purchase actions
    fun recordPurchase(purchase: Purchase, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.recordPurchase(purchase)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Purchase failed")
        }
    }

    fun deletePurchase(purchase: Purchase, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.deletePurchase(purchase)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Failed to delete purchase")
        }
    }

    // Sale actions
    fun recordSale(sale: Sale, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.recordSale(sale)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Sale failed")
        }
    }

    fun updateSale(oldSale: Sale, updatedSale: Sale, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.updateSale(oldSale, updatedSale)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Sale update failed")
        }
    }

    fun deleteSale(sale: Sale, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.deleteSale(sale)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Failed to delete sale")
        }
    }

    fun recordMultiProductSale(
        items: List<SaleLineItemDraft>,
        customerName: String?,
        customerContact: String?,
        customerEmail: String?,
        customerAddress: String?,
        saleInvoiceNumber: String = "",
        saleDate: Long,
        notes: String,
        amountReceived: Double,
        paymentMethod: String = "Cash",
        paymentDate: Long = saleDate,
        paymentNote: String = "",
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.recordMultiProductSale(
                items = items,
                customerName = customerName,
                customerContact = customerContact,
                customerEmail = customerEmail,
                customerAddress = customerAddress,
                saleInvoiceNumber = saleInvoiceNumber,
                saleDate = saleDate,
                notes = notes,
                amountReceived = amountReceived,
                paymentMethod = paymentMethod,
                paymentDate = paymentDate,
                paymentNote = paymentNote
            )
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Sale failed")
        }
    }

    // Bill actions
    fun insertBill(
        bill: Bill,
        items: List<BillItem>,
        createPurchaseStock: Boolean = false,
        onSuccess: (Long) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.insertBillWithItems(bill, items, createPurchaseStock)
            if (res.isSuccess) onSuccess(res.getOrThrow()) else onError(res.exceptionOrNull()?.message ?: "Failed to save bill")
        }
    }

    fun updateBill(
        bill: Bill,
        items: List<BillItem>,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.updateBill(bill, items)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Failed to update bill")
        }
    }

    fun deleteBill(
        bill: Bill,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.deleteBill(bill)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Failed to delete bill")
        }
    }

    // Product Usage actions
    fun recordProductUsage(usage: ProductUsage, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.recordProductUsage(usage)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Recording usage failed")
        }
    }

    fun deleteProductUsage(usage: ProductUsage, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.deleteProductUsage(usage)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Failed to delete product usage")
        }
    }

    // Borrowed Products actions
    fun recordBorrowedProduct(borrowed: BorrowedProduct, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.recordBorrowedProduct(borrowed)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Recording borrowed product failed")
        }
    }

    fun returnBorrowedProduct(borrowedId: Long, quantity: Int, notes: String = "", onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.returnBorrowedProduct(borrowedId, quantity, notes)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Return failed")
        }
    }

    fun settleBorrowedProduct(borrowedId: Long, amount: Double, notes: String = "", onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.settleBorrowedProduct(borrowedId, amount, notes)
            if (res.isSuccess) onSuccess() else onError(res.exceptionOrNull()?.message ?: "Settlement failed")
        }
    }

    fun deleteBorrowedProduct(borrowed: BorrowedProduct, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteBorrowedProduct(borrowed)
            onSuccess()
        }
    }

    // Manual stock adjustment
    fun adjustProductStock(productId: Long, newStock: Int, reason: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateProductStockDirect(productId, newStock, reason)
            onSuccess()
        }
    }

    // Additional Payment & Payment Tracking
    fun recordAdditionalPayment(
        saleId: Long,
        amount: Double,
        paymentMethod: String = "Cash",
        paymentDate: Long = System.currentTimeMillis(),
        notes: String = "",
        receiptImageUri: String? = null,
        onSuccess: (Long) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.recordAdditionalPayment(
                saleId = saleId,
                amount = amount,
                paymentMethod = paymentMethod,
                paymentDate = paymentDate,
                notes = notes,
                receiptImageUri = receiptImageUri
            )
            res.onSuccess { onSuccess(it) }
               .onFailure { onError(it.message ?: "Failed to record payment") }
        }
    }

    fun recordPurchaseOrder(
        order: PurchaseOrder,
        items: List<Purchase>,
        onSuccess: (Long) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.recordPurchaseOrder(order, items)
            res.onSuccess { onSuccess(it) }
               .onFailure { onError(it.message ?: "Failed to record purchase order") }
        }
    }

    fun deletePurchaseOrder(
        orderId: Long,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.deletePurchaseOrder(orderId)
            res.onSuccess { onSuccess() }
               .onFailure { onError(it.message ?: "Failed to delete purchase order") }
        }
    }

    fun getPaymentsForSale(saleId: Long) = repository.getPaymentsForSale(saleId)
    fun getPurchasesForOrder(orderId: Long) = repository.getPurchasesForOrder(orderId)
    fun getPaymentsForCustomer(customerName: String) = repository.getPaymentsForCustomer(customerName)

    // Product-wise profit, usage & points stats
    fun getProductProfitStats(): List<ProductProfitStat> {
        val sls = sales.value
        val purs = purchases.value
        val prods = products.value
        val usgs = productUsages.value
        return prods.map { prod ->
            val pSales = sls.filter { it.productId == prod.id }
            val pPurchases = purs.filter { it.productId == prod.id }
            val pUsages = usgs.filter { it.productId == prod.id }
            ProductProfitStat(
                productId = prod.id,
                productName = prod.name,
                unitsSold = pSales.sumOf { it.quantity },
                totalRevenue = pSales.sumOf { it.totalSaleAmount },
                totalCost = pSales.sumOf { it.totalPurchaseCost },
                totalProfit = pSales.sumOf { it.profit },
                totalPoints = pPurchases.sumOf { it.totalPoints },
                unitsUsed = pUsages.sumOf { it.quantity },
                totalUsageCost = pUsages.sumOf { it.totalCost }
            )
        }
    }
}
