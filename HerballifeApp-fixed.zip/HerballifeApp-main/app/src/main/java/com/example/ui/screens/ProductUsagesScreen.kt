package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ProductUsage
import com.example.ui.components.CustomDateRangeDialog
import com.example.ui.components.DateRangeSelectorRow
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.StatCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.DateRangeFilter
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductUsagesScreen(
    viewModel: NutritionViewModel,
    onOpenAddUsage: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val usages by viewModel.productUsages.collectAsState()
    val products by viewModel.products.collectAsState()
    val dateRange by viewModel.selectedDateRange.collectAsState()
    val customStartMs by viewModel.customStartMs.collectAsState()
    val customEndMs by viewModel.customEndMs.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var usageToDelete by remember { mutableStateOf<ProductUsage?>(null) }
    var showCustomDateDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    // Filter by date range
    val filteredUsages = remember(usages, dateRange, customStartMs, customEndMs, searchQuery) {
        val (start, end) = when (dateRange) {
            DateRangeFilter.TODAY -> {
                val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                cal.timeInMillis to System.currentTimeMillis()
            }
            DateRangeFilter.YESTERDAY -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -1)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                val endCal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -1)
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
                }
                cal.timeInMillis to endCal.timeInMillis
            }
            DateRangeFilter.THIS_WEEK -> {
                val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                cal.timeInMillis to System.currentTimeMillis()
            }
            DateRangeFilter.THIS_MONTH -> {
                val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                cal.timeInMillis to System.currentTimeMillis()
            }
            DateRangeFilter.THIS_YEAR -> {
                val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                cal.timeInMillis to System.currentTimeMillis()
            }
            DateRangeFilter.LIFETIME -> 0L to Long.MAX_VALUE
            DateRangeFilter.CUSTOM -> customStartMs to customEndMs
        }

        usages.filter {
            it.usageDate in start..end && (
                searchQuery.isBlank() ||
                it.productName.contains(searchQuery, ignoreCase = true) ||
                it.purpose.contains(searchQuery, ignoreCase = true) ||
                it.notes.contains(searchQuery, ignoreCase = true)
            )
        }
    }

    val totalUnitsUsed = filteredUsages.sumOf { it.quantity }
    val totalCostUsed = filteredUsages.sumOf { it.totalCost }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Product Usage / Personal Use", fontWeight = FontWeight.Bold)
                        Text(
                            "Track personal consumption & business samples",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (onOpenAddUsage != null) onOpenAddUsage() else showAddDialog = true
                },
                containerColor = ForestGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_usage_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Record Usage")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Date filter chips
            DateRangeSelectorRow(
                selectedRange = dateRange,
                onSelectRange = { viewModel.setDateRange(it) },
                onCustomRangeClick = { showCustomDateDialog = true }
            )

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by product, purpose, notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotBlank()) {
                    { IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") } }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Metrics Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Units Consumed",
                    value = "$totalUnitsUsed units",
                    subtitle = "${filteredUsages.size} entries",
                    icon = Icons.Default.Inventory2,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Total Usage Cost",
                    value = "₹%.2f".format(totalCostUsed),
                    subtitle = "Cost basis",
                    icon = Icons.Default.ReceiptLong,
                    modifier = Modifier.weight(1f)
                )
            }

            // Usages List
            if (filteredUsages.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.LocalDrink,
                    title = "No Usage Records Found",
                    description = "When you consume inventory or share samples with clients, record it here to keep your inventory accurate.",
                    actionText = "Record First Usage",
                    onActionClick = { showAddDialog = true }
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(filteredUsages, key = { it.id }) { usage ->
                        UsageCard(
                            usage = usage,
                            dateFormat = dateFormat,
                            onDelete = { usageToDelete = usage }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddProductUsageDialog(
            products = products,
            onDismiss = { showAddDialog = false },
            onSave = { newUsage ->
                viewModel.recordProductUsage(newUsage)
                showAddDialog = false
            }
        )
    }

    usageToDelete?.let { usage ->
        DeleteProtectionDialog(
            title = "Delete Usage Record?",
            whatWillBeDeleted = "Product Usage Entry",
            dateText = dateFormat.format(Date(usage.usageDate)),
            productText = usage.productName,
            quantityText = "${usage.quantity} units",
            amountText = "₹%.2f".format(usage.totalCost),
            onConfirm = {
                viewModel.deleteProductUsage(usage)
                usageToDelete = null
            },
            onDismiss = { usageToDelete = null }
        )
    }

    if (showCustomDateDialog) {
        CustomDateRangeDialog(
            initialStartMs = customStartMs,
            initialEndMs = customEndMs,
            onDismiss = { showCustomDateDialog = false },
            onApplyRange = { start, end ->
                viewModel.setCustomDateRange(start, end)
                showCustomDateDialog = false
            }
        )
    }
}

@Composable
fun UsageCard(
    usage: ProductUsage,
    dateFormat: SimpleDateFormat,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = usage.productName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = dateFormat.format(Date(usage.usageDate)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_usage_${usage.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete Usage",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ForestGreenPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = usage.purpose,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ForestGreenPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = "${usage.quantity} unit(s) • ₹%.2f".format(usage.totalCost),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (usage.notes.isNotBlank()) {
                Text(
                    text = "Note: ${usage.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
