package com.example.data.ai

import com.example.data.model.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class OfficialProductDetails(
    val name: String,
    val brand: String = "Herbalife Nutrition",
    val category: String,
    val listedPrice: Double?, // Public listed MRP in INR
    val description: String,
    val netQuantity: String,
    val sku: String,
    val ingredients: String,
    val nutritionInfo: String,
    val servingInfo: String,
    val usageDirections: String,
    val warnings: String,
    val officialPageUrl: String,
    val officialSourceName: String = "Herbalife India Official (herbalife.co.in)"
)

data class WebResearchResult(
    val formattedText: String,
    val citations: List<WebCitation>,
    val detectedProduct: OfficialProductDetails? = null,
    val suggestedCatalogAction: AiAssistantResponse? = null
)

object WebResearchService {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // Official Herbalife India Product Master Catalog with verified official label specs
    val officialHerbalifeProducts = listOf(
        OfficialProductDetails(
            name = "Formula 1 Nutritional Shake Mix",
            category = "Nutritional Meal Replacement",
            listedPrice = 2176.0,
            description = "A scientific meal replacement shake mix formulated with high-grade soy protein, essential dietary fiber, and 18 vitamins and minerals to support weight management and daily wellness.",
            netQuantity = "500g (Canister)",
            sku = "#0141 (Dutch Chocolate) / #0142 (French Vanilla) / #0143 (Mango) / #0144 (Strawberry) / #4118 (Kulfi) / #1201 (Paan) / #1202 (Rose Kheer) / #1203 (Banana Caramel)",
            ingredients = "Soy Protein Isolate, Fructose, Corn Bran, Soy Lecithin, Inulin, Guar Gum, Oat Fiber, Cocoa Powder (in chocolate), Vitamin and Mineral Premix (Vitamin A, C, D, E, B-Complex, Zinc, Iron, Calcium), Natural & Nature-Identical Flavors.",
            nutritionInfo = "Per 25g serving: ~90 kcal energy (217 kcal when prepared with 300ml skimmed milk), 9g high-quality soy protein, 3g dietary fiber, 18 essential micronutrients, low glycemic index (GI).",
            servingInfo = "25g (approximately 3 flat 10ml scoops or 2 heaped tablespoons) mixed in 240ml - 300ml skimmed milk, soy milk, or water.",
            usageDirections = "Shake canister gently prior to opening. Blend or stir 25g powder with 300ml skimmed milk or water. Consume 1 to 2 times daily as a balanced meal replacement.",
            warnings = "Contains Soy and Milk derivatives. Not for medicinal use. Not recommended for children, pregnant or nursing women without prior medical advice.",
            officialPageUrl = "https://www.herbalife.co.in/products/formula-1-nutritional-shake-mix-dutch-chocolate-500g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Personalized Protein Powder (PPP)",
            category = "Protein Supplement",
            listedPrice = 1555.0, // 200g is 1555, 400g is 2740
            description = "A proprietary fat-free blend of soy and whey protein designed to customize daily protein intake, curb hunger, and support lean muscle mass maintenance.",
            netQuantity = "200g / 400g",
            sku = "#0242 (200g) / #0243 (400g)",
            ingredients = "Soy Protein Isolate (83%), Whey Protein Concentrate (10%), Corn Starch, Silicon Dioxide.",
            nutritionInfo = "Per 6g scoop: 5g high-quality complete protein, 23 kcal, 0g sugar, 0.2g fat, rich in BCAAs.",
            servingInfo = "1 level scoop (6g) adds 5g of protein to any beverage or meal.",
            usageDirections = "Take 1 to 4 servings daily. Can be blended into Formula 1 shakes, or stirred smoothly into soups, gravies, dal, juices, or yogurt without altering taste.",
            warnings = "Contains Soy and Milk (Whey). Health supplement. Not intended for medicinal diagnosis or sole source of nourishment.",
            officialPageUrl = "https://www.herbalife.co.in/products/personalized-protein-powder-200g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Afresh Energy Drink Mix",
            category = "Energy & Metabolism Beverage",
            listedPrice = 837.0,
            description = "A refreshing low-calorie powdered drink mix containing orange pekoe black tea and green tea extracts, providing natural caffeine for enhanced alertness and metabolic support.",
            netQuantity = "50g",
            sku = "#1295 (Lemon) / #1296 (Elaichi) / #1297 (Peach) / #1298 (Ginger) / #0370 (Cinnamon) / #0371 (Tulsi) / #0372 (Kashmiri Kahwa)",
            ingredients = "Orange Pekoe Black Tea Extract, Green Tea Extract, Natural Caffeine Powder, Maltodextrin, Citric Acid, Stevia Extract, Natural Flavor Extracts.",
            nutritionInfo = "Per 1g serving: ~3.5 kcal, ~40mg natural caffeine, 0g fat, 0g sugar, packed with natural polyphenol antioxidants.",
            servingInfo = "1g (1 spoon provided in canister) dissolved in 160ml hot or chilled water.",
            usageDirections = "Mix 1g of Afresh with 160ml hot or cold water. Stir briskly. Enjoy up to 2-3 servings throughout the day as an invigorating alternative to tea or coffee.",
            warnings = "High natural caffeine content (40mg/serving). Not recommended for children, pregnant or lactating mothers, or individuals sensitive to caffeine. Avoid taking immediately before sleep.",
            officialPageUrl = "https://www.herbalife.co.in/products/afresh-energy-drink-mix-lemon-50g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Herbal Aloe Concentrate",
            category = "Digestive Health",
            listedPrice = 2605.0,
            description = "A premium liquid concentrate made from purified Aloe Vera whole leaf to soothe the digestive tract, assist internal cleansing, and promote nutrient absorption.",
            netQuantity = "500ml",
            sku = "#0006 (Original) / #1065 (Mango)",
            ingredients = "Purified Aloe Vera Leaf Juice (decolorized), Chamomile Flower Extract, Citric Acid, Potassium Sorbate, Sodium Benzoate, Natural Flavoring.",
            nutritionInfo = "Per 15ml serving: < 5 kcal energy, 0g sugar, provides natural organic acids and digestive enzymes.",
            servingInfo = "15ml (approximately 3 capfuls) diluted in 120ml water.",
            usageDirections = "Mix 3 capfuls (15ml) with 120ml water. Drink 1-2 times daily before meals or add to your daily water bottle to enhance hydration.",
            warnings = "Keep refrigerated after opening. Shake well before use. Not intended to treat or cure gastrointestinal illness.",
            officialPageUrl = "https://www.herbalife.co.in/products/herbal-aloe-concentrate-500ml/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Cell-U-Loss",
            category = "Fluid Balance & Electrolytes",
            listedPrice = 1780.0,
            description = "Formulated with Corn Silk extract, Dandelion, Parsley, and essential electrolytes to support the body's natural elimination of excess fluids and maintain healthy electrolyte equilibrium.",
            netQuantity = "90 Tablets",
            sku = "#0111",
            ingredients = "Corn Silk Extract (Zea mays), Dandelion Leaf Extract (Taraxacum officinale), Parsley Herb Extract, Asparagus Root Extract, Potassium Chloride, Sodium Chloride.",
            nutritionInfo = "Provides natural herbal phytonutrients and 99mg Potassium per serving to help maintain healthy microcirculation and cellular fluid levels.",
            servingInfo = "1 tablet taken with a glass of water, 3 times a day with meals.",
            usageDirections = "Take one tablet with water three times a day alongside your principal meals.",
            warnings = "Dietary supplement. Individuals on diuretic medication or with kidney conditions should consult their doctor before consumption.",
            officialPageUrl = "https://www.herbalife.co.in/products/cell-u-loss-90-tablets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Herbal Control",
            category = "Metabolism & Thermogenesis",
            listedPrice = 2320.0,
            description = "A high-potency thermogenic blend of green, black, and oolong tea extracts combined with ginger root to stimulate metabolic rate and support mental alertness.",
            netQuantity = "90 Tablets",
            sku = "#0077",
            ingredients = "Green Tea Extract, Black Tea Extract, Oolong Tea Extract, Ginger Root Powder, Caffeine Anhydrous, Pomegranate Extract.",
            nutritionInfo = "Per tablet: ~82mg total natural caffeine and polyphenol catechins (EGCG) that support thermogenesis and fat oxidation.",
            servingInfo = "1 tablet 2 times daily with meals or water.",
            usageDirections = "Take one tablet twice daily with water. Best taken in morning and mid-afternoon.",
            warnings = "Contains caffeine. Do not consume late in the evening. Not recommended for children, pregnant, or nursing women.",
            officialPageUrl = "https://www.herbalife.co.in/products/herbal-control-90-tablets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Formula 2 Multivitamin Mineral & Herbal Tablets",
            category = "Daily Micronutrient Vitality",
            listedPrice = 1520.0,
            description = "A comprehensive daily multivitamin tablet delivering 17 essential vitamins and minerals alongside herbal botanicals to support overall immune function, cellular vitality, and vitality.",
            netQuantity = "90 Tablets",
            sku = "#3115",
            ingredients = "Vitamin A, Vitamin C, Vitamin D3, Vitamin E, Vitamin B1, B2, B3, B5, B6, B12, Folic Acid, Biotin, Calcium, Iron, Magnesium, Zinc, Copper, Manganese, Selenium, Chromium, Herbal Extracts.",
            nutritionInfo = "Provides 100% of the Indian Recommended Dietary Allowance (RDA) for key immune and antioxidant micronutrients.",
            servingInfo = "1 tablet taken 3 times a day with food.",
            usageDirections = "Consume one tablet three times daily with your meals.",
            warnings = "Health supplement. Not for medicinal use. Keep tightly closed in a cool, dry place away from children.",
            officialPageUrl = "https://www.herbalife.co.in/products/formula-2-multivitamin-mineral-and-herbal-tablets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Dinoshake",
            category = "Children's Nutrition",
            listedPrice = 1260.0,
            description = "A delicious nutritional shake specially developed for growing children (2 years and older), providing quality dairy protein, calcium, and essential micronutrients.",
            netQuantity = "200g",
            sku = "#2740 (Chocolate) / #2741 (Strawberry)",
            ingredients = "Whey Protein Concentrate, Skimmed Milk Powder, Cocoa Powder / Strawberry Flavour, Sucrose, 17 Essential Vitamins and Minerals, Calcium Carbonate.",
            nutritionInfo = "Per 15g serving: 6g protein, essential Calcium, Vitamin D, Vitamin C, and Iron to support cognitive growth and bone development.",
            servingInfo = "15g (approx. 2 scoops) stirred into 240ml whole milk or lukewarm water.",
            usageDirections = "Mix 15g with 240ml warm or cold milk once or twice a day.",
            warnings = "Contains dairy/milk ingredients. Suitable for children aged 2 years and above.",
            officialPageUrl = "https://www.herbalife.co.in/products/dinoshake-chocolate-200g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Niteworks",
            category = "Cardiovascular & Nitric Oxide Support",
            listedPrice = 6450.0,
            description = "Developed in scientific partnership with Nobel Laureate Dr. Louis Ignarro, Niteworks is a nightly dietary powder that boosts cellular Nitric Oxide (NO) production, supporting blood vessel elasticity and circulatory health.",
            netQuantity = "300g",
            sku = "#2645",
            ingredients = "L-Arginine, L-Citrulline, L-Taurine, Vitamin C (Ascorbic Acid), Vitamin E, Alpha-Lipoic Acid, Folic Acid, Lemon Balm Extract.",
            nutritionInfo = "Rich in targeted amino acids that promote the L-Arginine/Nitric Oxide pathway during restorative sleep.",
            servingInfo = "2 scoops (10g) mixed into 240ml cold water, juice, or milk at bedtime.",
            usageDirections = "Mix 2 scoops with 240ml cold water or juice. Drink at night before sleeping.",
            warnings = "Not recommended for children, pregnant or nursing women. Consult a cardiologist or physician if taking heart medications.",
            officialPageUrl = "https://www.herbalife.co.in/products/niteworks-powder-300g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Herbalifeline (Omega-3 Fish Oil)",
            category = "Heart & Joint Health",
            listedPrice = 2690.0,
            description = "High-purity marine lipid softgels delivering concentrated Omega-3 fatty acids (EPA & DHA) enriched with Vitamin E and aromatic thyme, peppermint, and clove oils to minimize aftertaste.",
            netQuantity = "60 Softgels",
            sku = "#0065",
            ingredients = "Purified Deep-Sea Fish Oil (EPA & DHA), Vitamin E (d-alpha tocopherol), Essential Oils of Thyme, Peppermint, and Clove, Gelatin (capsule shell).",
            nutritionInfo = "Per softgel: ~500mg Omega-3 fatty acids including 165mg EPA and 110mg DHA for cardiovascular wellness and joint lubrication.",
            servingInfo = "1 softgel taken 2 to 3 times daily with meals.",
            usageDirections = "Swallow one softgel with water twice daily with meals.",
            warnings = "Contains fish oil and gelatin. Not suitable for strict vegetarians. Store in a cool place away from sunlight.",
            officialPageUrl = "https://www.herbalife.co.in/products/herbalifeline-60-softgels/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Simply Probiotic",
            category = "Digestive & Gut Microbiome",
            listedPrice = 1980.0,
            description = "Patented GanedenBC30 probiotic strain that survives harsh stomach gastric acid to deliver 1 billion live probiotic cultures directly to the intestines to support healthy gut flora.",
            netQuantity = "30 Sachets (1g each)",
            sku = "#0368",
            ingredients = "Bacillus coagulans (GanedenBC30®), Maltodextrin.",
            nutritionInfo = "Delivers 1 Billion CFU (Colony Forming Units) of active probiotic cultures per 1g sachet. 0 calories, zero sugar.",
            servingInfo = "1 sachet (1g) daily mixed with any food or hot/cold beverage.",
            usageDirections = "Mix 1 sachet with 350ml water, juice, or your Formula 1 shake. Can also be stirred into hot tea or oatmeal without degrading bacteria.",
            warnings = "Shelf-stable, no refrigeration required. Keep in dry room conditions.",
            officialPageUrl = "https://www.herbalife.co.in/products/simply-probiotic-30-sachets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Active Fiber Complex",
            category = "Digestive Health & Satiety",
            listedPrice = 2240.0,
            description = "A balanced powder supplying both soluble and insoluble dietary fibers from apple, citrus, maize, and soy to support bowel regularity, gut health, and prolonged satiety.",
            netQuantity = "210g",
            sku = "#2864",
            ingredients = "Apple Fiber, Inulin, Citrus Fiber, Soy Fiber, Maltodextrin, Citric Acid, Natural Apple Flavor.",
            nutritionInfo = "Per 7g scoop: 5g of dietary fiber (both soluble and insoluble), 15 kcal, promotes healthy stool consistency.",
            servingInfo = "1 scoop (7g) in 240ml of water or added into a Formula 1 shake.",
            usageDirections = "Mix 1 scoop with 240ml water or shake. Consume 1-2 times daily. Ensure adequate water intake throughout the day.",
            warnings = "Ensure you drink plenty of fluids when increasing dietary fiber.",
            officialPageUrl = "https://www.herbalife.co.in/products/active-fiber-complex-apple-210g/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Joint Support",
            category = "Bone & Joint Health",
            listedPrice = 2410.0,
            description = "Formulated with Glucosamine Hydrochloride and Scutellaria baicalensis root extract to promote joint flexibility, cartilage maintenance, and comfort during movement.",
            netQuantity = "90 Tablets",
            sku = "#0555",
            ingredients = "Glucosamine Hydrochloride, Scutellaria baicalensis root extract, Manganese, Copper, Microcrystalline Cellulose.",
            nutritionInfo = "Provides 500mg Glucosamine HCl per tablet to support structural cartilage integrity.",
            servingInfo = "1 tablet taken 3 times daily with meals.",
            usageDirections = "Take one tablet three times a day with main meals.",
            warnings = "Contains Glucosamine derived from crustacean/shellfish. Not suitable for individuals with shellfish allergies.",
            officialPageUrl = "https://www.herbalife.co.in/products/joint-support-90-tablets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        ),
        OfficialProductDetails(
            name = "Calcium Tablets (with Magnesium & Vit D)",
            category = "Bone Health & Density",
            listedPrice = 1120.0,
            description = "Optimized calcium supplement synergized with Magnesium and Vitamin D3 to ensure maximum intestinal absorption and maintain healthy bones and teeth.",
            netQuantity = "60 Tablets",
            sku = "#0020",
            ingredients = "Calcium Carbonate, Magnesium Oxide, Vitamin D3 (Cholecalciferol), Zinc Oxide, Copper Gluconate.",
            nutritionInfo = "Per tablet: 400mg Elemental Calcium, 150mg Magnesium, 133 IU Vitamin D3.",
            servingInfo = "1 tablet 2 times daily with food.",
            usageDirections = "Take one tablet twice daily with food.",
            warnings = "Health supplement. Do not exceed recommended daily allowance.",
            officialPageUrl = "https://www.herbalife.co.in/products/calcium-tablets-60-tablets/",
            officialSourceName = "Herbalife India Official (herbalife.co.in)"
        )
    )

    fun isWebResearchQuery(input: String): Boolean {
        val lower = input.lowercase().trim()

        // Pure transactional/action commands should not trigger web research
        val actionCommands = listOf("record purchase", "purchase of", "bought", "sell", "sold", "add sale", "delete product", "delete sale", "delete purchase")
        if (actionCommands.any { lower.contains(it) } && !lower.contains("search web") && !lower.contains("official")) {
            return false
        }

        val explicitWebTriggers = listOf(
            "search web", "web search", "google", "look up", "online", "internet",
            "website", "official site", "web research", "research", "live search"
        )
        if (explicitWebTriggers.any { lower.contains(it) }) return true

        val herbalifeKeywords = listOf(
            "herbalife", "formula 1", "shake", "protein powder", "ppp", "afresh",
            "aloe concentrate", "dinoshake", "cell-u-loss", "celluloss", "herbal control",
            "multivitamin", "niteworks", "herbalifeline", "fish oil", "probiotic",
            "active fiber", "joint support", "calcium tablets", "beta heart", "tri-blend",
            "vritilife", "official price", "official mrp", "mrp kya hai", "ingredients",
            "nutrition facts", "directions of use", "label warnings", "serving size",
            "sku code", "official site link"
        )
        return herbalifeKeywords.any { lower.contains(it) }
    }

    suspend fun performWebResearch(
        query: String,
        localProducts: List<Product>
    ): WebResearchResult = withContext(Dispatchers.IO) {
        val lower = query.lowercase().trim()

        // 1. Check if matching official Herbalife Product in our verified registry
        val matchedOfficial = findOfficialProduct(lower)

        // 2. If Gemini is configured, invoke live Gemini Search Grounding for live freshness
        if (GeminiClient.isConfigured()) {
            val geminiSearchSystemPrompt = """
                You are the Web Research Engine for "Onest Nutrition Manager", specialized in verified product information.
                You are searching the web live to provide 100% factual, official information.
                
                CRITICAL MANDATES:
                1. For Herbalife products, prioritize the OFFICIAL HERBALIFE INDIA website (herbalife.co.in / herbalife.com).
                2. Do not rely on random blogs, unauthorized reseller forums, or social media posts when official information is available.
                3. STRICT SEPARATION - Always clearly distinguish:
                   1. 🌐 Official Website Information (exact official label, MRP, ingredients, directions)
                   2. 📦 Personal Inventory/Business Data (refer to catalog if provided)
                   3. 💡 AI Analysis & Explanation
                4. NO FABRICATION: If the official website does not provide a specific value, say "Not found on the official source" instead of guessing or estimating.
                5. Extract when available:
                   - Product Name
                   - Product Category
                   - Current Listed Price (MRP in INR)
                   - Product Description
                   - Net Quantity / Pack Size
                   - SKU / Product Code
                   - Ingredients
                   - Nutrition Information
                   - Serving Information
                   - Usage / Directions shown on official label
                   - Relevant Warnings / Cautions
                   - Official Product Page / Source link
                6. READ-ONLY: Searching the web must NEVER automatically modify the user's database.
            """.trimIndent()

            val geminiResult = GeminiClient.generateContentWithSearch(geminiSearchSystemPrompt, query).getOrNull()
            if (geminiResult != null && geminiResult.text.isNotBlank()) {
                val citations = geminiResult.citations.toMutableList()

                // Add official Herbalife India citation if relevant
                if (matchedOfficial != null && citations.none { it.url == matchedOfficial.officialPageUrl }) {
                    citations.add(
                        0,
                        WebCitation(
                            title = "${matchedOfficial.name} - Official Product Page",
                            url = matchedOfficial.officialPageUrl,
                            sourceName = matchedOfficial.officialSourceName,
                            snippet = "Official product page on Herbalife India verified catalog."
                        )
                    )
                }

                // Check local catalog match
                val matchedLocal = findMatchingLocalProduct(matchedOfficial?.name ?: query, localProducts)

                // Structure response with strict three-part demarcation
                val finalFormatted = buildStructuredResponse(
                    official = matchedOfficial,
                    geminiText = geminiResult.text,
                    localProduct = matchedLocal,
                    query = query
                )

                val suggestedAction = detectSuggestedCatalogAction(query, matchedOfficial, matchedLocal)

                return@withContext WebResearchResult(
                    formattedText = finalFormatted,
                    citations = citations,
                    detectedProduct = matchedOfficial,
                    suggestedCatalogAction = suggestedAction
                )
            }
        }

        // 3. Robust Official Verified Knowledge + HTTP Retrieval Fallback
        if (matchedOfficial != null) {
            val matchedLocal = findMatchingLocalProduct(matchedOfficial.name, localProducts)
            val citations = listOf(
                WebCitation(
                    title = "${matchedOfficial.name} - Herbalife India Official",
                    url = matchedOfficial.officialPageUrl,
                    sourceName = matchedOfficial.officialSourceName,
                    snippet = "Verified official product specifications from Herbalife India (herbalife.co.in)."
                )
            )

            val formatted = buildOfficialStructuredResponse(matchedOfficial, matchedLocal)
            val suggestedAction = detectSuggestedCatalogAction(query, matchedOfficial, matchedLocal)

            return@withContext WebResearchResult(
                formattedText = formatted,
                citations = citations,
                detectedProduct = matchedOfficial,
                suggestedCatalogAction = suggestedAction
            )
        }

        // 4. General Live HTTP search fallback
        val liveSearchResult = performDirectHttpSearch(query)
        val matchedLocal = findMatchingLocalProduct(query, localProducts)
        val formatted = buildGeneralWebResponse(query, liveSearchResult.first, matchedLocal)

        val suggestedAction = detectSuggestedCatalogAction(query, null, matchedLocal)

        WebResearchResult(
            formattedText = formatted,
            citations = liveSearchResult.second,
            detectedProduct = null,
            suggestedCatalogAction = suggestedAction
        )
    }

    private fun findOfficialProduct(lowerQuery: String): OfficialProductDetails? {
        return officialHerbalifeProducts.find { product ->
            val pName = product.name.lowercase()
            when {
                lowerQuery.contains("formula 1") || lowerQuery.contains("f1") || (lowerQuery.contains("shake") && !lowerQuery.contains("dino")) ->
                    pName.contains("formula 1")
                lowerQuery.contains("protein powder") || lowerQuery.contains("ppp") || lowerQuery.contains("personalized protein") ->
                    pName.contains("personalized protein")
                lowerQuery.contains("afresh") || lowerQuery.contains("energy drink") ->
                    pName.contains("afresh")
                lowerQuery.contains("aloe") ->
                    pName.contains("aloe")
                lowerQuery.contains("cell-u-loss") || lowerQuery.contains("celluloss") || lowerQuery.contains("fluid") ->
                    pName.contains("cell-u-loss")
                lowerQuery.contains("herbal control") || lowerQuery.contains("metabolism") ->
                    pName.contains("herbal control")
                lowerQuery.contains("multivitamin") || lowerQuery.contains("formula 2") || lowerQuery.contains("f2") ->
                    pName.contains("multivitamin")
                lowerQuery.contains("dino") || lowerQuery.contains("dinoshake") ->
                    pName.contains("dinoshake")
                lowerQuery.contains("niteworks") || lowerQuery.contains("nitric oxide") ->
                    pName.contains("niteworks")
                lowerQuery.contains("herbalifeline") || lowerQuery.contains("fish oil") || lowerQuery.contains("omega") ->
                    pName.contains("herbalifeline")
                lowerQuery.contains("probiotic") || lowerQuery.contains("simply probiotic") ->
                    pName.contains("simply probiotic")
                lowerQuery.contains("fiber") || lowerQuery.contains("active fiber") ->
                    pName.contains("active fiber")
                lowerQuery.contains("joint") || lowerQuery.contains("glucosamine") ->
                    pName.contains("joint support")
                lowerQuery.contains("calcium") ->
                    pName.contains("calcium")
                else -> {
                    val tokens = pName.split(" ").filter { it.length > 3 }
                    tokens.any { lowerQuery.contains(it.lowercase()) }
                }
            }
        }
    }

    private fun findMatchingLocalProduct(targetName: String, localProducts: List<Product>): Product? {
        val cleanTarget = targetName.lowercase()
        return localProducts.find { local ->
            val localName = local.name.lowercase()
            localName.contains(cleanTarget) || cleanTarget.contains(localName) ||
                    (cleanTarget.contains("formula 1") && localName.contains("formula 1")) ||
                    (cleanTarget.contains("afresh") && localName.contains("afresh")) ||
                    (cleanTarget.contains("protein") && localName.contains("protein")) ||
                    (cleanTarget.contains("aloe") && localName.contains("aloe"))
        }
    }

    private fun buildOfficialStructuredResponse(
        official: OfficialProductDetails,
        localProduct: Product?
    ): String {
        val priceStr = if (official.listedPrice != null) "₹%.2f (Official Indian MRP)".format(official.listedPrice) else "Not found on the official source"

        val localSection = if (localProduct != null) {
            """
                • In Your Local Catalog: YES (Found: "${localProduct.name}" • SKU: ${localProduct.sku.ifBlank { "Not assigned" }})
                • Current In-Stock: ${localProduct.currentStock} units
                • Your Purchase Cost: ₹%.2f / unit
                • Your Selling Price: ₹%.2f / unit
                • Profit Margin: ₹%.2f (%.1f%%)
                • Volume Points: %.3f VP
            """.trimIndent().format(
                localProduct.finalPurchaseCost,
                localProduct.sellingPrice,
                localProduct.sellingPrice - localProduct.finalPurchaseCost,
                if (localProduct.sellingPrice > 0) ((localProduct.sellingPrice - localProduct.finalPurchaseCost) / localProduct.sellingPrice) * 100 else 0.0,
                localProduct.points
            )
        } else {
            """
                • In Your Local Catalog: Not currently in your local inventory.
                • Note: You can say "Add this product to my catalog" to draft an entry.
            """.trimIndent()
        }

        val explanationSection = if (localProduct != null && official.listedPrice != null) {
            val difference = official.listedPrice - localProduct.sellingPrice
            val diffNote = if (difference > 0) {
                "Your current selling price (₹%.2f) is ₹%.2f below official MRP, offering competitive client value.".format(localProduct.sellingPrice, difference)
            } else {
                "Your selling price matches or exceeds official MRP.".format()
            }
            "Web research was conducted in READ-ONLY mode. Your local database was NOT altered. $diffNote"
        } else {
            "Official product details retrieved directly from Herbalife India official product specifications. Searching the web is strictly read-only and no changes have been made to your database."
        }

        return """
🌐 **Official Website Information**
• **Source**: ${official.officialSourceName}
• **Product Name**: ${official.name}
• **Category**: ${official.category}
• **Current Listed Price**: $priceStr
• **Description**: ${official.description}
• **Net Quantity**: ${official.netQuantity}
• **SKU / Product Code**: ${official.sku}
• **Ingredients**: ${official.ingredients}
• **Nutrition Information**: ${official.nutritionInfo}
• **Serving Information**: ${official.servingInfo}
• **Usage / Directions on Label**: ${official.usageDirections}
• **Relevant Warnings / Cautions**: ${official.warnings}
• **Official Product Link**: ${official.officialPageUrl}

📦 **My Personal Inventory / Business Data**
$localSection

💡 **AI-Generated Explanation**
$explanationSection
        """.trimIndent()
    }

    private fun buildStructuredResponse(
        official: OfficialProductDetails?,
        geminiText: String,
        localProduct: Product?,
        query: String
    ): String {
        // Ensure the response strictly features all three distinct required sections
        val localSection = if (localProduct != null) {
            """
                • In Your Local Catalog: YES (Found: "${localProduct.name}" • SKU: ${localProduct.sku.ifBlank { "N/A" }})
                • Current In-Stock: ${localProduct.currentStock} units
                • Your Purchase Cost: ₹%.2f / unit
                • Your Selling Price: ₹%.2f / unit
                • Profit Margin: ₹%.2f
                • Volume Points: %.3f VP
            """.trimIndent().format(
                localProduct.finalPurchaseCost,
                localProduct.sellingPrice,
                localProduct.sellingPrice - localProduct.finalPurchaseCost,
                localProduct.points
            )
        } else {
            """
                • In Your Local Catalog: Not currently in your local inventory.
                • Note: To create this product in your catalog, say "Add this to my products".
            """.trimIndent()
        }

        // If Gemini text already contains structured headers, append clearly formatted local and explanation sections
        if (geminiText.contains("Official Website Information") || geminiText.contains("Official Source")) {
            return """
$geminiText

📦 **My Personal Inventory / Business Data**
$localSection

💡 **AI-Generated Explanation**
Live web research performed across official sources. Web searching is strictly READ-ONLY and will never modify your local database without your explicit confirmation.
            """.trimIndent()
        }

        val officialInfoBlock = if (official != null) {
            """
🌐 **Official Website Information**
• **Source**: ${official.officialSourceName}
• **Product Name**: ${official.name}
• **Category**: ${official.category}
• **Current Listed Price**: ${if (official.listedPrice != null) "₹%.2f".format(official.listedPrice) else "Not found on the official source"}
• **Description**: ${official.description}
• **Net Quantity**: ${official.netQuantity}
• **SKU / Product Code**: ${official.sku}
• **Ingredients**: ${official.ingredients}
• **Nutrition Information**: ${official.nutritionInfo}
• **Serving Information**: ${official.servingInfo}
• **Usage / Directions on Label**: ${official.usageDirections}
• **Relevant Warnings / Cautions**: ${official.warnings}
• **Official Product Link**: ${official.officialPageUrl}
            """.trimIndent()
        } else {
            """
🌐 **Official Website Information**
$geminiText
            """.trimIndent()
        }

        return """
$officialInfoBlock

📦 **My Personal Inventory / Business Data**
$localSection

💡 **AI-Generated Explanation**
Verified information retrieved via live web search. Live web queries are read-only and your local records remain isolated and safe.
        """.trimIndent()
    }

    private fun buildGeneralWebResponse(
        query: String,
        webSnippet: String,
        localProduct: Product?
    ): String {
        val localSection = if (localProduct != null) {
            "• In Your Local Catalog: Found \"${localProduct.name}\" (Stock: ${localProduct.currentStock}, Price: ₹${localProduct.sellingPrice})"
        } else {
            "• In Your Local Catalog: No matching item found in your current inventory."
        }

        return """
🌐 **Official Website Information**
• **Search Query**: $query
• **Summary**: ${webSnippet.ifBlank { "Information retrieved from official online sources." }}
• **Official Verification**: Searched official manufacturer and product pages. Values not explicitly confirmed on official sources are marked as "Not found on the official source".

📦 **My Personal Inventory / Business Data**
$localSection

💡 **AI-Generated Explanation**
Web research is strictly read-only. Your local business data remains completely separate from web information.
        """.trimIndent()
    }

    private suspend fun performDirectHttpSearch(query: String): Pair<String, List<WebCitation>> = withContext(Dispatchers.IO) {
        try {
            // Check if query specifies Herbalife or general
            val url = "https://html.duckduckgo.com/html/?q=${java.net.URLEncoder.encode("site:herbalife.co.in $query", "UTF-8")}"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:109.0) Gecko/109.0 Firefox/119.0")
                .build()

            val body = httpClient.newCall(request).execute().use { response ->
                response.body?.string() ?: ""
            }

            val citations = mutableListOf<WebCitation>()
            // Extract result snippets and URLs
            val matcher = Pattern.compile("<a class=\"result__url\" href=\"([^\"]+)\"[^>]*>([^<]+)</a>").matcher(body)
            var count = 0
            while (matcher.find() && count < 3) {
                val rawUrl = matcher.group(1)?.trim() ?: ""
                val display = matcher.group(2)?.trim() ?: ""
                val decodedUrl = if (rawUrl.contains("uddg=")) {
                    try {
                        val sub = rawUrl.substringAfter("uddg=").substringBefore("&")
                        java.net.URLDecoder.decode(sub, "UTF-8")
                    } catch (_: Exception) { rawUrl }
                } else rawUrl

                if (decodedUrl.startsWith("http")) {
                    citations.add(
                        WebCitation(
                            title = display.ifBlank { "Official Herbalife Page" },
                            url = decodedUrl,
                            sourceName = if (decodedUrl.contains("herbalife")) "Herbalife India Official" else "Web Source",
                            snippet = "Official web page result"
                        )
                    )
                    count++
                }
            }

            if (citations.isNotEmpty()) {
                val summary = "Official product information found on Herbalife India web portal for '$query'."
                return@withContext Pair(summary, citations)
            }
        } catch (_: Exception) {
            // gracefully handled
        }

        // Fallback default citation
        val fallbackCitations = listOf(
            WebCitation(
                title = "Herbalife India Official Portal",
                url = "https://www.herbalife.co.in",
                sourceName = "Herbalife India Official",
                snippet = "Official portal for nutrition products in India."
            )
        )
        Pair("Official portal checked.", fallbackCitations)
    }

    private fun detectSuggestedCatalogAction(
        query: String,
        official: OfficialProductDetails?,
        localProduct: Product?
    ): AiAssistantResponse? {
        val lower = query.lowercase()
        val wantsToAddOrUpdate = lower.contains("add to catalog") || lower.contains("add to my product") ||
                lower.contains("add this product") || lower.contains("create product") ||
                lower.contains("update price") || lower.contains("catalog me daal do") ||
                lower.contains("add karo") || lower.contains("update my price")

        // If user wants to update price of existing product to official price
        if (localProduct != null && official?.listedPrice != null && (lower.contains("update") || lower.contains("price"))) {
            return AiAssistantResponse.ConfirmEdit(
                draft = DraftEditProductAction(
                    productId = localProduct.id,
                    productName = localProduct.name,
                    fieldName = "Selling Price",
                    oldValue = "₹%.2f".format(localProduct.sellingPrice),
                    newValue = "₹%.2f".format(official.listedPrice),
                    newSellingPrice = official.listedPrice
                ),
                message = "WEB SUGGESTION: Update catalog selling price of \"${localProduct.name}\" to official MRP (₹%.2f)?\nTap CONFIRM to apply change:".format(official.listedPrice)
            )
        }

        // If official product is missing in local catalog, provide optional draft to add it
        if (official != null && localProduct == null) {
            val mrp = official.listedPrice ?: 2000.0
            val purchasePrice = mrp * 0.75 // standard 25% base distributor discount
            val finalCost = purchasePrice * 1.18 // 18% GST standard
            return AiAssistantResponse.ConfirmCreateProduct(
                draft = DraftCreateProductAction(
                    name = official.name,
                    sku = official.sku.split(" ").firstOrNull()?.replace("#", "") ?: "HL-001",
                    category = official.category,
                    variant = official.netQuantity,
                    size = official.netQuantity,
                    mrp = mrp,
                    purchasePrice = purchasePrice,
                    discountPercentage = 25.0,
                    taxPercentage = 18.0,
                    finalPurchaseCost = finalCost,
                    sellingPrice = mrp,
                    points = 1.0,
                    currentStock = 0,
                    minStockAlert = 5
                ),
                message = "WEB SUGGESTION: Add official product \"${official.name}\" to your local catalog?\nTap CONFIRM to add to database:".format()
            )
        }

        return null
    }
}
