package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.BorrowedProduct
import com.example.data.model.Product
import com.example.ui.theme.ForestGreenPrimary
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBorrowedProductDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (BorrowedProduct) -> Unit
) {
    var personName by remember { mutableStateOf("") }
    var contactInfo by remember { mutableStateOf("") }
    var selectedProductId by remember { mutableStateOf<Long?>(products.firstOrNull()?.id) }
    var expandedProductDropdown by remember { mutableStateOf(false) }
    val selectedProduct = products.find { it.id == selectedProductId }

    var quantityStr by remember { mutableStateOf("1") }
    var borrowDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var expectedReturnDateMs by remember { mutableStateOf<Long?>(null) }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val borrowDateDisplay = dateFormat.format(Date(borrowDateMs))
    val returnDateDisplay = expectedReturnDateMs?.let { dateFormat.format(Date(it)) } ?: "Not Set (Tap to choose)"

    val qty = quantityStr.toIntOrNull() ?: 1
    val unitCost = selectedProduct?.finalPurchaseCost ?: 0.0

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Borrow Product (Stock Inflow)", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    if (personName.isBlank()) {
                                        errorMessage = "Please enter the lender/person's name"
                                        return@Button
                                    }
                                    val prod = selectedProduct ?: run {
                                        errorMessage = "Please select a product"
                                        return@Button
                                    }
                                    if (qty <= 0) {
                                        errorMessage = "Quantity must be at least 1"
                                        return@Button
                                    }

                                    val borrowed = BorrowedProduct(
                                        personOrBusinessName = personName.trim(),
                                        contactNumber = contactInfo.trim().ifEmpty { null },
                                        productId = prod.id,
                                        productName = prod.name,
                                        quantityBorrowed = qty,
                                        quantityReturned = 0,
                                        unitValue = unitCost,
                                        totalValue = unitCost * qty,
                                        dateReceived = borrowDateMs,
                                        expectedReturnDate = expectedReturnDateMs,
                                        status = "BORROWED",
                                        notes = notes.trim()
                                    )
                                    onSave(borrowed)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_borrowed_button")
                            ) {
                                Text("Record Borrowed Stock")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(4.dp))

                    if (errorMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Lender details
                    Text("Lender / Distributor Info", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = personName,
                        onValueChange = {
                            personName = it
                            errorMessage = null
                        },
                        label = { Text("Person / Distributor Name *") },
                        placeholder = { Text("e.g. Ramesh Patel") },
                        modifier = Modifier.fillMaxWidth().testTag("borrow_person_input")
                    )

                    OutlinedTextField(
                        value = contactInfo,
                        onValueChange = { contactInfo = it },
                        label = { Text("Contact Number (Optional)") },
                        placeholder = { Text("e.g. +91 9876543210") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("borrow_contact_input")
                    )

                    // Product Selector
                    Text("Product Borrowed", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    if (products.isEmpty()) {
                        Text("No products exist in database.", color = MaterialTheme.colorScheme.error)
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = expandedProductDropdown,
                            onExpandedChange = { expandedProductDropdown = !expandedProductDropdown }
                        ) {
                            OutlinedTextField(
                                value = selectedProduct?.name ?: "Select Product",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProductDropdown) },
                                modifier = Modifier.fillMaxWidth().menuAnchor().testTag("borrow_product_dropdown")
                            )
                            ExposedDropdownMenu(
                                expanded = expandedProductDropdown,
                                onDismissRequest = { expandedProductDropdown = false }
                            ) {
                                products.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text("${p.name} (Current Stock: ${p.currentStock})") },
                                        onClick = {
                                            selectedProductId = p.id
                                            expandedProductDropdown = false
                                            errorMessage = null
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Quantity and Borrow Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = {
                                quantityStr = it
                                errorMessage = null
                            },
                            label = { Text("Quantity *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("borrow_quantity_input")
                        )

                        OutlinedTextField(
                            value = borrowDateDisplay,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Borrow Date") },
                            trailingIcon = {
                                IconButton(onClick = {
                                    val cal = Calendar.getInstance().apply { timeInMillis = borrowDateMs }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            borrowDateMs = c.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date")
                                }
                            },
                            modifier = Modifier.weight(1.2f)
                        )
                    }

                    // Expected Return Date
                    OutlinedTextField(
                        value = returnDateDisplay,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Expected Return Date (Optional)") },
                        trailingIcon = {
                            IconButton(onClick = {
                                val cal = Calendar.getInstance().apply {
                                    timeInMillis = expectedReturnDateMs ?: (System.currentTimeMillis() + 7 * 86400000L)
                                }
                                DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        val c = Calendar.getInstance().apply { set(y, m, d) }
                                        expectedReturnDateMs = c.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "Select Return Date")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Stock note card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Inventory Impact", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Adding this borrowed record will immediately increase your local inventory for '${selectedProduct?.name ?: "Product"}' by $qty unit(s).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Conditions (Optional)") },
                        modifier = Modifier.fillMaxWidth().testTag("borrow_notes_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
