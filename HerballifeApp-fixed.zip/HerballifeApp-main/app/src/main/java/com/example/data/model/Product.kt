package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String = "",
    val variant: String = "",
    val mrp: Double = 0.0,
    val purchasePrice: Double = 0.0,
    val discountPercentage: Double = 0.0,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val taxPercentage: Double = 0.0,
    val gstFixedAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val finalPurchaseCost: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val sellingDiscountPercentage: Double = 0.0,
    val points: Double = 0.0,
    val currentStock: Int = 0,
    val minStockAlert: Int = 5,
    val notes: String = "",
    val imageUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
