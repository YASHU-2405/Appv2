package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.auth.AuthManager
import com.example.data.auth.AuthState
import com.example.data.model.Product
import com.example.data.preferences.AppSettingsManager
import com.example.data.preferences.ThemeMode
import com.example.ui.screens.*
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PointsGold
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.NutritionViewModel

enum class MainNavDestination(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    DASHBOARD("dashboard", "Dashboard", Icons.Default.Dashboard),
    PURCHASES("purchases", "Purchases", Icons.Default.ShoppingBag),
    BILLS("bills", "Bills", Icons.Default.ReceiptLong),
    SALES("sales", "Sales", Icons.Default.PointOfSale),
    PRODUCTS("products", "Products", Icons.Default.Inventory2),
    PRODUCT_USAGE("product_usage", "Product Usage", Icons.Default.LocalDrink),
    BORROWED_PRODUCTS("borrowed_products", "Borrowed Stock", Icons.Default.SwapHoriz),
    HISTORY("history", "History", Icons.Default.History),
    REPORTS("reports", "Reports", Icons.Default.Assessment),
    AI_ASSISTANT("ai", "AI Assistant", Icons.Default.AutoAwesome),
    PROFILE("profile", "Profile", Icons.Default.AccountCircle),
    SETTINGS("settings", "Settings", Icons.Default.Settings),
    SEARCH("search", "Search", Icons.Default.Search)
}

class MainActivity : ComponentActivity() {
    private val nutritionViewModel: NutritionViewModel by viewModels()
    private val aiAssistantViewModel: AiAssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val settingsManager = remember { AppSettingsManager.getInstance(context) }
            val authManager = remember { AuthManager.getInstance(context) }
            val authState by authManager.authState.collectAsStateWithLifecycle()

            val themeMode by settingsManager.themeMode.collectAsStateWithLifecycle()
            val customThemeConfig by settingsManager.customThemeConfig.collectAsStateWithLifecycle()
            val animationsEnabled by settingsManager.animationsEnabled.collectAsStateWithLifecycle()

            val isSystemDark = isSystemInDarkTheme()
            val darkTheme = when (themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.CUSTOM -> customThemeConfig.isDark
                ThemeMode.SYSTEM -> isSystemDark
            }

            val customConfig = if (themeMode == ThemeMode.CUSTOM) customThemeConfig else null

            MyApplicationTheme(darkTheme = darkTheme, customConfig = customConfig) {
                Crossfade(
                    targetState = authState,
                    animationSpec = if (animationsEnabled) tween(350) else tween(0),
                    label = "auth_state_transition"
                ) { state ->
                    when (state) {
                        is AuthState.Loading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(MaterialTheme.colorScheme.background),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.primary,
                                    strokeWidth = 3.dp
                                )
                            }
                        }
                        is AuthState.Unauthenticated -> {
                            LoginScreen(
                                authManager = authManager,
                                onAuthSuccess = { /* State automatically updates */ }
                            )
                        }
                        is AuthState.Authenticated -> {
                            MainAppContent(
                                nutritionViewModel = nutritionViewModel,
                                aiAssistantViewModel = aiAssistantViewModel,
                                animationsEnabled = animationsEnabled,
                                onLogout = { authManager.logout() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MainAppContent(
    nutritionViewModel: NutritionViewModel,
    aiAssistantViewModel: AiAssistantViewModel,
    animationsEnabled: Boolean = true,
    onLogout: () -> Unit = {}
) {
    var currentDestination by remember { mutableStateOf(MainNavDestination.DASHBOARD) }

    var showAddProductDialog by remember { mutableStateOf(false) }
    var showAddPurchaseDialog by remember { mutableStateOf(false) }
    var showAddBillDialog by remember { mutableStateOf(false) }
    var showAddSaleDialog by remember { mutableStateOf(false) }
    var showAddUsageDialog by remember { mutableStateOf(false) }
    var showAddBorrowedDialog by remember { mutableStateOf(false) }
    var showMoreMenuSheet by remember { mutableStateOf(false) }

    val products by nutritionViewModel.products.collectAsStateWithLifecycle()

    // Handle system back gesture / back button safely to prevent unexpected app exit
    BackHandler(enabled = showMoreMenuSheet || currentDestination != MainNavDestination.DASHBOARD) {
        if (showMoreMenuSheet) {
            showMoreMenuSheet = false
        } else if (currentDestination != MainNavDestination.DASHBOARD) {
            currentDestination = MainNavDestination.DASHBOARD
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = currentDestination.title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    IconButton(
                        onClick = { currentDestination = MainNavDestination.AI_ASSISTANT },
                        modifier = Modifier.testTag("top_ai_assistant_btn")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant", tint = PointsGold)
                    }

                    if (currentDestination != MainNavDestination.SEARCH) {
                        IconButton(
                            onClick = { currentDestination = MainNavDestination.SEARCH },
                            modifier = Modifier.testTag("top_search_btn")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                    }

                    IconButton(
                        onClick = { currentDestination = MainNavDestination.PROFILE },
                        modifier = Modifier.testTag("top_profile_btn")
                    ) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Business Profile")
                    }

                    IconButton(
                        onClick = { showMoreMenuSheet = true },
                        modifier = Modifier.testTag("top_more_menu_btn")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More Menu")
                    }
                }
            )
        },
        bottomBar = {
            val isImeVisible = WindowInsets.isImeVisible
            if (!isImeVisible) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    val primaryNavItems = listOf(
                        MainNavDestination.DASHBOARD,
                        MainNavDestination.PURCHASES,
                        MainNavDestination.BILLS,
                        MainNavDestination.SALES,
                        MainNavDestination.PRODUCTS
                    )

                    primaryNavItems.forEach { dest ->
                        val isSelected = currentDestination == dest
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = dest },
                            icon = {
                                Icon(
                                    imageVector = dest.icon,
                                    contentDescription = dest.title,
                                    tint = LocalContentColor.current
                                )
                            },
                            label = {
                                Text(
                                    text = dest.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_item_${dest.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
        ) {
            val animationSpec = if (animationsEnabled) tween<Float>(300) else tween<Float>(0)

            Crossfade(
                targetState = currentDestination,
                animationSpec = animationSpec,
                label = "screen_transition"
            ) { destination ->
                when (destination) {
                    MainNavDestination.DASHBOARD -> DashboardScreen(
                        viewModel = nutritionViewModel,
                        onNavigateToProducts = { currentDestination = MainNavDestination.PRODUCTS },
                        onNavigateToPurchases = { currentDestination = MainNavDestination.PURCHASES },
                        onNavigateToBills = { currentDestination = MainNavDestination.BILLS },
                        onNavigateToSales = { currentDestination = MainNavDestination.SALES },
                        onNavigateToUsage = { currentDestination = MainNavDestination.PRODUCT_USAGE },
                        onNavigateToBorrowed = { currentDestination = MainNavDestination.BORROWED_PRODUCTS },
                        onNavigateToAi = { currentDestination = MainNavDestination.AI_ASSISTANT },
                        onNavigateToSearch = { currentDestination = MainNavDestination.SEARCH },
                        onNewSaleClick = { showAddSaleDialog = true },
                        onNewPurchaseClick = { showAddPurchaseDialog = true },
                        onNewBillClick = { showAddBillDialog = true }
                    )
                    MainNavDestination.PRODUCTS -> ProductsScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddProduct = { showAddProductDialog = true }
                    )
                    MainNavDestination.PURCHASES -> PurchasesScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddPurchase = { showAddPurchaseDialog = true }
                    )
                    MainNavDestination.BILLS -> BillsScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddBill = { showAddBillDialog = true }
                    )
                    MainNavDestination.SALES -> SalesScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddSale = { showAddSaleDialog = true }
                    )
                    MainNavDestination.PRODUCT_USAGE -> ProductUsagesScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddUsage = { showAddUsageDialog = true }
                    )
                    MainNavDestination.BORROWED_PRODUCTS -> BorrowedProductsScreen(
                        viewModel = nutritionViewModel,
                        onOpenAddBorrowed = { showAddBorrowedDialog = true }
                    )
                    MainNavDestination.HISTORY -> HistoryScreen(
                        viewModel = nutritionViewModel
                    )
                    MainNavDestination.REPORTS -> ReportsScreen(
                        viewModel = nutritionViewModel
                    )
                    MainNavDestination.AI_ASSISTANT -> AiAssistantScreen(
                        viewModel = aiAssistantViewModel,
                        onNavigateToDestination = { targetRoute ->
                            when (targetRoute.lowercase()) {
                                "products" -> currentDestination = MainNavDestination.PRODUCTS
                                "purchases" -> currentDestination = MainNavDestination.PURCHASES
                                "bills", "bill", "invoice", "invoices" -> currentDestination = MainNavDestination.BILLS
                                "sales" -> currentDestination = MainNavDestination.SALES
                                "product_usage", "usage", "usages", "personal_use" -> currentDestination = MainNavDestination.PRODUCT_USAGE
                                "borrowed_products", "borrowed", "borrow" -> currentDestination = MainNavDestination.BORROWED_PRODUCTS
                                "reports" -> currentDestination = MainNavDestination.REPORTS
                                "history" -> currentDestination = MainNavDestination.HISTORY
                                "settings" -> currentDestination = MainNavDestination.SETTINGS
                                "profile" -> currentDestination = MainNavDestination.PROFILE
                                "search" -> currentDestination = MainNavDestination.SEARCH
                                else -> currentDestination = MainNavDestination.DASHBOARD
                            }
                        }
                    )
                    MainNavDestination.PROFILE -> ProfileScreen(
                        viewModel = nutritionViewModel,
                        onNavigateBack = { currentDestination = MainNavDestination.DASHBOARD },
                        onNavigateToSettings = { currentDestination = MainNavDestination.SETTINGS },
                        onNavigateToReports = { currentDestination = MainNavDestination.REPORTS },
                        onLogout = onLogout
                    )
                    MainNavDestination.SETTINGS -> SettingsBackupScreen(
                        viewModel = nutritionViewModel,
                        onNavigateToProfile = { currentDestination = MainNavDestination.PROFILE },
                        onLogout = onLogout
                    )
                    MainNavDestination.SEARCH -> SearchScreen(
                        viewModel = nutritionViewModel,
                        onProductClick = {
                            currentDestination = MainNavDestination.PRODUCTS
                        }
                    )
                }
            }
        }
    }

    // Quick Add Product Dialog
    if (showAddProductDialog) {
        AddEditProductDialog(
            onDismiss = { showAddProductDialog = false },
            onSave = { product ->
                nutritionViewModel.addProduct(product)
                showAddProductDialog = false
            }
        )
    }

    // Quick Stock In / Purchase Dialog
    if (showAddPurchaseDialog) {
        AddPurchaseDialog(
            products = products,
            onDismiss = { showAddPurchaseDialog = false },
            onSave = { purchase ->
                nutritionViewModel.recordPurchase(purchase)
                showAddPurchaseDialog = false
            },
            onAddNewProductRequested = {
                showAddPurchaseDialog = false
                showAddProductDialog = true
            }
        )
    }

    // Quick New Multi-Product Sale Dialog
    if (showAddSaleDialog) {
        AddMultiProductSaleDialog(
            products = products,
            onDismiss = { showAddSaleDialog = false },
            onSave = { items, customerName, customerContact, customerEmail, customerAddress, saleInvoiceNumber, saleDateMs, amountReceived, paymentMethod, paymentNote, notes ->
                nutritionViewModel.recordMultiProductSale(
                    items = items,
                    customerName = customerName,
                    customerContact = customerContact,
                    customerEmail = customerEmail,
                    customerAddress = customerAddress,
                    saleInvoiceNumber = saleInvoiceNumber,
                    saleDate = saleDateMs,
                    amountReceived = amountReceived,
                    paymentMethod = paymentMethod,
                    paymentNote = paymentNote,
                    notes = notes
                )
                showAddSaleDialog = false
            }
        )
    }

    // Quick New Bill Dialog
    if (showAddBillDialog) {
        AddEditBillDialog(
            catalogProducts = products,
            onDismiss = { showAddBillDialog = false },
            onSave = { bill, items, createPurchaseStock ->
                nutritionViewModel.insertBill(bill, items, createPurchaseStock)
                showAddBillDialog = false
            }
        )
    }

    // Quick Record Product Usage Dialog
    if (showAddUsageDialog) {
        AddProductUsageDialog(
            products = products,
            onDismiss = { showAddUsageDialog = false },
            onSave = { usage ->
                nutritionViewModel.recordProductUsage(usage)
                showAddUsageDialog = false
            }
        )
    }

    // Quick Record Borrowed Product Dialog
    if (showAddBorrowedDialog) {
        AddBorrowedProductDialog(
            products = products,
            onDismiss = { showAddBorrowedDialog = false },
            onSave = { borrowed ->
                nutritionViewModel.recordBorrowedProduct(borrowed)
                showAddBorrowedDialog = false
            }
        )
    }

    // More Menu Bottom Sheet
    if (showMoreMenuSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMoreMenuSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Navigation & Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                HorizontalDivider()

                val menuItems = listOf(
                    MainNavDestination.DASHBOARD,
                    MainNavDestination.PURCHASES,
                    MainNavDestination.BILLS,
                    MainNavDestination.SALES,
                    MainNavDestination.PRODUCTS,
                    MainNavDestination.PRODUCT_USAGE,
                    MainNavDestination.BORROWED_PRODUCTS,
                    MainNavDestination.PROFILE,
                    MainNavDestination.HISTORY,
                    MainNavDestination.REPORTS,
                    MainNavDestination.AI_ASSISTANT,
                    MainNavDestination.SETTINGS,
                    MainNavDestination.SEARCH
                )

                menuItems.forEach { item ->
                    ListItem(
                        headlineContent = {
                            Text(
                                item.title,
                                fontWeight = if (currentDestination == item) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingContent = {
                            Icon(
                                item.icon,
                                contentDescription = null,
                                tint = if (currentDestination == item) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.medium)
                            .background(
                                if (currentDestination == item) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                else Color.Transparent
                            )
                            .clickable {
                                currentDestination = item
                                showMoreMenuSheet = false
                            }
                            .padding(horizontal = 4.dp),
                        trailingContent = {
                            if (currentDestination == item) {
                                Icon(Icons.Default.Check, contentDescription = "Active", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
