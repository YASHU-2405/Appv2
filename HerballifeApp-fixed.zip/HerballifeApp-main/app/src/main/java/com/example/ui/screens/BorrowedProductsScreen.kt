package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BorrowedProduct
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.StatCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BorrowedProductsScreen(
    viewModel: NutritionViewModel,
    onOpenAddBorrowed: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val borrowedList by viewModel.borrowedProducts.collectAsState()
    val products by viewModel.products.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var borrowedToReturn by remember { mutableStateOf<BorrowedProduct?>(null) }
    var borrowedToDelete by remember { mutableStateOf<BorrowedProduct?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Active / Outstanding, 1: All, 2: Returned/Settled
    var searchQuery by remember { mutableStateOf("") }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val filteredList = remember(borrowedList, selectedTab, searchQuery) {
        borrowedList.filter { item ->
            val matchesTab = when (selectedTab) {
                0 -> item.status == "BORROWED" || item.status == "PARTIALLY_RETURNED"
                2 -> item.status == "RETURNED" || item.status == "SETTLED"
                else -> true
            }
            val matchesQuery = searchQuery.isBlank() ||
                item.personName.contains(searchQuery, ignoreCase = true) ||
                item.productName.contains(searchQuery, ignoreCase = true) ||
                item.notes.contains(searchQuery, ignoreCase = true)

            matchesTab && matchesQuery
        }
    }

    val activeCount = borrowedList.count { it.status == "BORROWED" || it.status == "PARTIALLY_RETURNED" }
    val totalOutstandingUnits = borrowedList
        .filter { it.status == "BORROWED" || it.status == "PARTIALLY_RETURNED" }
        .sumOf { it.quantity - it.returnedQuantity }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Borrowed Products Tracking", fontWeight = FontWeight.Bold)
                        Text(
                            "Manage products borrowed from other distributors",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (onOpenAddBorrowed != null) onOpenAddBorrowed() else showAddDialog = true
                },
                containerColor = ForestGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_borrowed_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Borrow Stock")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Metrics Summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Active Borrowed Items",
                    value = "$activeCount active",
                    subtitle = "Pending returns",
                    icon = Icons.Default.PendingActions,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Units Due to Return",
                    value = "$totalOutstandingUnits units",
                    subtitle = "Total liability",
                    icon = Icons.Default.AssignmentReturn,
                    iconTint = PointsGold,
                    modifier = Modifier.weight(1f)
                )
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by lender name, product, notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotBlank()) {
                    { IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") } }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Status Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Due ($activeCount)") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("All (${borrowedList.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Resolved") }
                )
            }

            // Borrowed List
            if (filteredList.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.SwapHoriz,
                    title = "No Borrowed Stock Found",
                    description = "When you borrow product boxes from another distributor to fulfill customer orders, record it here to track returns.",
                    actionText = "Record Borrowed Stock",
                    onActionClick = { showAddDialog = true }
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(filteredList, key = { it.id }) { item ->
                        val matchingProduct = products.find { it.id == item.productId }
                        val currentStock = matchingProduct?.currentStock ?: 0

                        BorrowedCard(
                            item = item,
                            dateFormat = dateFormat,
                            onReturnClick = { borrowedToReturn = item },
                            onSettleClick = {
                                viewModel.settleBorrowedProduct(item.id, item.outstandingValue, "Settled via payment/agreement")
                            },
                            onDelete = { borrowedToDelete = item }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddBorrowedProductDialog(
            products = products,
            onDismiss = { showAddDialog = false },
            onSave = { newBorrowed ->
                viewModel.recordBorrowedProduct(newBorrowed)
                showAddDialog = false
            }
        )
    }

    borrowedToReturn?.let { item ->
        val matchingProduct = products.find { it.id == item.productId }
        val currentStock = matchingProduct?.currentStock ?: 0

        ReturnBorrowedDialog(
            borrowedProduct = item,
            currentAvailableStock = currentStock,
            onDismiss = { borrowedToReturn = null },
            onConfirmReturn = { qty, dateMs, notes ->
                viewModel.returnBorrowedProduct(item.id, qty, notes)
                borrowedToReturn = null
            }
        )
    }

    borrowedToDelete?.let { item ->
        DeleteProtectionDialog(
            title = "Delete Borrowed Stock Record?",
            whatWillBeDeleted = "Borrowed Stock Record (Will adjust inventory)",
            dateText = dateFormat.format(Date(item.borrowDate)),
            productText = item.productName,
            quantityText = "${item.quantity} units (Borrowed from ${item.personName})",
            amountText = "Status: ${item.status}",
            onConfirm = {
                viewModel.deleteBorrowedProduct(item)
                borrowedToDelete = null
            },
            onDismiss = { borrowedToDelete = null }
        )
    }
}

@Composable
fun BorrowedCard(
    item: BorrowedProduct,
    dateFormat: SimpleDateFormat,
    onReturnClick: () -> Unit,
    onSettleClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val remaining = (item.quantity - item.returnedQuantity).coerceAtLeast(0)
    val isResolved = item.status == "RETURNED" || item.status == "SETTLED"

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isResolved) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.productName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "From: ${item.personName}${if (!item.contactInfo.isNullOrBlank()) " (${item.contactInfo})" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                StatusBadge(status = item.status)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Borrowed: ${dateFormat.format(Date(item.borrowDate))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                if (item.expectedReturnDate != null) {
                    Text(
                        text = "Due: ${dateFormat.format(Date(item.expectedReturnDate))}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (System.currentTimeMillis() > item.expectedReturnDate && !isResolved) MaterialTheme.colorScheme.error else ForestGreenPrimary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Total: ${item.quantity} units",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Returned: ${item.returnedQuantity} units",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Due: $remaining units",
                    fontWeight = FontWeight.Bold,
                    color = if (remaining > 0) ForestGreenPrimary else MaterialTheme.colorScheme.outline
                )
            }

            if (item.notes.isNotBlank()) {
                Text(
                    text = "Note: ${item.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                    )
                }

                if (!isResolved) {
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedButton(
                        onClick = onSettleClick,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Settle", style = MaterialTheme.typography.labelMedium)
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onReturnClick,
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("return_borrowed_${item.id}")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Return Units", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (label, bg, fg) = when (status) {
        "BORROWED" -> Triple("Borrowed", Color(0xFFFFF3E0), Color(0xFFE65100))
        "PARTIALLY_RETURNED" -> Triple("Partially Returned", Color(0xFFE1F5FE), Color(0xFF0277BD))
        "RETURNED" -> Triple("Fully Returned", Color(0xFFE8F5E9), Color(0xFF2E7D32))
        "SETTLED" -> Triple("Settled", Color(0xFFEDE7F6), Color(0xFF512DA8))
        else -> Triple(status, Color.LightGray, Color.DarkGray)
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bg
    ) {
        Text(
            text = label,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
