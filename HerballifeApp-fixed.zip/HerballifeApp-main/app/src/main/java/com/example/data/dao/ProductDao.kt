package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Product
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY name ASC")
    suspend fun getAllProductsList(): List<Product>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    fun getProductById(id: Long): Flow<Product?>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductByIdDirect(id: Long): Product?

    @Query("SELECT * FROM products WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun findProductByName(name: String): Product?

    @Query("SELECT * FROM products WHERE LOWER(name) LIKE '%' || LOWER(:query) || '%' OR LOWER(sku) LIKE '%' || LOWER(:query) || '%'")
    fun searchProducts(query: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: Product): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<Product>): List<Long>

    @Update
    suspend fun update(product: Product)

    @Delete
    suspend fun delete(product: Product)

    @Query("UPDATE products SET currentStock = :newStock WHERE id = :productId")
    suspend fun updateStock(productId: Long, newStock: Int)

    @Query("UPDATE products SET sellingPrice = :newPrice WHERE id = :productId")
    suspend fun updateSellingPrice(productId: Long, newPrice: Double)

    @Query("UPDATE products SET points = :newPoints WHERE id = :productId")
    suspend fun updatePoints(productId: Long, newPoints: Double)

    @Query("UPDATE products SET discountPercentage = :newDiscount WHERE id = :productId")
    suspend fun updateDiscount(productId: Long, newDiscount: Double)

    @Query("UPDATE products SET taxPercentage = :newTax WHERE id = :productId")
    suspend fun updateTax(productId: Long, newTax: Double)

    @Query("DELETE FROM products")
    suspend fun deleteAll()
}
