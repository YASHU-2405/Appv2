package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Purchase
import kotlinx.coroutines.flow.Flow

@Dao
interface PurchaseDao {
    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC")
    fun getAllPurchases(): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC")
    suspend fun getAllPurchasesList(): List<Purchase>

    @Query("SELECT * FROM purchases WHERE id = :id LIMIT 1")
    suspend fun getPurchaseById(id: Long): Purchase?

    @Query("SELECT * FROM purchases WHERE productId = :productId ORDER BY purchaseDate DESC")
    fun getPurchasesForProduct(productId: Long): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE productId = :productId ORDER BY purchaseDate DESC")
    suspend fun getPurchasesForProductList(productId: Long): List<Purchase>

    @Query("SELECT * FROM purchases WHERE orderId = :orderId ORDER BY id ASC")
    fun getPurchasesForOrder(orderId: Long): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE orderId = :orderId ORDER BY id ASC")
    suspend fun getPurchasesForOrderList(orderId: Long): List<Purchase>

    @Query("SELECT * FROM purchases WHERE purchaseDate >= :start AND purchaseDate <= :end ORDER BY purchaseDate DESC")
    fun getPurchasesInRange(start: Long, end: Long): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE purchaseDate >= :start AND purchaseDate <= :end ORDER BY purchaseDate DESC")
    suspend fun getPurchasesInRangeList(start: Long, end: Long): List<Purchase>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(purchase: Purchase): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(purchases: List<Purchase>): List<Long>

    @Update
    suspend fun update(purchase: Purchase)

    @Delete
    suspend fun delete(purchase: Purchase)

    @Query("DELETE FROM purchases")
    suspend fun deleteAll()
}
