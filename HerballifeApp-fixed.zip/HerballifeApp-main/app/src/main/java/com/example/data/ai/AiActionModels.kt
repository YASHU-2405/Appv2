package com.example.data.ai

data class DraftPurchaseItem(
    val productName: String,
    val quantity: Int,
    val mrp: Double,
    val originalPrice: Double,
    val discountPercentage: Double,
    val discountAmount: Double,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val gstFixedAmount: Double = 0.0,
    val taxPercentage: Double = 18.0,
    val taxAmount: Double,
    val finalPricePerUnit: Double,
    val totalAmount: Double,
    val matchedProductId: Long? = null,
    val sku: String = "",
    val needsReview: Boolean = false
)

data class DraftPurchaseAction(
    val items: List<DraftPurchaseItem>,
    val invoiceNumber: String = "",
    val notes: String = "",
    val purchaseDateMs: Long = System.currentTimeMillis()
)

data class ReceiptReviewDraft(
    val items: List<DraftPurchaseItem>,
    val invoiceNumber: String = "",
    val orderDateStr: String = "",
    val detectedStoreOrSupplier: String = "",
    val overallNeedsReview: Boolean = false,
    val rawOcrSummary: String = ""
)

data class DraftSaleAction(
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val sellingPrice: Double,
    val discountPercentage: Double = 0.0,
    val discountAmount: Double = 0.0,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val gstPercentage: Double = 0.0,
    val gstFixedAmount: Double = 0.0,
    val gstAmount: Double = 0.0,
    val finalSellingPrice: Double = sellingPrice,
    val totalSaleAmount: Double,
    val unitPurchaseCost: Double,
    val profit: Double,
    val points: Double,
    val remainingStock: Int,
    val customerName: String? = null,
    val customerContact: String? = null,
    val customerEmail: String? = null,
    val customerAddress: String? = null
)

data class DraftCreateProductAction(
    val name: String,
    val sku: String = "",
    val category: String = "Nutrition",
    val variant: String = "",
    val size: String = "",
    val mrp: Double,
    val purchasePrice: Double,
    val discountPercentage: Double = 0.0,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val gstFixedAmount: Double = 0.0,
    val taxPercentage: Double = 18.0,
    val finalPurchaseCost: Double,
    val sellingPrice: Double,
    val points: Double = 0.0,
    val currentStock: Int = 0,
    val minStockAlert: Int = 5
)

data class DraftEditProductAction(
    val productId: Long,
    val productName: String,
    val fieldName: String, // "Selling Price", "Stock", "Points", "Discount", "Tax", "MRP"
    val oldValue: String,
    val newValue: String,
    val newSellingPrice: Double? = null,
    val newStock: Int? = null,
    val newPoints: Double? = null,
    val newDiscount: Double? = null,
    val newTax: Double? = null,
    val newMrp: Double? = null
)

data class DraftDeleteAction(
    val targetType: String, // "PRODUCT", "PURCHASE", "SALE"
    val id: Long,
    val title: String,
    val dateStr: String,
    val quantityStr: String,
    val amountStr: String
)

data class DraftUpdateSettingsAction(
    val settingName: String, // "Theme Mode", "Animations"
    val oldValue: String,
    val newValue: String,
    val newThemeMode: String? = null, // "LIGHT", "DARK", "SYSTEM"
    val newAnimationsEnabled: Boolean? = null
)

data class NavigateAction(
    val destination: String, // "DASHBOARD", "PRODUCTS", "PURCHASES", "SALES", "HISTORY", "REPORTS", "PROFILE", "SETTINGS", "SEARCH"
    val message: String
)

data class WebCitation(
    val title: String,
    val url: String,
    val sourceName: String = "Herbalife India Official",
    val snippet: String = ""
)

sealed class AiAssistantResponse {
    data class TextMessage(
        val message: String,
        val citations: List<WebCitation> = emptyList(),
        val isWebResearched: Boolean = false,
        val suggestedCatalogAction: AiAssistantResponse? = null
    ) : AiAssistantResponse()
    data class ConfirmPurchase(val draft: DraftPurchaseAction, val message: String) : AiAssistantResponse()
    data class ConfirmReceiptReview(val receiptDraft: ReceiptReviewDraft, val message: String) : AiAssistantResponse()
    data class ConfirmSale(val draft: DraftSaleAction, val message: String) : AiAssistantResponse()
    data class ConfirmCreateProduct(val draft: DraftCreateProductAction, val message: String) : AiAssistantResponse()
    data class ConfirmEdit(val draft: DraftEditProductAction, val message: String) : AiAssistantResponse()
    data class ConfirmDelete(val draft: DraftDeleteAction, val message: String) : AiAssistantResponse()
    data class ConfirmSettingsChange(val draft: DraftUpdateSettingsAction, val message: String) : AiAssistantResponse()
    data class Navigate(val action: NavigateAction) : AiAssistantResponse()
}
