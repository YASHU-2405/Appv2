package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object ReceiptImageStorage {
    private const val RECEIPTS_DIR = "receipt_images"

    fun getReceiptsDir(context: Context): File {
        val dir = File(context.filesDir, RECEIPTS_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Creates a temporary file and returns its FileProvider Uri for Camera capture
     */
    fun createTempPictureUri(context: Context): Pair<Uri, File> {
        val dir = getReceiptsDir(context)
        val file = File(dir, "receipt_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, file)
        return Pair(uri, file)
    }

    /**
     * Saves a captured Bitmap to internal storage and returns the local file absolute path
     */
    fun saveBitmap(context: Context, bitmap: Bitmap): String? {
        return try {
            val dir = getReceiptsDir(context)
            val file = File(dir, "receipt_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Copies an image from a content URI (e.g. Gallery) to internal storage and returns local path
     */
    fun saveImageFromUri(context: Context, sourceUri: Uri): String? {
        return try {
            val dir = getReceiptsDir(context)
            val file = File(dir, "receipt_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            }
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Safely deletes a stored receipt file
     */
    fun deleteImage(filePath: String?) {
        if (filePath.isNullOrBlank()) return
        try {
            val file = File(filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
