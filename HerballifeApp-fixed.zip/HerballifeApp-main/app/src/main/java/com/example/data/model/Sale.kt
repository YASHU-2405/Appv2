package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val sellingPrice: Double = 0.0,
    val discountType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val discountPercentage: Double = 0.0,
    val discountFixedAmount: Double = 0.0,
    val discountAmount: Double = 0.0,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val taxPercentage: Double = 0.0,
    val gstFixedAmount: Double = 0.0,
    val gstAmount: Double = 0.0,
    val finalSellingPrice: Double = 0.0,
    val totalSaleAmount: Double = 0.0,
    val unitPurchaseCost: Double = 0.0,
    val totalPurchaseCost: Double = 0.0,
    val profit: Double = 0.0,
    val pointsPerUnit: Double = 0.0,
    val totalPoints: Double = 0.0,
    val customerName: String? = null,
    val customerContact: String? = null,
    val customerEmail: String? = null,
    val customerAddress: String? = null,
    val fromBorrowedId: Long? = null,
    val saleDate: Long = System.currentTimeMillis(),
    val notes: String = "",
    val paymentStatus: String = "PAID", // "PAID", "PARTIAL", "PENDING"
    val amountReceived: Double = 0.0,
    val amountPending: Double = 0.0,
    val paymentMethod: String = "Cash", // "Cash", "UPI", "Bank Transfer", "Other"
    val paymentDate: Long? = null,
    val paymentNote: String = "",
    val receiptImageUri: String? = null,
    val saleInvoiceNumber: String = ""
)
