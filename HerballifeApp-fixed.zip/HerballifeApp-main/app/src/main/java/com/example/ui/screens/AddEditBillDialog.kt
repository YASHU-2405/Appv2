package com.example.ui.screens

import android.app.DatePickerDialog
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ai.AiAssistantResponse
import com.example.data.ai.NaturalLanguageProcessor
import com.example.data.database.AppDatabase
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BillWithItems
import com.example.data.model.Product
import com.example.data.preferences.AppSettingsManager
import com.example.data.repository.NutritionRepository
import com.example.ui.components.ReceiptAttachmentSection
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

data class EditableBillItemState(
    val id: Long = 0,
    var productName: String = "",
    var productId: Long? = null,
    var quantityStr: String = "1",
    var originalPriceStr: String = "0.0",
    var discountPercentStr: String = "0.0",
    var taxPercentStr: String = "18.0",
    var needsReview: Boolean = false
) {
    val quantity: Int get() = (quantityStr.toIntOrNull() ?: 1).coerceAtLeast(1)
    val originalPrice: Double get() = (originalPriceStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val discountPercent: Double get() = (discountPercentStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
    val taxPercent: Double get() = (taxPercentStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    val discountAmountPerUnit: Double get() = originalPrice * (discountPercent / 100.0)
    val priceAfterDiscount: Double get() = (originalPrice - discountAmountPerUnit).coerceAtLeast(0.0)
    val taxAmountPerUnit: Double get() = priceAfterDiscount * (taxPercent / 100.0)
    val finalPricePerUnit: Double get() = priceAfterDiscount + taxAmountPerUnit

    val lineTotalOriginal: Double get() = originalPrice * quantity
    val lineTotalDiscount: Double get() = discountAmountPerUnit * quantity
    val lineTotalTax: Double get() = taxAmountPerUnit * quantity
    val lineTotalAmount: Double get() = finalPricePerUnit * quantity

    fun toBillItem(billId: Long = 0): BillItem {
        return BillItem(
            id = id,
            billId = billId,
            productId = productId,
            productName = productName.trim(),
            quantity = quantity,
            originalPrice = originalPrice,
            discountPercentage = discountPercent,
            discountAmount = discountAmountPerUnit * quantity,
            taxPercentage = taxPercent,
            taxAmount = taxAmountPerUnit * quantity,
            finalPricePerUnit = finalPricePerUnit,
            totalAmount = lineTotalAmount,
            needsReview = needsReview
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditBillDialog(
    initialBillWithItems: BillWithItems? = null,
    catalogProducts: List<Product> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (Bill, List<BillItem>, Boolean) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var billNumber by remember {
        mutableStateOf(
            initialBillWithItems?.bill?.billNumber
                ?: "BILL-${System.currentTimeMillis() % 1000000}"
        )
    }
    var supplierName by remember { mutableStateOf(initialBillWithItems?.bill?.supplierName ?: "") }
    var billDateMs by remember { mutableStateOf(initialBillWithItems?.bill?.billDate ?: System.currentTimeMillis()) }
    var billImageUri by remember { mutableStateOf(initialBillWithItems?.bill?.billImageUri) }
    var notes by remember { mutableStateOf(initialBillWithItems?.bill?.notes ?: "") }

    val lineItems = remember {
        mutableStateListOf<EditableBillItemState>().apply {
            if (initialBillWithItems != null && initialBillWithItems.items.isNotEmpty()) {
                addAll(
                    initialBillWithItems.items.map { item ->
                        EditableBillItemState(
                            id = item.id,
                            productName = item.productName,
                            productId = item.productId,
                            quantityStr = item.quantity.toString(),
                            originalPriceStr = "%.2f".format(item.originalPrice),
                            discountPercentStr = "%.2f".format(item.discountPercentage),
                            taxPercentStr = "%.2f".format(item.taxPercentage),
                            needsReview = item.needsReview
                        )
                    }
                )
            } else {
                add(EditableBillItemState(productName = "", quantityStr = "1", originalPriceStr = "0.0"))
            }
        }
    }

    var isScanning by remember { mutableStateOf(false) }
    var scanStatusMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Computations
    val totalOriginalAmount = lineItems.sumOf { it.lineTotalOriginal }
    val totalDiscountAmount = lineItems.sumOf { it.lineTotalDiscount }
    val totalGstAmount = lineItems.sumOf { it.lineTotalTax }
    val finalBillAmount = lineItems.sumOf { it.lineTotalAmount }

    var amountPaidStr by remember {
        mutableStateOf(
            initialBillWithItems?.bill?.amountPaid?.takeIf { it > 0 }?.toString() ?: ""
        )
    }
    var userModifiedPaid by remember { mutableStateOf(initialBillWithItems != null) }

    val paidAmount = if (userModifiedPaid) (amountPaidStr.toDoubleOrNull() ?: 0.0) else finalBillAmount
    val pendingAmount = (finalBillAmount - paidAmount).coerceAtLeast(0.0)
    val paymentStatus = if (paidAmount >= finalBillAmount - 0.01) "PAID" else if (paidAmount <= 0.01) "PENDING" else "PARTIAL"

    val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(billDateMs))

    // Function to run AI Bill Scanner
    fun performAiScan(imagePath: String) {
        coroutineScope.launch {
            isScanning = true
            scanStatusMessage = "Analyzing bill image with AI..."
            errorMessage = null
            try {
                val db = AppDatabase.getDatabase(context)
                val repo = NutritionRepository(db)
                val settings = AppSettingsManager.getInstance(context)
                val nlp = NaturalLanguageProcessor(repo, settings)

                val bitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(imagePath)
                }
                if (bitmap == null) {
                    errorMessage = "Could not open image file for scanning."
                    isScanning = false
                    return@launch
                }

                val response = nlp.processUserCommandWithImage("Extract bill receipt details", bitmap)
                when (response) {
                    is AiAssistantResponse.ConfirmReceiptReview -> {
                        val draft = response.receiptDraft
                        if (draft.invoiceNumber.isNotBlank()) {
                            billNumber = draft.invoiceNumber
                        }
                        if (draft.detectedStoreOrSupplier.isNotBlank()) {
                            supplierName = draft.detectedStoreOrSupplier
                        }

                        if (draft.items.isNotEmpty()) {
                            lineItems.clear()
                            for (scanned in draft.items) {
                                lineItems.add(
                                    EditableBillItemState(
                                        productName = scanned.productName,
                                        productId = scanned.matchedProductId,
                                        quantityStr = scanned.quantity.toString(),
                                        originalPriceStr = "%.2f".format(scanned.originalPrice),
                                        discountPercentStr = "%.2f".format(scanned.discountPercentage),
                                        taxPercentStr = "%.2f".format(scanned.taxPercentage),
                                        needsReview = scanned.needsReview
                                    )
                                )
                            }
                            scanStatusMessage = "Successfully extracted ${draft.items.size} item(s)!"
                        } else {
                            scanStatusMessage = "Image scanned. No items detected. You can add lines manually."
                        }
                    }
                    is AiAssistantResponse.TextMessage -> {
                        scanStatusMessage = response.message
                    }
                    else -> {
                        scanStatusMessage = "Scan completed."
                    }
                }
            } catch (e: Exception) {
                errorMessage = "AI scan error: ${e.message}"
            } finally {
                isScanning = false
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                if (initialBillWithItems == null) "New Bill / Invoice" else "Edit Bill",
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = Color.White
                        ),
                        actions = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Total: ₹%.2f".format(finalBillAmount),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Status: $paymentStatus",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = when (paymentStatus) {
                                        "PAID" -> Color(0xFF2E7D32)
                                        "PARTIAL" -> Color(0xFFF57F17)
                                        else -> Color(0xFFC62828)
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Option 1: Save as Bill Record Only (NO STOCK TOUCHED)
                                OutlinedButton(
                                    onClick = {
                                        if (billNumber.isBlank()) {
                                            errorMessage = "Bill number cannot be empty"
                                            return@OutlinedButton
                                        }
                                        if (lineItems.isEmpty()) {
                                            errorMessage = "Please add at least one line item"
                                            return@OutlinedButton
                                        }

                                        val bill = Bill(
                                            id = initialBillWithItems?.bill?.id ?: 0,
                                            billNumber = billNumber.trim(),
                                            billDate = billDateMs,
                                            supplierName = supplierName.trim(),
                                            billImageUri = billImageUri,
                                            totalOriginalAmount = totalOriginalAmount,
                                            totalDiscountAmount = totalDiscountAmount,
                                            totalGstAmount = totalGstAmount,
                                            finalAmount = finalBillAmount,
                                            amountPaid = paidAmount,
                                            amountPending = pendingAmount,
                                            paymentStatus = paymentStatus,
                                            notes = notes.trim(),
                                            linkedPurchaseOrderId = initialBillWithItems?.bill?.linkedPurchaseOrderId
                                        )
                                        val items = lineItems.map { it.toBillItem(bill.id) }
                                        onSave(bill, items, false)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("save_bill_record_only_button")
                                ) {
                                    Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Save Bill Only")
                                }

                                // Option 2: Save Bill & Add to Purchase/Stock
                                Button(
                                    onClick = {
                                        if (billNumber.isBlank()) {
                                            errorMessage = "Bill number cannot be empty"
                                            return@Button
                                        }
                                        if (lineItems.isEmpty()) {
                                            errorMessage = "Please add at least one line item"
                                            return@Button
                                        }

                                        val bill = Bill(
                                            id = initialBillWithItems?.bill?.id ?: 0,
                                            billNumber = billNumber.trim(),
                                            billDate = billDateMs,
                                            supplierName = supplierName.trim(),
                                            billImageUri = billImageUri,
                                            totalOriginalAmount = totalOriginalAmount,
                                            totalDiscountAmount = totalDiscountAmount,
                                            totalGstAmount = totalGstAmount,
                                            finalAmount = finalBillAmount,
                                            amountPaid = paidAmount,
                                            amountPending = pendingAmount,
                                            paymentStatus = paymentStatus,
                                            notes = notes.trim(),
                                            linkedPurchaseOrderId = initialBillWithItems?.bill?.linkedPurchaseOrderId
                                        )
                                        val items = lineItems.map { it.toBillItem(bill.id) }
                                        onSave(bill, items, true)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .testTag("save_bill_and_add_stock_button")
                                ) {
                                    Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Save & Add Stock")
                                }
                            }
                        }
                    }
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (errorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(errorMessage ?: "", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (scanStatusMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = scanStatusMessage ?: "",
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // Section 1: Capture / Upload Bill Document
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ReceiptAttachmentSection(
                                currentImageUri = billImageUri,
                                onImageCaptured = { path ->
                                    billImageUri = path
                                    performAiScan(path)
                                },
                                onImageRemoved = { billImageUri = null },
                                title = "Bill / Invoice Photo or Scan"
                            )

                            if (!billImageUri.isNullOrBlank()) {
                                Button(
                                    onClick = { billImageUri?.let { performAiScan(it) } },
                                    enabled = !isScanning,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    if (isScanning) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Extracting Products with AI...")
                                    } else {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Scan & Extract Products with AI")
                                    }
                                }
                            }
                        }
                    }

                    // Section 2: Bill Header Details
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = billNumber,
                            onValueChange = { billNumber = it },
                            label = { Text("Bill / Invoice No.") },
                            modifier = Modifier.weight(1.2f)
                        )

                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance().apply { timeInMillis = billDateMs }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, day ->
                                        val newCal = Calendar.getInstance().apply {
                                            set(year, month, day)
                                        }
                                        billDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(dateDisplay, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    OutlinedTextField(
                        value = supplierName,
                        onValueChange = { supplierName = it },
                        label = { Text("Supplier / Vendor Name") },
                        placeholder = { Text("e.g. Herbalife Distribution, ABC Wholesaler") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Section 3: Multi-Product Line Items
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Bill Line Items (${lineItems.size})", fontWeight = FontWeight.Bold)
                                TextButton(
                                    onClick = {
                                        lineItems.add(
                                            EditableBillItemState(
                                                productName = "",
                                                quantityStr = "1",
                                                originalPriceStr = "0.0",
                                                discountPercentStr = "0.0",
                                                taxPercentStr = "18.0"
                                            )
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Item")
                                }
                            }

                            lineItems.forEachIndexed { index, itemState ->
                                BillItemRowCard(
                                    index = index + 1,
                                    itemState = itemState,
                                    catalogProducts = catalogProducts,
                                    onDelete = {
                                        if (lineItems.size > 1) {
                                            lineItems.removeAt(index)
                                        } else {
                                            lineItems[0] = EditableBillItemState(productName = "", quantityStr = "1", originalPriceStr = "0.0")
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // Section 4: Totals Breakdown Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Bill Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Original Cost (Subtotal):", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(totalOriginalAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Discount:", style = MaterialTheme.typography.bodySmall, color = ProfitGreen)
                                Text("-₹%.2f".format(totalDiscountAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total GST:", style = MaterialTheme.typography.bodySmall)
                                Text("+₹%.2f".format(totalGstAmount), style = MaterialTheme.typography.bodySmall)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Final Bill Amount:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(finalBillAmount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Section 5: Payment & Settlement
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment Settlement", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = when (paymentStatus) {
                                        "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                        "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                                        else -> Color(0xFFC62828).copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = paymentStatus,
                                        color = when (paymentStatus) {
                                            "PAID" -> Color(0xFF2E7D32)
                                            "PARTIAL" -> Color(0xFFF57F17)
                                            else -> Color(0xFFC62828)
                                        },
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = if (userModifiedPaid) amountPaidStr else if (finalBillAmount > 0) "%.2f".format(finalBillAmount) else "",
                                onValueChange = {
                                    userModifiedPaid = true
                                    amountPaidStr = it
                                },
                                label = { Text("Amount Paid to Supplier (₹)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Balance Pending to Pay:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "₹%.2f".format(pendingAmount),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (pendingAmount > 0.01) Color(0xFFC62828) else Color(0xFF2E7D32)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Internal Memo") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillItemRowCard(
    index: Int,
    itemState: EditableBillItemState,
    catalogProducts: List<Product>,
    onDelete: () -> Unit
) {
    var expandedCatalogDropdown by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (itemState.needsReview) Color(0xFFFFF8E1) else MaterialTheme.colorScheme.surface
        ),
        border = if (itemState.needsReview) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFFA000)) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header: Item # and Review Warning badge if applicable
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("#$index", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    if (itemState.needsReview) {
                        Surface(color = Color(0xFFFFA000), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                "⚠️ Needs Review",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Item", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
            }

            // Product Name (with Catalog Quick Select)
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = itemState.productName,
                    onValueChange = {
                        itemState.productName = it
                        itemState.needsReview = false
                    },
                    label = { Text("Product Name") },
                    placeholder = { Text("e.g. Formula 1 Shake") },
                    modifier = Modifier.weight(1f)
                )

                if (catalogProducts.isNotEmpty()) {
                    Box {
                        IconButton(
                            onClick = { expandedCatalogDropdown = true },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Default.List, contentDescription = "Select from Catalog", tint = ForestGreenPrimary)
                        }

                        DropdownMenu(
                            expanded = expandedCatalogDropdown,
                            onDismissRequest = { expandedCatalogDropdown = false }
                        ) {
                            catalogProducts.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.name) },
                                    onClick = {
                                        itemState.productName = p.name
                                        itemState.productId = p.id
                                        itemState.originalPriceStr = if (p.purchasePrice > 0) p.purchasePrice.toString() else p.mrp.toString()
                                        itemState.discountPercentStr = p.discountPercentage.toString()
                                        itemState.taxPercentStr = p.taxPercentage.toString()
                                        itemState.needsReview = false
                                        expandedCatalogDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Numeric inputs: Quantity, Original Price, Discount %, Tax %
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = itemState.quantityStr,
                    onValueChange = { itemState.quantityStr = it },
                    label = { Text("Qty") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(0.8f)
                )
                OutlinedTextField(
                    value = itemState.originalPriceStr,
                    onValueChange = { itemState.originalPriceStr = it },
                    label = { Text("Price (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1.2f)
                )
                OutlinedTextField(
                    value = itemState.discountPercentStr,
                    onValueChange = { itemState.discountPercentStr = it },
                    label = { Text("Disc %") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = itemState.taxPercentStr,
                    onValueChange = { itemState.taxPercentStr = it },
                    label = { Text("GST %") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
            }

            // Line Item Totals
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Unit Cost: ₹%.2f".format(itemState.finalPricePerUnit),
                    style = MaterialTheme.typography.bodySmall,
                    color = StockBlue,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Line Total: ₹%.2f".format(itemState.lineTotalAmount),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary
                )
            }
        }
    }
}
