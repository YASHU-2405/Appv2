package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val mrp: Double = 0.0,
    val originalPrice: Double = 0.0,
    val discountType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val discountPercentage: Double = 0.0,
    val discountFixedAmount: Double = 0.0,
    val discountAmount: Double = 0.0,
    val gstType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val taxPercentage: Double = 0.0,
    val gstFixedAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val finalPricePerUnit: Double = 0.0,
    val totalAmount: Double = 0.0,
    val purchaseDate: Long = System.currentTimeMillis(),
    val invoiceNumber: String = "",
    val notes: String = "",
    val pointsPerUnit: Double = 0.0,
    val totalPoints: Double = 0.0,
    val orderId: Long? = null,
    val supplierName: String = "",
    val receiptImageUri: String? = null,
    val paymentStatus: String = "PAID", // "PAID", "PARTIAL", "PENDING"
    val amountPaid: Double = 0.0,
    val amountPending: Double = 0.0
)
