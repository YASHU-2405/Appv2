package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ProductUsage
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductUsageDao {
    @Query("SELECT * FROM product_usages ORDER BY usageDate DESC")
    fun getAllProductUsages(): Flow<List<ProductUsage>>

    @Query("SELECT * FROM product_usages ORDER BY usageDate DESC")
    suspend fun getAllProductUsagesList(): List<ProductUsage>

    @Query("SELECT * FROM product_usages WHERE id = :id LIMIT 1")
    suspend fun getProductUsageById(id: Long): ProductUsage?

    @Query("SELECT * FROM product_usages WHERE productId = :productId ORDER BY usageDate DESC")
    fun getUsagesForProduct(productId: Long): Flow<List<ProductUsage>>

    @Query("SELECT * FROM product_usages WHERE productId = :productId ORDER BY usageDate DESC")
    suspend fun getUsagesForProductList(productId: Long): List<ProductUsage>

    @Query("SELECT * FROM product_usages WHERE usageDate >= :start AND usageDate <= :end ORDER BY usageDate DESC")
    fun getUsagesInRange(start: Long, end: Long): Flow<List<ProductUsage>>

    @Query("SELECT * FROM product_usages WHERE usageDate >= :start AND usageDate <= :end ORDER BY usageDate DESC")
    suspend fun getUsagesInRangeList(start: Long, end: Long): List<ProductUsage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(usage: ProductUsage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(usages: List<ProductUsage>): List<Long>

    @Update
    suspend fun update(usage: ProductUsage)

    @Delete
    suspend fun delete(usage: ProductUsage)

    @Query("DELETE FROM product_usages")
    suspend fun deleteAll()
}
