package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Sale
import com.example.ui.components.CustomerLedgerDialog
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ReceiptImageViewerDialog
import com.example.ui.components.RecordPaymentDialog
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    viewModel: NutritionViewModel,
    onOpenAddSale: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var paymentStatusFilter by remember { mutableStateOf("ALL") } // ALL, PAID, PARTIAL, PENDING
    var saleToDelete by remember { mutableStateOf<Sale?>(null) }
    var saleToEdit by remember { mutableStateOf<Sale?>(null) }
    var saleDetailToView by remember { mutableStateOf<Sale?>(null) }
    var saleToRecordPayment by remember { mutableStateOf<Sale?>(null) }
    var customerLedgerName by remember { mutableStateOf<String?>(null) }
    var receiptImageToView by remember { mutableStateOf<String?>(null) }

    // Search sales by: Product Name, Customer Name, Contact Number, or Email, plus status filter
    val filteredSales = remember(sales, searchQuery, paymentStatusFilter) {
        sales.filter { sale ->
            val matchesQuery = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                sale.productName.lowercase().contains(q) ||
                (sale.customerName?.lowercase()?.contains(q) == true) ||
                (sale.customerContact?.lowercase()?.contains(q) == true) ||
                (sale.customerEmail?.lowercase()?.contains(q) == true)
            }
            val matchesStatus = when (paymentStatusFilter) {
                "PAID" -> sale.paymentStatus == "PAID"
                "PARTIAL" -> sale.paymentStatus == "PARTIAL"
                "PENDING" -> sale.paymentStatus == "PENDING"
                else -> true
            }
            matchesQuery && matchesStatus
        }
    }

    val totalRevenue = remember(sales) { sales.sumOf { it.totalSaleAmount } }
    val totalReceived = remember(sales) { sales.sumOf { it.amountReceived } }
    val totalPending = remember(sales) { sales.sumOf { it.amountPending } }
    val totalUnitsSold = remember(sales) { sales.sumOf { it.quantity } }

    val paidCount = remember(sales) { sales.count { it.paymentStatus == "PAID" } }
    val partialCount = remember(sales) { sales.count { it.paymentStatus == "PARTIAL" } }
    val pendingCount = remember(sales) { sales.count { it.paymentStatus == "PENDING" } }

    Scaffold(
        modifier = modifier.testTag("sales_screen"),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAddSale,
                icon = { Icon(Icons.Default.PointOfSale, contentDescription = "New Sale") },
                text = { Text("New Sale") },
                containerColor = ForestGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier
                    .padding(bottom = 60.dp)
                    .testTag("fab_add_sale")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header summary
            Surface(
                color = ForestGreenPrimary.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Revenue", style = MaterialTheme.typography.labelSmall, color = ForestGreenPrimary)
                            Text("₹%.2f".format(totalRevenue), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Received", style = MaterialTheme.typography.labelSmall, color = ProfitGreen)
                            Text("₹%.2f".format(totalReceived), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ProfitGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Pending", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828))
                            Text("₹%.2f".format(totalPending), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (totalPending > 0) Color(0xFFC62828) else ProfitGreen)
                        }
                    }
                }
            }

            // Payment Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = paymentStatusFilter == "ALL",
                    onClick = { paymentStatusFilter = "ALL" },
                    label = { Text("All (${sales.size})", style = MaterialTheme.typography.labelSmall) }
                )
                FilterChip(
                    selected = paymentStatusFilter == "PAID",
                    onClick = { paymentStatusFilter = "PAID" },
                    label = { Text("Paid ($paidCount)", style = MaterialTheme.typography.labelSmall) }
                )
                FilterChip(
                    selected = paymentStatusFilter == "PARTIAL",
                    onClick = { paymentStatusFilter = "PARTIAL" },
                    label = { Text("Partial ($partialCount)", style = MaterialTheme.typography.labelSmall) }
                )
                FilterChip(
                    selected = paymentStatusFilter == "PENDING",
                    onClick = { paymentStatusFilter = "PENDING" },
                    label = { Text("Pending ($pendingCount)", style = MaterialTheme.typography.labelSmall) }
                )
            }

            // Search Bar supporting Customer Name, Contact Number, Email, and Product
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by customer, phone, email, product...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("sales_search_input"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            if (filteredSales.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.PointOfSale,
                    title = if (searchQuery.isBlank()) "No Sales Recorded" else "No Matching Sales",
                    description = if (searchQuery.isBlank())
                        "Enter customer sales to calculate actual profits, track customer orders, and accumulate volume points."
                    else "No sales match '$searchQuery'. Try searching by customer name, phone, or email.",
                    actionText = if (searchQuery.isBlank()) "Record First Sale" else null,
                    onActionClick = if (searchQuery.isBlank()) onOpenAddSale else null
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredSales, key = { it.id }) { sale ->
                        SaleItemCard(
                            sale = sale,
                            onClick = { saleDetailToView = sale },
                            onEdit = { saleToEdit = sale },
                            onDelete = { saleToDelete = sale },
                            onRecordPayment = { saleToRecordPayment = sale },
                            onViewCustomerLedger = {
                                customerLedgerName = sale.customerName ?: "Walk-in Customer"
                            },
                            onViewReceipt = { uri -> receiptImageToView = uri }
                        )
                    }
                }
            }
        }
    }

    // View Sale Details Dialog
    saleDetailToView?.let { detail ->
        SaleDetailDialog(
            sale = detail,
            onDismiss = { saleDetailToView = null },
            onEdit = {
                saleDetailToView = null
                saleToEdit = detail
            },
            onDelete = {
                saleDetailToView = null
                saleToDelete = detail
            },
            onRecordPayment = {
                saleDetailToView = null
                saleToRecordPayment = detail
            },
            onViewReceipt = { uri ->
                receiptImageToView = uri
            }
        )
    }

    // Record Payment Dialog
    saleToRecordPayment?.let { s ->
        RecordPaymentDialog(
            sale = s,
            onDismiss = { saleToRecordPayment = null },
            onSavePayment = { amount, method, date, notes, receiptUri ->
                viewModel.recordAdditionalPayment(
                    saleId = s.id,
                    amount = amount,
                    paymentMethod = method,
                    paymentDate = date,
                    notes = notes,
                    receiptImageUri = receiptUri
                )
                saleToRecordPayment = null
            }
        )
    }

    // Customer Ledger Dialog
    customerLedgerName?.let { cName ->
        CustomerLedgerDialog(
            customerName = cName,
            sales = sales,
            payments = payments,
            onDismiss = { customerLedgerName = null },
            onRecordPayment = { s ->
                saleToRecordPayment = s
            },
            onViewReceipt = { uri ->
                receiptImageToView = uri
            }
        )
    }

    // Receipt Image Viewer Dialog
    receiptImageToView?.let { uri ->
        ReceiptImageViewerDialog(
            imageUri = uri,
            onDismiss = { receiptImageToView = null }
        )
    }

    // Edit Sale Dialog
    saleToEdit?.let { toEdit ->
        AddSaleDialog(
            products = products,
            initialSale = toEdit,
            onDismiss = { saleToEdit = null },
            onSave = { updatedSale ->
                viewModel.updateSale(toEdit, updatedSale)
                saleToEdit = null
            }
        )
    }

    // Delete Sale Confirmation Dialog (with Customer Details)
    saleToDelete?.let { s ->
        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(s.saleDate))
        val customerSummary = buildString {
            append(s.customerName ?: "Walk-in Customer")
            s.customerContact?.takeIf { it.isNotBlank() }?.let { append(" • Phone: $it") }
            s.customerEmail?.takeIf { it.isNotBlank() }?.let { append(" • Email: $it") }
            s.customerAddress?.takeIf { it.isNotBlank() }?.let { append(" • Addr: $it") }
        }

        DeleteProtectionDialog(
            title = "Delete Sale Record?",
            whatWillBeDeleted = "Sale Entry (Stock will be restored)",
            dateText = dateStr,
            customerText = customerSummary,
            productText = s.productName,
            quantityText = "${s.quantity} units",
            amountText = "₹%.2f".format(s.totalSaleAmount),
            onConfirm = {
                viewModel.deleteSale(s)
                saleToDelete = null
            },
            onDismiss = { saleToDelete = null }
        )
    }
}

@Composable
fun SaleItemCard(
    sale: Sale,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRecordPayment: () -> Unit,
    onViewCustomerLedger: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(sale.saleDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("sale_card_${sale.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Row: Product Name & Sale Total
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = sale.productName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = dateStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                Text(
                    text = "₹%.2f".format(sale.totalSaleAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary
                )
            }

            // Payment Status Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (badgeBg, badgeFg) = when (sale.paymentStatus) {
                    "PAID" -> Pair(ProfitGreen, Color.White)
                    "PARTIAL" -> Pair(Color(0xFFE65100), Color.White)
                    else -> Pair(MaterialTheme.colorScheme.error, Color.White)
                }
                Surface(
                    color = badgeBg,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = sale.paymentStatus,
                        color = badgeFg,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Rec: ₹%.0f".format(sale.amountReceived), style = MaterialTheme.typography.bodySmall, color = ProfitGreen, fontWeight = FontWeight.SemiBold)
                    if (sale.amountPending > 0.001) {
                        Text("Due: ₹%.0f".format(sale.amountPending), style = MaterialTheme.typography.bodySmall, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Customer Details Row
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = sale.customerName ?: "Walk-in Customer",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Customer Ledger button
                        TextButton(
                            onClick = onViewCustomerLedger,
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text("Ledger", style = MaterialTheme.typography.labelSmall, color = ForestGreenPrimary)
                        }
                    }

                    sale.customerContact?.takeIf { it.isNotBlank() }?.let { contact ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(
                                Icons.Default.Phone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = contact,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    sale.customerEmail?.takeIf { it.isNotBlank() }?.let { email ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(
                                Icons.Default.Email,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = email,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Metrics and Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Qty", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("${sale.quantity}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                val realizedProfit = if (sale.totalSaleAmount > 0.001) {
                    sale.profit * (sale.amountReceived.coerceIn(0.0, sale.totalSaleAmount) / sale.totalSaleAmount)
                } else 0.0

                Column {
                    Text("Profit Received", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.0f".format(realizedProfit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!sale.receiptImageUri.isNullOrBlank()) {
                        IconButton(
                            onClick = { onViewReceipt(sale.receiptImageUri) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = "View Bill",
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (sale.amountPending > 0.001) {
                        Button(
                            onClick = onRecordPayment,
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Collect", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp).testTag("edit_sale_btn_${sale.id}")
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Sale",
                            tint = ForestGreenPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).testTag("delete_sale_btn_${sale.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SaleDetailDialog(
    sale: Sale,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRecordPayment: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(sale.saleDate))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sale Details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Payment Status & Collection Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Payment Collection Status",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenPrimary
                            )
                            val (badgeBg, badgeFg) = when (sale.paymentStatus) {
                                "PAID" -> Pair(ProfitGreen, Color.White)
                                "PARTIAL" -> Pair(Color(0xFFE65100), Color.White)
                                else -> Pair(MaterialTheme.colorScheme.error, Color.White)
                            }
                            Surface(color = badgeBg, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    sale.paymentStatus,
                                    color = badgeFg,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        DetailItem("Total Amount", "₹%.2f".format(sale.totalSaleAmount))
                        DetailItem("Amount Received", "₹%.2f".format(sale.amountReceived), highlightColor = ProfitGreen)
                        DetailItem(
                            "Amount Pending",
                            "₹%.2f".format(sale.amountPending),
                            highlightColor = if (sale.amountPending > 0.001) Color(0xFFC62828) else ProfitGreen
                        )
                        DetailItem("Payment Method", sale.paymentMethod)
                        if (sale.paymentNote.isNotBlank()) {
                            DetailItem("Payment Reference", sale.paymentNote)
                        }

                        if (!sale.receiptImageUri.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = { onViewReceipt(sale.receiptImageUri) },
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("View Attached Bill / Receipt")
                            }
                        }

                        if (sale.amountPending > 0.001) {
                            Button(
                                onClick = onRecordPayment,
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Record Additional Payment")
                            }
                        }
                    }
                }

                // Customer Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "Customer Details",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary
                        )
                        DetailItem("Customer Name", sale.customerName ?: "Walk-in Customer")
                        DetailItem("Contact Number", sale.customerContact?.ifEmpty { null } ?: "Not Provided")
                        DetailItem("Email Address", sale.customerEmail?.ifEmpty { null } ?: "Not Provided")
                        DetailItem("Address", sale.customerAddress?.ifEmpty { null } ?: "Not Provided")
                    }
                }

                // Transaction Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "Transaction Details",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary
                        )
                        DetailItem("Product", sale.productName)
                        DetailItem("Quantity Sold", "${sale.quantity} units")
                        DetailItem("Unit Base Price", "₹%.2f".format(sale.sellingPrice))
                        if (sale.discountPercentage > 0) {
                            DetailItem("Discount Given", "%.1f%% (-₹%.2f)".format(sale.discountPercentage, sale.discountAmount))
                        }
                        if (sale.gstAmount > 0) {
                            val gstDesc = if (sale.gstType == "FIXED_AMOUNT") "Fixed GST (₹%.2f/unit)".format(sale.gstFixedAmount) else "GST Rate (%.1f%%)".format(sale.taxPercentage)
                            DetailItem("GST / Tax", "$gstDesc: +₹%.2f".format(sale.gstAmount), highlightColor = ForestGreenPrimary)
                        }
                        DetailItem("Final Unit Price", "₹%.2f".format(sale.finalSellingPrice))
                        DetailItem("Total Sale Amount", "₹%.2f".format(sale.totalSaleAmount))
                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                        DetailItem("Unit Cost of Goods", "₹%.2f".format(sale.unitPurchaseCost))
                        DetailItem("Total Cost of Goods", "₹%.2f".format(sale.totalPurchaseCost))
                        DetailItem("Gross Sale Profit", "₹%.2f".format(sale.profit), highlightColor = ProfitGreen)
                        val realizedProfit = if (sale.totalSaleAmount > 0.001) {
                            sale.profit * (sale.amountReceived.coerceIn(0.0, sale.totalSaleAmount) / sale.totalSaleAmount)
                        } else 0.0
                        DetailItem(
                            "Profit Received",
                            "₹%.2f".format(realizedProfit),
                            highlightColor = ProfitGreen
                        )
                        DetailItem("Sale Date", dateStr)
                        if (sale.notes.isNotBlank()) {
                            DetailItem("Notes", sale.notes)
                        }
                    }
                }

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete")
                    }

                    Button(
                        onClick = onEdit,
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Sale")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailItem(label: String, value: String, highlightColor: Color? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = highlightColor ?: MaterialTheme.colorScheme.onSurface
        )
    }
}
