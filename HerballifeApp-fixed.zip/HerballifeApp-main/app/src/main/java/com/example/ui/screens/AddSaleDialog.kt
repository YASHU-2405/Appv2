package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.ui.components.DiscountTypeSelector
import com.example.ui.components.GstTypeSelector
import com.example.ui.components.ReceiptAttachmentSection
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSaleDialog(
    products: List<Product>,
    initialSale: Sale? = null,
    onDismiss: () -> Unit,
    onSave: (Sale) -> Unit
) {
    // Select in-stock product by default if available
    val availableProducts = products.filter { it.currentStock > 0 }
    var selectedProductId by remember {
        mutableStateOf<Long?>(
            initialSale?.productId
                ?: availableProducts.firstOrNull()?.id
                ?: products.firstOrNull()?.id
        )
    }
    var expandedProductDropdown by remember { mutableStateOf(false) }

    val selectedProduct = products.find { it.id == selectedProductId }

    var quantityStr by remember { mutableStateOf(initialSale?.quantity?.toString() ?: "1") }
    var sellingPriceStr by remember {
        mutableStateOf(
            initialSale?.sellingPrice?.takeIf { it > 0 }?.toString()
                ?: selectedProduct?.sellingPrice?.takeIf { it > 0 }?.toString()
                ?: ""
        )
    }
    var discountType by remember { mutableStateOf(initialSale?.discountType ?: "PERCENTAGE") }
    var discountPercentStr by remember {
        mutableStateOf(initialSale?.discountPercentage?.takeIf { it > 0 }?.toString() ?: "0")
    }
    var discountFixedAmountStr by remember {
        mutableStateOf(initialSale?.discountFixedAmount?.takeIf { it > 0 }?.toString() ?: "0")
    }

    var gstType by remember {
        mutableStateOf(initialSale?.gstType ?: "PERCENTAGE")
    }
    var taxPercentageStr by remember {
        mutableStateOf(initialSale?.taxPercentage?.takeIf { it > 0 }?.toString() ?: "0")
    }
    var gstFixedAmountStr by remember {
        mutableStateOf(initialSale?.gstFixedAmount?.takeIf { it > 0 }?.toString() ?: "")
    }

    var customerName by remember { mutableStateOf(initialSale?.customerName ?: "") }
    var customerContact by remember { mutableStateOf(initialSale?.customerContact ?: "") }
    var customerEmail by remember { mutableStateOf(initialSale?.customerEmail ?: "") }
    var customerAddress by remember { mutableStateOf(initialSale?.customerAddress ?: "") }
    var notes by remember { mutableStateOf(initialSale?.notes ?: "") }
    var saleDateMs by remember { mutableStateOf(initialSale?.saleDate ?: System.currentTimeMillis()) }

    var amountReceivedStr by remember {
        mutableStateOf(
            if (initialSale != null) initialSale.amountReceived.toString() else ""
        )
    }
    var userModifiedAmountReceived by remember { mutableStateOf(initialSale != null) }
    var paymentMethod by remember { mutableStateOf(initialSale?.paymentMethod ?: "Cash") }
    var paymentDateMs by remember { mutableStateOf(initialSale?.paymentDate ?: saleDateMs) }
    var paymentNote by remember { mutableStateOf(initialSale?.paymentNote ?: "") }
    var receiptImageUri by remember { mutableStateOf(initialSale?.receiptImageUri) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // When product selection changes in new sale, update selling price
    LaunchedEffect(selectedProductId) {
        if (initialSale == null) {
            selectedProduct?.let {
                if (it.sellingPrice > 0) {
                    sellingPriceStr = it.sellingPrice.toString()
                }
            }
        }
    }

    val context = LocalContext.current
    val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(saleDateMs))

    val qty = quantityStr.toIntOrNull() ?: 1
    val baseSellingPrice = sellingPriceStr.toDoubleOrNull() ?: 0.0
    val discPercent = discountPercentStr.toDoubleOrNull() ?: 0.0
    val discFixedAmt = discountFixedAmountStr.toDoubleOrNull() ?: 0.0

    val unitDiscAmt = if (discountType == "FIXED_AMOUNT") {
        discFixedAmt.coerceAtMost(baseSellingPrice)
    } else {
        baseSellingPrice * (discPercent / 100.0)
    }
    val taxableUnitSellingPrice = (baseSellingPrice - unitDiscAmt).coerceAtLeast(0.0)

    val taxPercent = taxPercentageStr.toDoubleOrNull() ?: 0.0
    val gstFixed = gstFixedAmountStr.toDoubleOrNull() ?: 0.0
    val unitGstAmt = if (gstType == "FIXED_AMOUNT") gstFixed else taxableUnitSellingPrice * (taxPercent / 100.0)
    val finalUnitSellingPrice = taxableUnitSellingPrice + unitGstAmt
    val totalSaleAmount = finalUnitSellingPrice * qty
    val totalGstAmount = unitGstAmt * qty

    val unitCost = initialSale?.unitPurchaseCost ?: (selectedProduct?.finalPurchaseCost ?: 0.0)
    val totalCost = unitCost * qty
    val calculatedProfit = (taxableUnitSellingPrice * qty) - totalCost
    // Volume points are earned on product purchases, not customer sales
    val pointsPerUnit = 0.0
    val totalPoints = 0.0
    val previousQty = initialSale?.quantity ?: 0
    val stockDelta = qty - previousQty
    val availableStock = selectedProduct?.currentStock ?: 0
    val isInsufficientStock = selectedProduct != null && (
        if (initialSale == null) qty > availableStock
        else stockDelta > availableStock
    )
    val shortfall = if (initialSale == null) {
        (qty - availableStock).coerceAtLeast(0)
    } else {
        (stockDelta - availableStock).coerceAtLeast(0)
    }
    val remainingStock = (availableStock - stockDelta).coerceAtLeast(0)

    // Automatically synchronize amountReceivedStr with totalSaleAmount for new sales unless user modified it
    LaunchedEffect(totalSaleAmount) {
        if (!userModifiedAmountReceived && totalSaleAmount > 0) {
            amountReceivedStr = "%.2f".format(totalSaleAmount)
        }
    }

    val parsedAmountReceived = amountReceivedStr.toDoubleOrNull() ?: 0.0
    val amountReceived = parsedAmountReceived.coerceAtLeast(0.0)
    val amountPending = (totalSaleAmount - amountReceived).coerceAtLeast(0.0)

    val paymentStatus = when {
        amountReceived <= 0.001 -> "PENDING"
        amountPending <= 0.001 -> "PAID"
        else -> "PARTIAL"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                if (initialSale == null) "New Sale Entry" else "Edit Sale Entry",
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    val prod = selectedProduct ?: run {
                                        errorMessage = "Please select a product"
                                        return@Button
                                    }
                                    if (qty <= 0) {
                                        errorMessage = "Quantity must be at least 1"
                                        return@Button
                                    }
                                    if (initialSale == null && qty > prod.currentStock) {
                                        errorMessage = "Cannot sell $qty units! Only ${prod.currentStock} available in stock for '${prod.name}'."
                                        return@Button
                                    } else if (initialSale != null && stockDelta > 0 && prod.currentStock < stockDelta) {
                                        errorMessage = "Cannot increase sale by $stockDelta units! Only ${prod.currentStock} available in stock for '${prod.name}'."
                                        return@Button
                                    }

                                    val sale = Sale(
                                        id = initialSale?.id ?: 0,
                                        productId = prod.id,
                                        productName = prod.name,
                                        quantity = qty,
                                        sellingPrice = baseSellingPrice,
                                        discountType = discountType,
                                        discountPercentage = if (discountType == "PERCENTAGE") discPercent else 0.0,
                                        discountFixedAmount = if (discountType == "FIXED_AMOUNT") discFixedAmt else 0.0,
                                        discountAmount = unitDiscAmt * qty,
                                        gstType = gstType,
                                        taxPercentage = if (gstType == "PERCENTAGE") taxPercent else 0.0,
                                        gstFixedAmount = if (gstType == "FIXED_AMOUNT") gstFixed else 0.0,
                                        gstAmount = totalGstAmount,
                                        finalSellingPrice = finalUnitSellingPrice,
                                        totalSaleAmount = totalSaleAmount,
                                        unitPurchaseCost = unitCost,
                                        totalPurchaseCost = totalCost,
                                        profit = calculatedProfit,
                                        pointsPerUnit = pointsPerUnit,
                                        totalPoints = totalPoints,
                                        customerName = customerName.trim().ifEmpty { null },
                                        customerContact = customerContact.trim().ifEmpty { null },
                                        customerEmail = customerEmail.trim().ifEmpty { null },
                                        customerAddress = customerAddress.trim().ifEmpty { null },
                                        saleDate = saleDateMs,
                                        notes = notes.trim(),
                                        paymentStatus = paymentStatus,
                                        amountReceived = amountReceived,
                                        amountPending = amountPending,
                                        paymentMethod = paymentMethod,
                                        paymentDate = paymentDateMs,
                                        paymentNote = paymentNote.trim(),
                                        receiptImageUri = receiptImageUri
                                    )
                                    onSave(sale)
                                },
                                enabled = !isInsufficientStock && qty > 0 && selectedProduct != null,
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_sale_button")
                            ) {
                                Text(if (initialSale == null) "Confirm Sale" else "Update Sale")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(4.dp))

                    if (errorMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Product Selector
                    Text("Select Product", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    if (products.isEmpty()) {
                        Text("No products exist in database.", color = MaterialTheme.colorScheme.error)
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = expandedProductDropdown,
                            onExpandedChange = { expandedProductDropdown = !expandedProductDropdown }
                        ) {
                            OutlinedTextField(
                                value = if (selectedProduct != null) "${selectedProduct.name} (Available: ${selectedProduct.currentStock})" else "Select Product",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProductDropdown) },
                                modifier = Modifier.fillMaxWidth().menuAnchor().testTag("sale_product_dropdown")
                            )
                            ExposedDropdownMenu(
                                expanded = expandedProductDropdown,
                                onDismissRequest = { expandedProductDropdown = false }
                            ) {
                                products.forEach { p ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    "Stock: ${p.currentStock}",
                                                    color = if (p.currentStock > 0) ForestGreenPrimary else MaterialTheme.colorScheme.error
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedProductId = p.id
                                            expandedProductDropdown = false
                                            errorMessage = null
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Quantity and Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = {
                                quantityStr = it
                                errorMessage = null
                            },
                            label = { Text("Quantity Sold *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("sale_quantity_input")
                        )

                        OutlinedTextField(
                            value = dateDisplay,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Sale Date") },
                            trailingIcon = {
                                IconButton(onClick = {
                                    val cal = Calendar.getInstance().apply { timeInMillis = saleDateMs }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            saleDateMs = c.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date")
                                }
                            },
                            modifier = Modifier.weight(1.2f)
                        )
                    }

                    if (isInsufficientStock) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("insufficient_stock_warning")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Warning,
                                        contentDescription = "Insufficient Stock",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        "INSUFFICIENT STOCK",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Available Stock:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                                    Text("$availableStock units", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Requested Quantity:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                                    Text("$qty units", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Shortfall:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    Text("$shortfall units", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                }
                                Text(
                                    "Cannot confirm sale until stock is replenished or quantity is reduced.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    // Selling price & customer discount
                    OutlinedTextField(
                        value = sellingPriceStr,
                        onValueChange = { sellingPriceStr = it },
                        label = { Text("Base Selling Price (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("sale_price_input")
                    )

                    // Customer Discount Mode Selector
                    DiscountTypeSelector(
                        selectedType = discountType,
                        onTypeSelected = { discountType = it },
                        label = "Customer Discount Mode"
                    )

                    if (discountType == "PERCENTAGE") {
                        OutlinedTextField(
                            value = discountPercentStr,
                            onValueChange = { discountPercentStr = it },
                            label = { Text("Discount Given (%)") },
                            trailingIcon = { Text("%", fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 12.dp)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("sale_discount_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = discountFixedAmountStr,
                            onValueChange = { discountFixedAmountStr = it },
                            label = { Text("Discount Given Fixed Amount (₹ per unit)") },
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("sale_discount_fixed_input")
                        )
                    }

                    // GST / Tax Section
                    Text("GST / Tax on Sale", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    GstTypeSelector(
                        selectedType = gstType,
                        onTypeSelected = { gstType = it }
                    )

                    if (gstType == "PERCENTAGE") {
                        OutlinedTextField(
                            value = taxPercentageStr,
                            onValueChange = { taxPercentageStr = it },
                            label = { Text("GST Rate (%)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("sale_gst_percent_input")
                        )

                        // Quick GST preset chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(0.0, 5.0, 12.0, 18.0, 28.0).forEach { rate ->
                                FilterChip(
                                    selected = (taxPercentageStr.toDoubleOrNull() ?: -1.0) == rate,
                                    onClick = { taxPercentageStr = if (rate % 1.0 == 0.0) rate.toInt().toString() else rate.toString() },
                                    label = { Text("${rate.toInt()}%", style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("sale_gst_chip_${rate.toInt()}")
                                )
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = gstFixedAmountStr,
                            onValueChange = { gstFixedAmountStr = it },
                            label = { Text("Fixed GST Amount per Unit (₹)") },
                            placeholder = { Text("e.g. 50.00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("sale_gst_fixed_input")
                        )
                    }

                    // Customer Details Section (Optional)
                    Text("Customer Information", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Customer Name (Optional)") },
                        placeholder = { Text("e.g. Rahul Sharma") },
                        modifier = Modifier.fillMaxWidth().testTag("sale_customer_name_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = customerContact,
                        onValueChange = { customerContact = it },
                        label = { Text("Customer Contact Number (Optional)") },
                        placeholder = { Text("e.g. +91 9876543210") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("sale_customer_contact_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = customerEmail,
                        onValueChange = { customerEmail = it },
                        label = { Text("Customer Email (Optional)") },
                        placeholder = { Text("e.g. rahul@example.com") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth().testTag("sale_customer_email_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = customerAddress,
                        onValueChange = { customerAddress = it },
                        label = { Text("Customer Address (Optional)") },
                        placeholder = { Text("e.g. Flat 402, Green Valley, Mumbai") },
                        modifier = Modifier.fillMaxWidth().testTag("sale_customer_address_input"),
                        maxLines = 2
                    )

                    // Payment Status & Collection Details Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Payment Status & Collection",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )

                                // Status Badge
                                val (statusBg, statusFg, statusIcon) = when (paymentStatus) {
                                    "PAID" -> Triple(ProfitGreen, Color.White, Icons.Default.CheckCircle)
                                    "PARTIAL" -> Triple(Color(0xFFE65100), Color.White, Icons.Default.Refresh)
                                    else -> Triple(MaterialTheme.colorScheme.error, Color.White, Icons.Default.DateRange)
                                }
                                Surface(
                                    color = statusBg,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(statusIcon, contentDescription = null, tint = statusFg, modifier = Modifier.size(14.dp))
                                        Text(paymentStatus, color = statusFg, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Sale Amount:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text("₹%.2f".format(totalSaleAmount), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                            }

                            // Amount Received Field
                            OutlinedTextField(
                                value = amountReceivedStr,
                                onValueChange = {
                                    amountReceivedStr = it
                                    userModifiedAmountReceived = true
                                },
                                label = { Text("Amount Received *") },
                                leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth().testTag("sale_amount_received_input"),
                                singleLine = true
                            )

                            // Quick Fill Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = amountPending <= 0.001 && totalSaleAmount > 0,
                                    onClick = {
                                        amountReceivedStr = "%.2f".format(totalSaleAmount)
                                        userModifiedAmountReceived = true
                                    },
                                    label = { Text("Full Paid") },
                                    leadingIcon = { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                )
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        amountReceivedStr = "%.2f".format(totalSaleAmount / 2.0)
                                        userModifiedAmountReceived = true
                                    },
                                    label = { Text("50% Partial") }
                                )
                                FilterChip(
                                    selected = amountReceived <= 0.001,
                                    onClick = {
                                        amountReceivedStr = "0.00"
                                        userModifiedAmountReceived = true
                                    },
                                    label = { Text("Pending (₹0)") }
                                )
                            }

                            // Amount Pending Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Amount Pending / Balance:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "₹%.2f".format(amountPending),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (amountPending > 0.001) Color(0xFFC62828) else ProfitGreen
                                )
                            }

                            HorizontalDivider()

                            // Payment Method
                            Text("Payment Method:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            val methods = listOf("Cash", "UPI", "Card", "Bank Transfer", "Cheque", "Other")
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                methods.take(3).forEach { m ->
                                    FilterChip(
                                        selected = paymentMethod == m,
                                        onClick = { paymentMethod = m },
                                        label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                methods.drop(3).forEach { m ->
                                    FilterChip(
                                        selected = paymentMethod == m,
                                        onClick = { paymentMethod = m },
                                        label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            // Payment Date
                            val paymentDateFormatted = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(paymentDateMs))
                            OutlinedButton(
                                onClick = {
                                    val cal = Calendar.getInstance().apply { timeInMillis = paymentDateMs }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            paymentDateMs = c.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Payment Date: $paymentDateFormatted")
                            }

                            // Payment Notes
                            OutlinedTextField(
                                value = paymentNote,
                                onValueChange = { paymentNote = it },
                                label = { Text("Payment Note / Reference (Optional)") },
                                placeholder = { Text("e.g. UPI Ref #9382103810, Cheque #2041") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }

                    // Customer Bill / Receipt Photo Attachment
                    ReceiptAttachmentSection(
                        currentImageUri = receiptImageUri,
                        onImageCaptured = { receiptImageUri = it },
                        onImageRemoved = { receiptImageUri = null },
                        title = "Bill / Receipt / Payment Screenshot"
                    )

                    // Real-time Calculations Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Automatic Sale Calculations", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Base Unit Price:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(baseSellingPrice), style = MaterialTheme.typography.bodySmall)
                            }
                            if (discPercent > 0 || discFixedAmt > 0) {
                                val discLabel = if (discountType == "FIXED_AMOUNT") "Fixed Discount" else "Discount (%.1f%%)".format(discPercent)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("$discLabel:", style = MaterialTheme.typography.bodySmall)
                                    Text("-₹%.2f".format(unitDiscAmt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                            if (unitGstAmt > 0) {
                                val gstLabel = if (gstType == "FIXED_AMOUNT") "Fixed GST" else "GST (%.1f%%)".format(taxPercent)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("$gstLabel per Unit:", style = MaterialTheme.typography.bodySmall)
                                    Text("+₹%.2f".format(unitGstAmt), style = MaterialTheme.typography.bodySmall, color = ForestGreenPrimary)
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Final Selling Price / Unit:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Text("₹%.2f".format(finalUnitSellingPrice), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Sale Amount ($qty units):", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(totalSaleAmount), fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Unit Cost of Goods:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(unitCost), style = MaterialTheme.typography.bodySmall)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Cost of Goods:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(totalCost), style = MaterialTheme.typography.bodySmall)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Profit from this Sale:", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(calculatedProfit), fontWeight = FontWeight.Bold, color = ProfitGreen)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Volume Points from Sale:", style = MaterialTheme.typography.bodySmall)
                                Text("0.00 pts", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                if (isInsufficientStock) {
                                    Text("Stock Status:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    Text("Shortfall: $shortfall units (Blocked)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                } else {
                                    Text("Remaining Stock after Sale:")
                                    Text("$remainingStock units", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
