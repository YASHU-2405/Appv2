package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Sale
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ProfitGreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentDialog(
    sale: Sale,
    onDismiss: () -> Unit,
    onSavePayment: (
        amount: Double,
        method: String,
        date: Long,
        notes: String,
        receiptUri: String?
    ) -> Unit
) {
    val context = LocalContext.current
    val balanceDue = sale.amountPending

    var amountStr by remember { mutableStateOf("%.2f".format(balanceDue)) }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var paymentDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var paymentNotes by remember { mutableStateOf("") }
    var receiptImageUri by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val parsedAmount = amountStr.toDoubleOrNull() ?: 0.0
    val newPending = (balanceDue - parsedAmount).coerceAtLeast(0.0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Record Customer Payment", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    if (parsedAmount <= 0) {
                                        errorMessage = "Please enter a valid payment amount greater than 0"
                                        return@Button
                                    }
                                    if (parsedAmount > balanceDue + 0.01) {
                                        errorMessage = "Amount exceeds balance pending (₹%.2f)".format(balanceDue)
                                        return@Button
                                    }
                                    onSavePayment(
                                        parsedAmount,
                                        paymentMethod,
                                        paymentDateMs,
                                        paymentNotes.trim(),
                                        receiptImageUri
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_payment_button")
                            ) {
                                Text("Confirm Payment")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(4.dp))

                    if (errorMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Sale Summary Header
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                sale.productName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val customer = sale.customerName ?: "Walk-in Customer"
                            Text("Customer: $customer", style = MaterialTheme.typography.bodySmall)

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Sale Amount:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(sale.totalSaleAmount), fontWeight = FontWeight.SemiBold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Already Received:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(sale.amountReceived), color = ProfitGreen, fontWeight = FontWeight.SemiBold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Current Balance Pending:", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(balanceDue), fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            }
                        }
                    }

                    // Payment Amount Input
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = {
                            amountStr = it
                            errorMessage = null
                        },
                        label = { Text("Payment Amount to Collect *") },
                        leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("payment_amount_input"),
                        singleLine = true
                    )

                    // Quick Fill Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = amountStr == "%.2f".format(balanceDue),
                            onClick = { amountStr = "%.2f".format(balanceDue) },
                            label = { Text("Full Balance (₹%.0f)".format(balanceDue)) },
                            leadingIcon = { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        if (balanceDue > 1) {
                            FilterChip(
                                selected = false,
                                onClick = { amountStr = "%.2f".format(balanceDue / 2.0) },
                                label = { Text("50% (₹%.0f)".format(balanceDue / 2.0)) }
                            )
                        }
                    }

                    // Remaining Balance Preview
                    Surface(
                        color = if (newPending <= 0.001) ProfitGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("New Balance After This Payment:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (newPending <= 0.001) "FULLY PAID (₹0.00)" else "₹%.2f PENDING".format(newPending),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (newPending <= 0.001) ProfitGreen else Color(0xFFE65100)
                            )
                        }
                    }

                    // Payment Method Chips
                    Text("Payment Method:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    val methods = listOf("Cash", "UPI", "Card", "Bank Transfer", "Cheque", "Other")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        methods.take(3).forEach { m ->
                            FilterChip(
                                selected = paymentMethod == m,
                                onClick = { paymentMethod = m },
                                label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        methods.drop(3).forEach { m ->
                            FilterChip(
                                selected = paymentMethod == m,
                                onClick = { paymentMethod = m },
                                label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    // Payment Date
                    val dateFormatted = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(paymentDateMs))
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance().apply { timeInMillis = paymentDateMs }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val c = Calendar.getInstance().apply { set(y, m, d) }
                                    paymentDateMs = c.timeInMillis
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Payment Date: $dateFormatted")
                    }

                    // Payment Notes / Reference
                    OutlinedTextField(
                        value = paymentNotes,
                        onValueChange = { paymentNotes = it },
                        label = { Text("Payment Note / Reference (Optional)") },
                        placeholder = { Text("e.g. UPI Ref #, Cheque #4021...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Receipt Attachment Section
                    ReceiptAttachmentSection(
                        currentImageUri = receiptImageUri,
                        onImageCaptured = { receiptImageUri = it },
                        onImageRemoved = { receiptImageUri = null },
                        title = "Payment Screenshot / Receipt"
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
