package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "borrowed_products")
data class BorrowedProduct(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personOrBusinessName: String,
    val contactNumber: String? = null,
    val productId: Long,
    val productName: String,
    val quantityBorrowed: Int,
    val quantityReturned: Int = 0,
    val quantitySold: Int = 0,
    val unitValue: Double = 0.0,
    val totalValue: Double = 0.0,
    val dateReceived: Long = System.currentTimeMillis(),
    val expectedReturnDate: Long? = null,
    val notes: String = "",
    val status: String = "BORROWED", // "BORROWED", "PARTIALLY_RETURNED", "RETURNED", "SETTLED"
    val settlementAmount: Double? = null,
    val settlementDate: Long? = null,
    val settlementNotes: String? = null,
    val receiptImageUri: String? = null
) {
    // Convenience getters for UI components
    val personName: String get() = personOrBusinessName
    val contactInfo: String? get() = contactNumber
    val quantity: Int get() = quantityBorrowed
    val returnedQuantity: Int get() = quantityReturned
    val unitPurchaseCost: Double get() = unitValue
    val borrowDate: Long get() = dateReceived

    val remainingQuantity: Int
        get() = (quantityBorrowed - quantityReturned - quantitySold).coerceAtLeast(0)

    val outstandingValue: Double
        get() = remainingQuantity * unitValue
}

