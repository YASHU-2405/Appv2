package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.Sale
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class ProductFilter(val label: String) {
    ALL("All Products"),
    IN_STOCK("In Stock"),
    LOW_STOCK("Low Stock"),
    OUT_OF_STOCK("Out of Stock")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    viewModel: NutritionViewModel,
    onOpenAddProduct: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(ProductFilter.ALL) }

    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }
    var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }

    val filteredProducts = remember(products, searchQuery, selectedFilter) {
        products.filter { prod ->
            val matchesQuery = prod.name.contains(searchQuery, ignoreCase = true) ||
                    prod.sku.contains(searchQuery, ignoreCase = true) ||
                    prod.variant.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                ProductFilter.ALL -> true
                ProductFilter.IN_STOCK -> prod.currentStock > 0
                ProductFilter.LOW_STOCK -> prod.currentStock in 1..prod.minStockAlert
                ProductFilter.OUT_OF_STOCK -> prod.currentStock <= 0
            }
            matchesQuery && matchesFilter
        }
    }

    Scaffold(
        modifier = modifier.testTag("products_screen"),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAddProduct,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Product") },
                text = { Text("Add Product") },
                containerColor = ForestGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier
                    .padding(bottom = 60.dp)
                    .testTag("fab_add_product")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name, SKU, variant...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("products_search_input"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ProductFilter.values().forEach { filter ->
                    val isSelected = filter == selectedFilter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ForestGreenPrimary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Products List
            if (filteredProducts.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.Inventory2,
                    title = if (products.isEmpty()) "No Products Yet" else "No matching products",
                    description = if (products.isEmpty()) "Start by adding your inventory products to track stock, profit and points." else "Try adjusting your search query or filters.",
                    actionText = if (products.isEmpty()) "Add First Product" else null,
                    onActionClick = onOpenAddProduct
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductListItemCard(
                            product = product,
                            onClick = { selectedProductForDetail = product },
                            onEdit = { productToEdit = product },
                            onDelete = { productToDelete = product }
                        )
                    }
                }
            }
        }
    }

    // Edit Product Dialog
    productToEdit?.let { prod ->
        AddEditProductDialog(
            initialProduct = prod,
            onDismiss = { productToEdit = null },
            onSave = { updated ->
                viewModel.updateProduct(updated)
                productToEdit = null
            }
        )
    }

    // Delete Protection Dialog
    productToDelete?.let { prod ->
        val stockVal = prod.currentStock * prod.sellingPrice
        DeleteProtectionDialog(
            title = "Delete Product?",
            whatWillBeDeleted = "Product Master Record",
            dateText = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(prod.createdAt)),
            productText = prod.name,
            quantityText = "${prod.currentStock} units in stock",
            amountText = "Estimated Value ₹%.2f".format(stockVal),
            onConfirm = {
                viewModel.deleteProduct(prod)
                productToDelete = null
            },
            onDismiss = { productToDelete = null }
        )
    }

    // Product Detail Dialog (showing full history, profit, sales, purchases)
    selectedProductForDetail?.let { prod ->
        val productPurchases = purchases.filter { it.productId == prod.id }
        val productSales = sales.filter { it.productId == prod.id }

        ProductDetailDialog(
            product = prod,
            purchases = productPurchases,
            sales = productSales,
            onDismiss = { selectedProductForDetail = null },
            onEdit = {
                productToEdit = prod
                selectedProductForDetail = null
            }
        )
    }
}

@Composable
fun ProductListItemCard(
    product: Product,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (product.sku.isNotBlank() || product.variant.isNotBlank()) {
                        Text(
                            text = listOf(product.sku, product.variant).filter { it.isNotBlank() }.joinToString(" • "),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Stock status badge
                val isLow = product.currentStock in 1..product.minStockAlert
                val isOut = product.currentStock <= 0
                val badgeColor = when {
                    isOut -> LossRed
                    isLow -> PointsGold
                    else -> ForestGreenPrimary
                }
                val badgeText = when {
                    isOut -> "Out of Stock"
                    isLow -> "Low: ${product.currentStock}"
                    else -> "${product.currentStock} in stock"
                }

                Surface(
                    color = badgeColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Selling Price", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.2f".format(product.sellingPrice), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                }
                Column {
                    Text("Purchase Cost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.2f".format(product.finalPurchaseCost), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text("Points", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("%.2f pts".format(product.points), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = PointsGold)
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailDialog(
    product: Product,
    purchases: List<Purchase>,
    sales: List<Sale>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit
) {
    val totalPurchasedQty = purchases.sumOf { it.quantity }
    val totalPurchasedAmount = purchases.sumOf { it.totalAmount }
    val totalSoldQty = sales.sumOf { it.quantity }
    val totalSoldAmount = sales.sumOf { it.totalSaleAmount }
    val totalProfit = sales.sumOf { it.profit }
    val totalPoints = purchases.sumOf { it.totalPoints }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text(product.name, fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        ),
                        actions = {
                            IconButton(onClick = onEdit) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.White)
                            }
                        }
                    )
                },
                bottomBar = {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                    ) {
                        Text("Close")
                    }
                }
            ) { innerPadding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Current Inventory Status
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("Product Overview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Current Stock: ${product.currentStock} units", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                    Text("Min Alert: ${product.minStockAlert}", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("MRP: ₹%.2f".format(product.mrp), style = MaterialTheme.typography.bodySmall)
                                    Text("Selling Price: ₹%.2f".format(product.sellingPrice), fontWeight = FontWeight.SemiBold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Purchase Cost: ₹%.2f".format(product.finalPurchaseCost), style = MaterialTheme.typography.bodySmall)
                                    Text("Points: %.2f pts".format(product.points), fontWeight = FontWeight.SemiBold, color = PointsGold)
                                }
                            }
                        }
                    }

                    // Complete Historical Statistics for this Product
                    item {
                        Text("Lifetime Product Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Purchased", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                    Text("$totalPurchasedQty units", fontWeight = FontWeight.Bold)
                                    Text("₹%.2f".format(totalPurchasedAmount), style = MaterialTheme.typography.bodySmall, color = ForestSecondary)
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Sold", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                    Text("$totalSoldQty units", fontWeight = FontWeight.Bold)
                                    Text("₹%.2f".format(totalSoldAmount), style = MaterialTheme.typography.bodySmall, color = ForestGreenPrimary)
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Profit Earned", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                    Text("₹%.2f".format(totalProfit), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ProfitGreen)
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Purchase Points", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                    Text("%.2f pts".format(totalPoints), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PointsGold)
                                }
                            }
                        }
                    }

                    // Complete Lifetime Purchases Section
                    item {
                        Text("Lifetime Purchase History (${purchases.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (purchases.isEmpty()) {
                            Text("No purchases recorded yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                purchases.forEach { pur ->
                                    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(pur.purchaseDate))
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    "$dateStr ${if (pur.invoiceNumber.isNotBlank()) "• Inv: ${pur.invoiceNumber}" else ""}",
                                                    style = MaterialTheme.typography.labelSmall
                                                )
                                                Text(
                                                    "Qty: ${pur.quantity} units @ ₹%.2f (MRP: ₹%.2f, Disc: %.1f%%, Tax: %.1f%%)"
                                                        .format(pur.finalPricePerUnit, pur.mrp, pur.discountPercentage, pur.taxPercentage),
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                            Text("₹%.2f".format(pur.totalAmount), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Complete Lifetime Sales Section
                    item {
                        Text("Lifetime Sales History (${sales.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (sales.isEmpty()) {
                            Text("No sales recorded yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                sales.forEach { sale ->
                                    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(sale.saleDate))
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("$dateStr • ${sale.customerName ?: "Customer"}", style = MaterialTheme.typography.labelSmall)
                                                Text(
                                                    "Qty: ${sale.quantity} @ ₹%.2f • Profit: ₹%.2f • Points: %.2f pts"
                                                        .format(sale.finalSellingPrice, sale.profit, sale.totalPoints),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = ProfitGreen
                                                )
                                            }
                                            Text("₹%.2f".format(sale.totalSaleAmount), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
