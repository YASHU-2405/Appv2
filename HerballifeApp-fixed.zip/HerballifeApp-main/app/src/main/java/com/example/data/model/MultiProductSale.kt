package com.example.data.model

import java.util.UUID

data class SaleLineItemDraft(
    val id: String = UUID.randomUUID().toString(),
    val product: Product,
    val quantity: Int = 1,
    val baseSellingPrice: Double = product.sellingPrice,
    val discountType: String = "PERCENTAGE", // "PERCENTAGE" or "FIXED_AMOUNT"
    val discountValue: Double = 0.0, // percent or fixed amount
    val gstType: String = product.gstType, // "PERCENTAGE" or "FIXED_AMOUNT"
    val gstValue: Double = if (product.gstType == "PERCENTAGE") product.taxPercentage else product.gstFixedAmount
) {
    val discountAmountPerUnit: Double
        get() = when (discountType) {
            "FIXED_AMOUNT" -> discountValue.coerceAtMost(baseSellingPrice)
            else -> baseSellingPrice * (discountValue.coerceIn(0.0, 100.0) / 100.0)
        }

    val priceAfterDiscount: Double
        get() = (baseSellingPrice - discountAmountPerUnit).coerceAtLeast(0.0)

    val gstAmountPerUnit: Double
        get() = when (gstType) {
            "FIXED_AMOUNT" -> gstValue.coerceAtLeast(0.0)
            else -> priceAfterDiscount * (gstValue.coerceAtLeast(0.0) / 100.0)
        }

    val finalPricePerUnit: Double
        get() = priceAfterDiscount + gstAmountPerUnit

    val lineTotal: Double
        get() = finalPricePerUnit * quantity

    val totalDiscountAmount: Double
        get() = discountAmountPerUnit * quantity

    val totalGstAmount: Double
        get() = gstAmountPerUnit * quantity

    val baseSubtotal: Double
        get() = baseSellingPrice * quantity

    val unitPurchaseCost: Double
        get() = product.finalPurchaseCost

    val totalPurchaseCost: Double
        get() = unitPurchaseCost * quantity

    val lineProfit: Double
        get() = lineTotal - totalPurchaseCost
}
