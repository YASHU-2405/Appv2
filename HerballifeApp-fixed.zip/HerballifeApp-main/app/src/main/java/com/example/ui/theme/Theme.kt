package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import com.example.data.preferences.CustomThemeConfig

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreenPrimaryDark,
    onPrimary = ForestGreenOnPrimaryDark,
    primaryContainer = ForestGreenPrimaryContainerDark,
    onPrimaryContainer = ForestGreenOnPrimaryContainerDark,
    secondary = ForestSecondary,
    surface = SurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    background = BackgroundDark,
    onSurface = OnSurfaceDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = OutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = ForestGreenOnPrimary,
    primaryContainer = ForestGreenPrimaryContainer,
    onPrimaryContainer = ForestGreenOnPrimaryContainer,
    secondary = ForestSecondary,
    onSecondary = ForestOnSecondary,
    secondaryContainer = ForestSecondaryContainer,
    onSecondaryContainer = ForestOnSecondaryContainer,
    tertiary = EmeraldTertiary,
    onTertiary = EmeraldOnTertiary,
    tertiaryContainer = EmeraldTertiaryContainer,
    onTertiaryContainer = EmeraldOnTertiaryContainer,
    surface = SurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    background = BackgroundLight,
    onSurface = OnSurfaceLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outline = OutlineLight
)

fun createCustomColorScheme(config: CustomThemeConfig): ColorScheme {
    val primary = Color(config.primaryColor)
    val secondary = Color(config.secondaryColor)
    val background = Color(config.backgroundColor)
    val surface = Color(config.surfaceColor)
    val textColor = Color(config.textColor)
    val accent = Color(config.accentColor)

    // Contrast check
    val onPrimary = if (primary.luminance() > 0.5f) Color(0xFF1A1C18) else Color.White
    val onSecondary = if (secondary.luminance() > 0.5f) Color(0xFF1A1C18) else Color.White
    val onSurface = textColor
    val onBackground = textColor
    val surfaceVariant = if (config.isDark) surface.copy(alpha = 0.85f) else Color(0xFFEFF3EB)
    val onSurfaceVariant = if (config.isDark) Color(0xFFC3C8BC) else Color(0xFF42493E)

    return if (config.isDark) {
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = primary.copy(alpha = 0.25f),
            onPrimaryContainer = primary,
            secondary = secondary,
            onSecondary = onSecondary,
            tertiary = accent,
            onTertiary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
            surface = surface,
            surfaceVariant = surfaceVariant,
            background = background,
            onSurface = onSurface,
            onBackground = onBackground,
            onSurfaceVariant = onSurfaceVariant,
            outline = onSurfaceVariant.copy(alpha = 0.4f)
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = primary.copy(alpha = 0.15f),
            onPrimaryContainer = primary,
            secondary = secondary,
            onSecondary = onSecondary,
            secondaryContainer = secondary.copy(alpha = 0.15f),
            onSecondaryContainer = secondary,
            tertiary = accent,
            onTertiary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
            surface = surface,
            surfaceVariant = surfaceVariant,
            background = background,
            onSurface = onSurface,
            onBackground = onBackground,
            onSurfaceVariant = onSurfaceVariant,
            outline = Color(0xFF73796E)
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    customConfig: CustomThemeConfig? = null,
    dynamicColor: Boolean = false, // Keep consistent branding colors
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        customConfig != null -> createCustomColorScheme(customConfig)
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

