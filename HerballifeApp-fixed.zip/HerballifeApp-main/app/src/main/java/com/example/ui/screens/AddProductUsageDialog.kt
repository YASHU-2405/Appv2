package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.ProductUsage
import com.example.ui.theme.ForestGreenPrimary
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductUsageDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (ProductUsage) -> Unit
) {
    val inStockProducts = products.filter { it.currentStock > 0 }
    var selectedProductId by remember {
        mutableStateOf<Long?>(inStockProducts.firstOrNull()?.id ?: products.firstOrNull()?.id)
    }
    var expandedProductDropdown by remember { mutableStateOf(false) }
    val selectedProduct = products.find { it.id == selectedProductId }

    var quantityStr by remember { mutableStateOf("1") }
    var purpose by remember { mutableStateOf("Personal Consumption") }
    var notes by remember { mutableStateOf("") }
    var usageDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(usageDateMs))

    val qty = quantityStr.toIntOrNull() ?: 1
    val unitCost = selectedProduct?.finalPurchaseCost ?: 0.0
    val totalCost = unitCost * qty
    val remainingStock = (selectedProduct?.currentStock ?: 0) - qty

    val commonPurposes = listOf("Personal Consumption", "Client Sample / Tasting", "Club Demo", "Staff / Team Use", "Damaged / Expired")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Record Product Usage / Personal Use", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    val prod = selectedProduct ?: run {
                                        errorMessage = "Please select a product"
                                        return@Button
                                    }
                                    if (qty <= 0) {
                                        errorMessage = "Quantity must be at least 1"
                                        return@Button
                                    }
                                    if (qty > prod.currentStock) {
                                        errorMessage = "Cannot use $qty units! Only ${prod.currentStock} units in stock."
                                        return@Button
                                    }

                                    val combinedNotes = if (purpose.isNotBlank()) {
                                        "[${purpose.trim()}] ${notes.trim()}".trim()
                                    } else {
                                        notes.trim()
                                    }
                                    val usage = ProductUsage(
                                        productId = prod.id,
                                        productName = prod.name,
                                        quantity = qty,
                                        unitCost = unitCost,
                                        totalCost = totalCost,
                                        usageDate = usageDateMs,
                                        notes = combinedNotes
                                    )
                                    onSave(usage)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_usage_button")
                            ) {
                                Text("Save Usage Record")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(4.dp))

                    if (errorMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Product Selector
                    Text("Select Product Consumed", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    if (products.isEmpty()) {
                        Text("No products exist in database.", color = MaterialTheme.colorScheme.error)
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = expandedProductDropdown,
                            onExpandedChange = { expandedProductDropdown = !expandedProductDropdown }
                        ) {
                            OutlinedTextField(
                                value = if (selectedProduct != null) "${selectedProduct.name} (Stock: ${selectedProduct.currentStock})" else "Select Product",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProductDropdown) },
                                modifier = Modifier.fillMaxWidth().menuAnchor().testTag("usage_product_dropdown")
                            )
                            ExposedDropdownMenu(
                                expanded = expandedProductDropdown,
                                onDismissRequest = { expandedProductDropdown = false }
                            ) {
                                products.forEach { p ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    "Stock: ${p.currentStock}",
                                                    color = if (p.currentStock > 0) ForestGreenPrimary else MaterialTheme.colorScheme.error
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedProductId = p.id
                                            expandedProductDropdown = false
                                            errorMessage = null
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Quantity and Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = {
                                quantityStr = it
                                errorMessage = null
                            },
                            label = { Text("Quantity Used *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("usage_quantity_input")
                        )

                        OutlinedTextField(
                            value = dateDisplay,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Usage Date") },
                            trailingIcon = {
                                IconButton(onClick = {
                                    val cal = Calendar.getInstance().apply { timeInMillis = usageDateMs }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            usageDateMs = c.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date")
                                }
                            },
                            modifier = Modifier.weight(1.2f)
                        )
                    }

                    // Purpose Section
                    Text("Reason / Purpose", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = purpose,
                        onValueChange = { purpose = it },
                        label = { Text("Purpose *") },
                        placeholder = { Text("e.g. Personal Consumption, Club Demo") },
                        modifier = Modifier.fillMaxWidth().testTag("usage_purpose_input")
                    )

                    // Quick Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        commonPurposes.take(3).forEach { p ->
                            FilterChip(
                                selected = purpose == p,
                                onClick = { purpose = p },
                                label = { Text(p, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    // Cost & Stock Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Usage Accounting Impact", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Unit Cost Basis:", style = MaterialTheme.typography.bodySmall)
                                Text("₹%.2f".format(unitCost), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Usage Value ($qty units):", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(totalCost), fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Remaining Stock:")
                                val stockColor = if (remainingStock < 0) MaterialTheme.colorScheme.error else ForestGreenPrimary
                                Text("$remainingStock units", fontWeight = FontWeight.Bold, color = stockColor)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Additional Notes (Optional)") },
                        modifier = Modifier.fillMaxWidth().testTag("usage_notes_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
