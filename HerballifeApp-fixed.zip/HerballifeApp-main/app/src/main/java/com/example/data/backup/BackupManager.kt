package com.example.data.backup

import android.content.Context
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BillWithItems
import com.example.data.model.BorrowedProduct
import com.example.data.model.Product
import com.example.data.model.ProductUsage
import com.example.data.model.Purchase
import com.example.data.model.PurchaseOrder
import com.example.data.model.Sale
import com.example.data.model.SalePayment
import com.example.data.model.StockMovement
import com.example.data.repository.NutritionRepository
import com.example.util.ReceiptImageStorage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class BackupPayload(
    val exportDate: Long,
    val appVersion: String,
    val products: List<Product>,
    val purchases: List<Purchase>,
    val sales: List<Sale>,
    val movements: List<StockMovement>,
    val usages: List<ProductUsage> = emptyList(),
    val borrowed: List<BorrowedProduct> = emptyList(),
    val payments: List<SalePayment> = emptyList(),
    val purchaseOrders: List<PurchaseOrder> = emptyList(),
    val billsWithItems: List<BillWithItems> = emptyList(),
    val settingsMap: Map<String, String> = emptyMap()
)

class BackupManager(private val repository: NutritionRepository) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val fileTimestampFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault())

    suspend fun generateBackupJson(extraSettings: Map<String, String> = emptyMap()): String {
        val products = repository.getAllProductsList()
        val purchases = repository.getAllPurchasesList()
        val sales = repository.getAllSalesList()
        val movements = repository.getAllMovementsList()
        val usages = repository.getAllProductUsagesList()
        val borrowed = repository.getAllBorrowedProductsList()
        val payments = repository.getAllPaymentsList()
        val purchaseOrders = repository.getAllPurchaseOrdersList()
        val billsWithItems = repository.getAllBillsWithItemsList()

        val root = JSONObject()
        root.put("appName", "Onest Nutrition Manager")
        root.put("version", "3.0")
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("exportDateFormatted", dateFormat.format(Date()))

        // Settings
        val settingsObj = JSONObject()
        extraSettings.forEach { (k, v) -> settingsObj.put(k, v) }
        root.put("settings", settingsObj)

        // Products
        val productsArr = JSONArray()
        for (p in products) {
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            obj.put("sku", p.sku)
            obj.put("variant", p.variant)
            obj.put("mrp", p.mrp)
            obj.put("purchasePrice", p.purchasePrice)
            obj.put("discountPercentage", p.discountPercentage)
            obj.put("gstType", p.gstType)
            obj.put("taxPercentage", p.taxPercentage)
            obj.put("gstFixedAmount", p.gstFixedAmount)
            obj.put("taxAmount", p.taxAmount)
            obj.put("finalPurchaseCost", p.finalPurchaseCost)
            obj.put("sellingPrice", p.sellingPrice)
            obj.put("sellingDiscountPercentage", p.sellingDiscountPercentage)
            obj.put("points", p.points)
            obj.put("currentStock", p.currentStock)
            obj.put("minStockAlert", p.minStockAlert)
            obj.put("notes", p.notes)
            obj.put("imageUri", p.imageUri ?: "")
            obj.put("createdAt", p.createdAt)
            productsArr.put(obj)
        }
        root.put("products", productsArr)

        // Purchases
        val purchasesArr = JSONArray()
        for (pur in purchases) {
            val obj = JSONObject()
            obj.put("id", pur.id)
            obj.put("productId", pur.productId)
            obj.put("productName", pur.productName)
            obj.put("quantity", pur.quantity)
            obj.put("mrp", pur.mrp)
            obj.put("originalPrice", pur.originalPrice)
            obj.put("discountType", pur.discountType)
            obj.put("discountPercentage", pur.discountPercentage)
            obj.put("discountFixedAmount", pur.discountFixedAmount)
            obj.put("discountAmount", pur.discountAmount)
            obj.put("gstType", pur.gstType)
            obj.put("taxPercentage", pur.taxPercentage)
            obj.put("gstFixedAmount", pur.gstFixedAmount)
            obj.put("taxAmount", pur.taxAmount)
            obj.put("finalPricePerUnit", pur.finalPricePerUnit)
            obj.put("totalAmount", pur.totalAmount)
            obj.put("purchaseDate", pur.purchaseDate)
            obj.put("invoiceNumber", pur.invoiceNumber)
            obj.put("notes", pur.notes)
            obj.put("pointsPerUnit", pur.pointsPerUnit)
            obj.put("totalPoints", pur.totalPoints)
            obj.put("orderId", pur.orderId ?: -1L)
            obj.put("supplierName", pur.supplierName)
            obj.put("receiptImageUri", pur.receiptImageUri ?: "")
            purchasesArr.put(obj)
        }
        root.put("purchases", purchasesArr)

        // Purchase Orders
        val ordersArr = JSONArray()
        for (po in purchaseOrders) {
            val obj = JSONObject()
            obj.put("id", po.id)
            obj.put("orderNumber", po.orderNumber)
            obj.put("invoiceNumber", po.invoiceNumber)
            obj.put("supplierName", po.supplierName)
            obj.put("purchaseDate", po.purchaseDate)
            obj.put("totalProducts", po.totalProducts)
            obj.put("totalQuantity", po.totalQuantity)
            obj.put("totalOriginalAmount", po.totalOriginalAmount)
            obj.put("totalDiscountAmount", po.totalDiscountAmount)
            obj.put("totalGstAmount", po.totalGstAmount)
            obj.put("finalPurchaseAmount", po.finalPurchaseAmount)
            obj.put("totalPoints", po.totalPoints)
            obj.put("notes", po.notes)
            obj.put("receiptImageUri", po.receiptImageUri ?: "")
            ordersArr.put(obj)
        }
        root.put("purchaseOrders", ordersArr)

        // Sales
        val salesArr = JSONArray()
        for (s in sales) {
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("productId", s.productId)
            obj.put("productName", s.productName)
            obj.put("quantity", s.quantity)
            obj.put("sellingPrice", s.sellingPrice)
            obj.put("discountType", s.discountType)
            obj.put("discountPercentage", s.discountPercentage)
            obj.put("discountFixedAmount", s.discountFixedAmount)
            obj.put("discountAmount", s.discountAmount)
            obj.put("gstType", s.gstType)
            obj.put("taxPercentage", s.taxPercentage)
            obj.put("gstFixedAmount", s.gstFixedAmount)
            obj.put("taxAmount", s.gstAmount)
            obj.put("finalSellingPrice", s.finalSellingPrice)
            obj.put("totalSaleAmount", s.totalSaleAmount)
            obj.put("unitPurchaseCost", s.unitPurchaseCost)
            obj.put("totalPurchaseCost", s.totalPurchaseCost)
            obj.put("profit", s.profit)
            obj.put("pointsPerUnit", s.pointsPerUnit)
            obj.put("totalPoints", s.totalPoints)
            obj.put("customerName", s.customerName ?: "")
            obj.put("customerContact", s.customerContact ?: "")
            obj.put("customerEmail", s.customerEmail ?: "")
            obj.put("customerAddress", s.customerAddress ?: "")
            obj.put("fromBorrowedId", s.fromBorrowedId ?: -1L)
            obj.put("saleDate", s.saleDate)
            obj.put("notes", s.notes)
            obj.put("paymentStatus", s.paymentStatus)
            obj.put("amountReceived", s.amountReceived)
            obj.put("amountPending", s.amountPending)
            obj.put("paymentMethod", s.paymentMethod)
            obj.put("paymentDate", s.paymentDate ?: -1L)
            obj.put("paymentNote", s.paymentNote)
            obj.put("receiptImageUri", s.receiptImageUri ?: "")
            salesArr.put(obj)
        }
        root.put("sales", salesArr)

        // Payments
        val paymentsArr = JSONArray()
        for (pay in payments) {
            val obj = JSONObject()
            obj.put("id", pay.id)
            obj.put("saleId", pay.saleId)
            obj.put("customerName", pay.customerName ?: "")
            obj.put("customerContact", pay.customerContact ?: "")
            obj.put("amount", pay.amount)
            obj.put("paymentDate", pay.paymentDate)
            obj.put("paymentMethod", pay.paymentMethod)
            obj.put("notes", pay.notes)
            obj.put("receiptImageUri", pay.receiptImageUri ?: "")
            paymentsArr.put(obj)
        }
        root.put("salePayments", paymentsArr)

        // Movements
        val movementsArr = JSONArray()
        for (m in movements) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("productId", m.productId)
            obj.put("productName", m.productName)
            obj.put("movementType", m.movementType)
            obj.put("quantityChange", m.quantityChange)
            obj.put("remainingStock", m.remainingStock)
            obj.put("referenceId", m.referenceId ?: -1L)
            obj.put("timestamp", m.timestamp)
            obj.put("notes", m.notes)
            movementsArr.put(obj)
        }
        root.put("stockMovements", movementsArr)

        // Product Usages
        val usagesArr = JSONArray()
        for (u in usages) {
            val obj = JSONObject()
            obj.put("id", u.id)
            obj.put("productId", u.productId)
            obj.put("productName", u.productName)
            obj.put("quantity", u.quantity)
            obj.put("unitCost", u.unitCost)
            obj.put("totalCost", u.totalCost)
            obj.put("usageDate", u.usageDate)
            obj.put("notes", u.notes)
            obj.put("receiptImageUri", u.receiptImageUri ?: "")
            usagesArr.put(obj)
        }
        root.put("productUsages", usagesArr)

        // Borrowed Products
        val borrowedArr = JSONArray()
        for (b in borrowed) {
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("personOrBusinessName", b.personOrBusinessName)
            obj.put("contactNumber", b.contactNumber ?: "")
            obj.put("productId", b.productId)
            obj.put("productName", b.productName)
            obj.put("quantityBorrowed", b.quantityBorrowed)
            obj.put("quantityReturned", b.quantityReturned)
            obj.put("quantitySold", b.quantitySold)
            obj.put("unitValue", b.unitValue)
            obj.put("totalValue", b.totalValue)
            obj.put("dateReceived", b.dateReceived)
            obj.put("expectedReturnDate", b.expectedReturnDate ?: -1L)
            obj.put("notes", b.notes)
            obj.put("status", b.status)
            obj.put("settlementAmount", b.settlementAmount ?: 0.0)
            obj.put("settlementDate", b.settlementDate ?: -1L)
            obj.put("settlementNotes", b.settlementNotes ?: "")
            obj.put("receiptImageUri", b.receiptImageUri ?: "")
            borrowedArr.put(obj)
        }
        root.put("borrowedProducts", borrowedArr)

        // Bills with line items
        val billsArr = JSONArray()
        for (bwi in billsWithItems) {
            val b = bwi.bill
            val bObj = JSONObject()
            bObj.put("id", b.id)
            bObj.put("billNumber", b.billNumber)
            bObj.put("billDate", b.billDate)
            bObj.put("supplierName", b.supplierName)
            bObj.put("billImageUri", b.billImageUri ?: "")
            bObj.put("totalOriginalAmount", b.totalOriginalAmount)
            bObj.put("totalDiscountAmount", b.totalDiscountAmount)
            bObj.put("totalGstAmount", b.totalGstAmount)
            bObj.put("finalAmount", b.finalAmount)
            bObj.put("amountPaid", b.amountPaid)
            bObj.put("amountPending", b.amountPending)
            bObj.put("paymentStatus", b.paymentStatus)
            bObj.put("notes", b.notes)
            bObj.put("linkedPurchaseOrderId", b.linkedPurchaseOrderId ?: -1L)

            val itemsArr = JSONArray()
            for (item in bwi.items) {
                val itObj = JSONObject()
                itObj.put("id", item.id)
                itObj.put("billId", item.billId)
                itObj.put("productId", item.productId ?: -1L)
                itObj.put("productName", item.productName)
                itObj.put("quantity", item.quantity)
                itObj.put("originalPrice", item.originalPrice)
                itObj.put("discountPercentage", item.discountPercentage)
                itObj.put("discountAmount", item.discountAmount)
                itObj.put("taxPercentage", item.taxPercentage)
                itObj.put("taxAmount", item.taxAmount)
                itObj.put("finalPricePerUnit", item.finalPricePerUnit)
                itObj.put("totalAmount", item.totalAmount)
                itObj.put("needsReview", item.needsReview)
                itemsArr.put(itObj)
            }
            bObj.put("items", itemsArr)
            billsArr.put(bObj)
        }
        root.put("bills", billsArr)

        return root.toString(2)
    }

    suspend fun exportSalesCsv(): String {
        val sales = repository.getAllSalesList()
        val sb = StringBuilder()
        sb.append("Sale ID,Date,Product,Quantity,Selling Price,Discount,GST,Final Unit Price,Total Amount,Unit Cost,Total Cost,Profit,Points,Customer Name,Customer Contact,Payment Status,Amount Received,Amount Pending,Payment Method,Notes\n")
        for (s in sales) {
            val dateStr = dateFormat.format(Date(s.saleDate))
            sb.append("\"${s.id}\",")
            sb.append("\"$dateStr\",")
            sb.append("\"${escapeCsv(s.productName)}\",")
            sb.append("${s.quantity},")
            sb.append("%.2f,".format(s.sellingPrice))
            sb.append("%.2f,".format(s.discountAmount))
            sb.append("%.2f,".format(s.gstAmount))
            sb.append("%.2f,".format(s.finalSellingPrice))
            sb.append("%.2f,".format(s.totalSaleAmount))
            sb.append("%.2f,".format(s.unitPurchaseCost))
            sb.append("%.2f,".format(s.totalPurchaseCost))
            sb.append("%.2f,".format(s.profit))
            sb.append("%.2f,".format(s.totalPoints))
            sb.append("\"${escapeCsv(s.customerName ?: "")}\",")
            sb.append("\"${escapeCsv(s.customerContact ?: "")}\",")
            sb.append("\"${s.paymentStatus}\",")
            sb.append("%.2f,".format(s.amountReceived))
            sb.append("%.2f,".format(s.amountPending))
            sb.append("\"${escapeCsv(s.paymentMethod)}\",")
            sb.append("\"${escapeCsv(s.notes)}\"\n")
        }
        return sb.toString()
    }

    suspend fun exportPurchasesCsv(): String {
        val purchases = repository.getAllPurchasesList()
        val sb = StringBuilder()
        sb.append("Purchase ID,Date,Invoice Number,Supplier,Product,Quantity,Original Unit Price,Discount %,Discount Amount,GST %,GST Amount,Final Unit Cost,Total Amount,Points,Notes\n")
        for (p in purchases) {
            val dateStr = dateFormat.format(Date(p.purchaseDate))
            sb.append("\"${p.id}\",")
            sb.append("\"$dateStr\",")
            sb.append("\"${escapeCsv(p.invoiceNumber)}\",")
            sb.append("\"${escapeCsv(p.supplierName)}\",")
            sb.append("\"${escapeCsv(p.productName)}\",")
            sb.append("${p.quantity},")
            sb.append("%.2f,".format(p.originalPrice))
            sb.append("%.2f,".format(p.discountPercentage))
            sb.append("%.2f,".format(p.discountAmount))
            sb.append("%.2f,".format(p.taxPercentage))
            sb.append("%.2f,".format(p.taxAmount))
            sb.append("%.2f,".format(p.finalPricePerUnit))
            sb.append("%.2f,".format(p.totalAmount))
            sb.append("%.2f,".format(p.totalPoints))
            sb.append("\"${escapeCsv(p.notes)}\"\n")
        }
        return sb.toString()
    }

    suspend fun exportProductsCsv(): String {
        val products = repository.getAllProductsList()
        val sb = StringBuilder()
        sb.append("Product ID,Name,SKU,Variant,MRP,Purchase Price,Default Discount %,GST %,Final Cost,Selling Price,Margin %,Stock,Min Alert,Points,Notes\n")
        for (p in products) {
            val margin = if (p.sellingPrice > 0) ((p.sellingPrice - p.finalPurchaseCost) / p.sellingPrice) * 100.0 else 0.0
            sb.append("\"${p.id}\",")
            sb.append("\"${escapeCsv(p.name)}\",")
            sb.append("\"${escapeCsv(p.sku)}\",")
            sb.append("\"${escapeCsv(p.variant)}\",")
            sb.append("%.2f,".format(p.mrp))
            sb.append("%.2f,".format(p.purchasePrice))
            sb.append("%.2f,".format(p.discountPercentage))
            sb.append("%.2f,".format(p.taxPercentage))
            sb.append("%.2f,".format(p.finalPurchaseCost))
            sb.append("%.2f,".format(p.sellingPrice))
            sb.append("%.1f%%,".format(margin))
            sb.append("${p.currentStock},")
            sb.append("${p.minStockAlert},")
            sb.append("%.2f,".format(p.points))
            sb.append("\"${escapeCsv(p.notes)}\"\n")
        }
        return sb.toString()
    }

    suspend fun exportPaymentsCsv(): String {
        val payments = repository.getAllPaymentsList()
        val sb = StringBuilder()
        sb.append("Payment ID,Sale ID,Date,Customer Name,Contact,Amount Received,Payment Method,Notes\n")
        for (pay in payments) {
            val dateStr = dateFormat.format(Date(pay.paymentDate))
            sb.append("\"${pay.id}\",")
            sb.append("\"${pay.saleId}\",")
            sb.append("\"$dateStr\",")
            sb.append("\"${escapeCsv(pay.customerName ?: "")}\",")
            sb.append("\"${escapeCsv(pay.customerContact ?: "")}\",")
            sb.append("%.2f,".format(pay.amount))
            sb.append("\"${escapeCsv(pay.paymentMethod)}\",")
            sb.append("\"${escapeCsv(pay.notes)}\"\n")
        }
        return sb.toString()
    }

    suspend fun exportStockMovementsCsv(): String {
        val movements = repository.getAllMovementsList()
        val sb = StringBuilder()
        sb.append("Movement ID,Timestamp,Product,Type,Quantity Change,Remaining Stock,Reference ID,Notes\n")
        for (m in movements) {
            val dateStr = dateFormat.format(Date(m.timestamp))
            sb.append("\"${m.id}\",")
            sb.append("\"$dateStr\",")
            sb.append("\"${escapeCsv(m.productName)}\",")
            sb.append("\"${m.movementType}\",")
            sb.append("${m.quantityChange},")
            sb.append("${m.remainingStock},")
            sb.append("\"${m.referenceId ?: ""}\",")
            sb.append("\"${escapeCsv(m.notes)}\"\n")
        }
        return sb.toString()
    }

    suspend fun exportCustomerLedgerCsv(): String {
        val sales = repository.getAllSalesList()
        val payments = repository.getAllPaymentsList()
        val customers = sales.mapNotNull { it.customerName?.takeIf { name -> name.isNotBlank() } }.distinct()
        val sb = StringBuilder()
        sb.append("Customer Name,Total Sales Value,Total Amount Received,Total Balance Pending,Total Purchases Count\n")
        for (c in customers) {
            val custSales = sales.filter { it.customerName.equals(c, ignoreCase = true) }
            val totalSales = custSales.sumOf { it.totalSaleAmount }
            val totalRec = custSales.sumOf { it.amountReceived }
            val totalPend = custSales.sumOf { it.amountPending }
            sb.append("\"${escapeCsv(c)}\",")
            sb.append("%.2f,".format(totalSales))
            sb.append("%.2f,".format(totalRec))
            sb.append("%.2f,".format(totalPend))
            sb.append("${custSales.size}\n")
        }
        return sb.toString()
    }

    /**
     * Creates a complete, offline backup package (.ZIP) containing data.json, CSVs, and receipt images
     */
    suspend fun generateCompleteBackupZip(context: Context, extraSettings: Map<String, String> = emptyMap()): File {
        val timestamp = fileTimestampFormat.format(Date())
        val backupDir = File(context.cacheDir, "backups")
        if (!backupDir.exists()) backupDir.mkdirs()

        val zipFile = File(backupDir, "OnestNutrition_Backup_$timestamp.zip")
        val jsonContent = generateBackupJson(extraSettings)
        val salesCsv = exportSalesCsv()
        val purchasesCsv = exportPurchasesCsv()
        val productsCsv = exportProductsCsv()
        val paymentsCsv = exportPaymentsCsv()
        val movementsCsv = exportStockMovementsCsv()
        val ledgerCsv = exportCustomerLedgerCsv()

        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            // 1. data.json
            addZipTextEntry(zos, "data.json", jsonContent)
            // 2. CSVs
            addZipTextEntry(zos, "sales.csv", salesCsv)
            addZipTextEntry(zos, "purchases.csv", purchasesCsv)
            addZipTextEntry(zos, "products.csv", productsCsv)
            addZipTextEntry(zos, "payments.csv", paymentsCsv)
            addZipTextEntry(zos, "stock_movements.csv", movementsCsv)
            addZipTextEntry(zos, "customer_ledger.csv", ledgerCsv)

            // 3. Receipt Images
            val receiptsDir = ReceiptImageStorage.getReceiptsDir(context)
            if (receiptsDir.exists() && receiptsDir.isDirectory) {
                receiptsDir.listFiles()?.forEach { imgFile ->
                    if (imgFile.isFile && imgFile.length() > 0) {
                        zos.putNextEntry(ZipEntry("receipt_images/${imgFile.name}"))
                        FileInputStream(imgFile).use { fis -> fis.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
        }
        return zipFile
    }

    private fun addZipTextEntry(zos: ZipOutputStream, entryName: String, text: String) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        zos.write(bytes)
        zos.closeEntry()
    }

    private fun escapeCsv(value: String): String {
        return value.replace("\"", "\"\"").replace("\n", " ")
    }

    suspend fun restoreFromJson(jsonString: String, isMerge: Boolean = false): Result<BackupPayload> {
        return try {
            val root = JSONObject(jsonString)
            val appVersion = root.optString("version", "1.0")
            val exportDate = root.optLong("exportTimestamp", System.currentTimeMillis())

            val products = mutableListOf<Product>()
            val purchases = mutableListOf<Purchase>()
            val sales = mutableListOf<Sale>()
            val movements = mutableListOf<StockMovement>()
            val usages = mutableListOf<ProductUsage>()
            val borrowed = mutableListOf<BorrowedProduct>()
            val payments = mutableListOf<SalePayment>()
            val purchaseOrders = mutableListOf<PurchaseOrder>()
            val billsWithItems = mutableListOf<BillWithItems>()
            val settingsMap = mutableMapOf<String, String>()

            // Settings
            val settingsObj = root.optJSONObject("settings")
            settingsObj?.keys()?.forEach { key ->
                settingsMap[key] = settingsObj.optString(key, "")
            }

            // Products
            val productsArr = root.optJSONArray("products") ?: JSONArray()
            for (i in 0 until productsArr.length()) {
                val obj = productsArr.getJSONObject(i)
                products.add(
                    Product(
                        id = obj.optLong("id", 0),
                        name = obj.getString("name"),
                        sku = obj.optString("sku", ""),
                        variant = obj.optString("variant", ""),
                        mrp = obj.optDouble("mrp", 0.0),
                        purchasePrice = obj.optDouble("purchasePrice", 0.0),
                        discountPercentage = obj.optDouble("discountPercentage", 0.0),
                        gstType = obj.optString("gstType", "PERCENTAGE"),
                        taxPercentage = obj.optDouble("taxPercentage", 0.0),
                        gstFixedAmount = obj.optDouble("gstFixedAmount", 0.0),
                        taxAmount = obj.optDouble("taxAmount", 0.0),
                        finalPurchaseCost = obj.optDouble("finalPurchaseCost", 0.0),
                        sellingPrice = obj.optDouble("sellingPrice", 0.0),
                        sellingDiscountPercentage = obj.optDouble("sellingDiscountPercentage", 0.0),
                        points = obj.optDouble("points", 0.0),
                        currentStock = obj.optInt("currentStock", 0),
                        minStockAlert = obj.optInt("minStockAlert", 5),
                        notes = obj.optString("notes", ""),
                        imageUri = obj.optString("imageUri").takeIf { it.isNotBlank() },
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            // Purchases
            val purchasesArr = root.optJSONArray("purchases") ?: JSONArray()
            for (i in 0 until purchasesArr.length()) {
                val obj = purchasesArr.getJSONObject(i)
                val ordId = obj.optLong("orderId", -1L)
                purchases.add(
                    Purchase(
                        id = obj.optLong("id", 0),
                        productId = obj.getLong("productId"),
                        productName = obj.optString("productName", "Product"),
                        quantity = obj.getInt("quantity"),
                        mrp = obj.optDouble("mrp", 0.0),
                        originalPrice = obj.optDouble("originalPrice", 0.0),
                        discountType = obj.optString("discountType", "PERCENTAGE"),
                        discountPercentage = obj.optDouble("discountPercentage", 0.0),
                        discountFixedAmount = obj.optDouble("discountFixedAmount", 0.0),
                        discountAmount = obj.optDouble("discountAmount", 0.0),
                        gstType = obj.optString("gstType", "PERCENTAGE"),
                        taxPercentage = obj.optDouble("taxPercentage", 0.0),
                        gstFixedAmount = obj.optDouble("gstFixedAmount", 0.0),
                        taxAmount = obj.optDouble("taxAmount", 0.0),
                        finalPricePerUnit = obj.optDouble("finalPricePerUnit", 0.0),
                        totalAmount = obj.optDouble("totalAmount", 0.0),
                        purchaseDate = obj.optLong("purchaseDate", System.currentTimeMillis()),
                        invoiceNumber = obj.optString("invoiceNumber", ""),
                        notes = obj.optString("notes", ""),
                        pointsPerUnit = obj.optDouble("pointsPerUnit", 0.0),
                        totalPoints = obj.optDouble("totalPoints", 0.0),
                        orderId = if (ordId > 0) ordId else null,
                        supplierName = obj.optString("supplierName", ""),
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Purchase Orders
            val ordersArr = root.optJSONArray("purchaseOrders") ?: JSONArray()
            for (i in 0 until ordersArr.length()) {
                val obj = ordersArr.getJSONObject(i)
                purchaseOrders.add(
                    PurchaseOrder(
                        id = obj.optLong("id", 0),
                        orderNumber = obj.getString("orderNumber"),
                        invoiceNumber = obj.optString("invoiceNumber", ""),
                        supplierName = obj.optString("supplierName", ""),
                        purchaseDate = obj.optLong("purchaseDate", System.currentTimeMillis()),
                        totalProducts = obj.optInt("totalProducts", 0),
                        totalQuantity = obj.optInt("totalQuantity", 0),
                        totalOriginalAmount = obj.optDouble("totalOriginalAmount", 0.0),
                        totalDiscountAmount = obj.optDouble("totalDiscountAmount", 0.0),
                        totalGstAmount = obj.optDouble("totalGstAmount", 0.0),
                        finalPurchaseAmount = obj.optDouble("finalPurchaseAmount", 0.0),
                        totalPoints = obj.optDouble("totalPoints", 0.0),
                        notes = obj.optString("notes", ""),
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Sales
            val salesArr = root.optJSONArray("sales") ?: JSONArray()
            for (i in 0 until salesArr.length()) {
                val obj = salesArr.getJSONObject(i)
                val fromB = obj.optLong("fromBorrowedId", -1L)
                val pDate = obj.optLong("paymentDate", -1L)
                val totAmount = obj.optDouble("totalSaleAmount", 0.0)
                val recAmount = obj.optDouble("amountReceived", totAmount) // default to totAmount for backwards compatibility
                val pendAmount = obj.optDouble("amountPending", (totAmount - recAmount).coerceAtLeast(0.0))
                val payStatus = obj.optString("paymentStatus", if (pendAmount <= 0.001) "PAID" else if (recAmount > 0) "PARTIAL" else "PENDING")

                sales.add(
                    Sale(
                        id = obj.optLong("id", 0),
                        productId = obj.getLong("productId"),
                        productName = obj.optString("productName", "Product"),
                        quantity = obj.getInt("quantity"),
                        sellingPrice = obj.optDouble("sellingPrice", 0.0),
                        discountType = obj.optString("discountType", "PERCENTAGE"),
                        discountPercentage = obj.optDouble("discountPercentage", 0.0),
                        discountFixedAmount = obj.optDouble("discountFixedAmount", 0.0),
                        discountAmount = obj.optDouble("discountAmount", 0.0),
                        gstType = obj.optString("gstType", "PERCENTAGE"),
                        taxPercentage = obj.optDouble("taxPercentage", 0.0),
                        gstFixedAmount = obj.optDouble("gstFixedAmount", 0.0),
                        gstAmount = obj.optDouble("gstAmount", 0.0),
                        finalSellingPrice = obj.optDouble("finalSellingPrice", 0.0),
                        totalSaleAmount = totAmount,
                        unitPurchaseCost = obj.optDouble("unitPurchaseCost", 0.0),
                        totalPurchaseCost = obj.optDouble("totalPurchaseCost", 0.0),
                        profit = obj.optDouble("profit", 0.0),
                        pointsPerUnit = obj.optDouble("pointsPerUnit", 0.0),
                        totalPoints = obj.optDouble("totalPoints", 0.0),
                        customerName = obj.optString("customerName").takeIf { it.isNotBlank() },
                        customerContact = obj.optString("customerContact").takeIf { it.isNotBlank() },
                        customerEmail = obj.optString("customerEmail").takeIf { it.isNotBlank() },
                        customerAddress = obj.optString("customerAddress").takeIf { it.isNotBlank() },
                        fromBorrowedId = if (fromB > 0) fromB else null,
                        saleDate = obj.optLong("saleDate", System.currentTimeMillis()),
                        notes = obj.optString("notes", ""),
                        paymentStatus = payStatus,
                        amountReceived = recAmount,
                        amountPending = pendAmount,
                        paymentMethod = obj.optString("paymentMethod", "Cash"),
                        paymentDate = if (pDate > 0) pDate else null,
                        paymentNote = obj.optString("paymentNote", ""),
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Sale Payments
            val paymentsArr = root.optJSONArray("salePayments") ?: JSONArray()
            for (i in 0 until paymentsArr.length()) {
                val obj = paymentsArr.getJSONObject(i)
                payments.add(
                    SalePayment(
                        id = obj.optLong("id", 0),
                        saleId = obj.getLong("saleId"),
                        customerName = obj.optString("customerName").takeIf { it.isNotBlank() },
                        customerContact = obj.optString("customerContact").takeIf { it.isNotBlank() },
                        amount = obj.optDouble("amount", 0.0),
                        paymentDate = obj.optLong("paymentDate", System.currentTimeMillis()),
                        paymentMethod = obj.optString("paymentMethod", "Cash"),
                        notes = obj.optString("notes", ""),
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Stock Movements
            val movementsArr = root.optJSONArray("stockMovements") ?: JSONArray()
            for (i in 0 until movementsArr.length()) {
                val obj = movementsArr.getJSONObject(i)
                val ref = obj.optLong("referenceId", -1L)
                movements.add(
                    StockMovement(
                        id = obj.optLong("id", 0),
                        productId = obj.getLong("productId"),
                        productName = obj.optString("productName", "Product"),
                        movementType = obj.optString("movementType", "ADJUSTMENT"),
                        quantityChange = obj.optInt("quantityChange", 0),
                        remainingStock = obj.optInt("remainingStock", 0),
                        referenceId = if (ref > 0) ref else null,
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        notes = obj.optString("notes", "")
                    )
                )
            }

            // Usages
            val usagesArr = root.optJSONArray("productUsages") ?: JSONArray()
            for (i in 0 until usagesArr.length()) {
                val obj = usagesArr.getJSONObject(i)
                usages.add(
                    ProductUsage(
                        id = obj.optLong("id", 0),
                        productId = obj.getLong("productId"),
                        productName = obj.optString("productName", "Product"),
                        quantity = obj.getInt("quantity"),
                        unitCost = obj.optDouble("unitCost", 0.0),
                        totalCost = obj.optDouble("totalCost", 0.0),
                        usageDate = obj.optLong("usageDate", System.currentTimeMillis()),
                        notes = obj.optString("notes", ""),
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Borrowed
            val borrowedArr = root.optJSONArray("borrowedProducts") ?: JSONArray()
            for (i in 0 until borrowedArr.length()) {
                val obj = borrowedArr.getJSONObject(i)
                val expDate = obj.optLong("expectedReturnDate", -1L)
                val setDate = obj.optLong("settlementDate", -1L)
                borrowed.add(
                    BorrowedProduct(
                        id = obj.optLong("id", 0),
                        personOrBusinessName = obj.getString("personOrBusinessName"),
                        contactNumber = obj.optString("contactNumber").takeIf { it.isNotBlank() },
                        productId = obj.getLong("productId"),
                        productName = obj.optString("productName", "Product"),
                        quantityBorrowed = obj.getInt("quantityBorrowed"),
                        quantityReturned = obj.optInt("quantityReturned", 0),
                        quantitySold = obj.optInt("quantitySold", 0),
                        unitValue = obj.optDouble("unitValue", 0.0),
                        totalValue = obj.optDouble("totalValue", 0.0),
                        dateReceived = obj.optLong("dateReceived", System.currentTimeMillis()),
                        expectedReturnDate = if (expDate > 0) expDate else null,
                        notes = obj.optString("notes", ""),
                        status = obj.optString("status", "BORROWED"),
                        settlementAmount = obj.optDouble("settlementAmount").takeIf { it > 0 },
                        settlementDate = if (setDate > 0) setDate else null,
                        settlementNotes = obj.optString("settlementNotes").takeIf { it.isNotBlank() },
                        receiptImageUri = obj.optString("receiptImageUri").takeIf { it.isNotBlank() }
                    )
                )
            }

            // Bills
            val billsArr = root.optJSONArray("bills") ?: JSONArray()
            for (i in 0 until billsArr.length()) {
                val bObj = billsArr.getJSONObject(i)
                val linkedPo = bObj.optLong("linkedPurchaseOrderId", -1L)
                val totOrig = bObj.optDouble("totalOriginalAmount", 0.0)
                val totFin = bObj.optDouble("finalAmount", 0.0)
                val pd = bObj.optDouble("amountPaid", 0.0)
                val pnd = bObj.optDouble("amountPending", (totFin - pd).coerceAtLeast(0.0))
                val pStat = bObj.optString("paymentStatus", if (pnd <= 0.001) "PAID" else if (pd > 0) "PARTIAL" else "PENDING")

                val bill = Bill(
                    id = bObj.optLong("id", 0),
                    billNumber = bObj.getString("billNumber"),
                    billDate = bObj.optLong("billDate", System.currentTimeMillis()),
                    supplierName = bObj.optString("supplierName", ""),
                    billImageUri = bObj.optString("billImageUri").takeIf { it.isNotBlank() },
                    totalOriginalAmount = totOrig,
                    totalDiscountAmount = bObj.optDouble("totalDiscountAmount", 0.0),
                    totalGstAmount = bObj.optDouble("totalGstAmount", 0.0),
                    finalAmount = totFin,
                    amountPaid = pd,
                    amountPending = pnd,
                    paymentStatus = pStat,
                    notes = bObj.optString("notes", ""),
                    linkedPurchaseOrderId = if (linkedPo > 0) linkedPo else null
                )

                val itemsArr = bObj.optJSONArray("items") ?: JSONArray()
                val billItems = mutableListOf<BillItem>()
                for (j in 0 until itemsArr.length()) {
                    val itObj = itemsArr.getJSONObject(j)
                    val prodId = itObj.optLong("productId", -1L)
                    billItems.add(
                        BillItem(
                            id = itObj.optLong("id", 0),
                            billId = itObj.optLong("billId", bill.id),
                            productId = if (prodId > 0) prodId else null,
                            productName = itObj.getString("productName"),
                            quantity = itObj.getInt("quantity"),
                            originalPrice = itObj.optDouble("originalPrice", 0.0),
                            discountPercentage = itObj.optDouble("discountPercentage", 0.0),
                            discountAmount = itObj.optDouble("discountAmount", 0.0),
                            taxPercentage = itObj.optDouble("taxPercentage", 0.0),
                            taxAmount = itObj.optDouble("taxAmount", 0.0),
                            finalPricePerUnit = itObj.optDouble("finalPricePerUnit", 0.0),
                            totalAmount = itObj.optDouble("totalAmount", 0.0),
                            needsReview = itObj.optBoolean("needsReview", false)
                        )
                    )
                }
                billsWithItems.add(BillWithItems(bill = bill, items = billItems))
            }

            // Restore into database atomically
            if (isMerge) {
                repository.restoreMergeData(
                    products = products,
                    purchases = purchases,
                    sales = sales,
                    movements = movements,
                    usages = usages,
                    borrowed = borrowed,
                    payments = payments,
                    purchaseOrders = purchaseOrders,
                    billsWithItems = billsWithItems
                )
            } else {
                repository.restoreAllData(
                    products = products,
                    purchases = purchases,
                    sales = sales,
                    movements = movements,
                    usages = usages,
                    borrowed = borrowed,
                    payments = payments,
                    purchaseOrders = purchaseOrders,
                    billsWithItems = billsWithItems
                )
            }

            val payload = BackupPayload(
                exportDate = exportDate,
                appVersion = appVersion,
                products = products,
                purchases = purchases,
                sales = sales,
                movements = movements,
                usages = usages,
                borrowed = borrowed,
                payments = payments,
                purchaseOrders = purchaseOrders,
                billsWithItems = billsWithItems,
                settingsMap = settingsMap
            )
            Result.success(payload)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Restores backup from a ZIP file by unzipping data.json and receipt images
     */
    suspend fun restoreFromZip(context: Context, zipFile: File, isMerge: Boolean = false): Result<BackupPayload> {
        return try {
            var jsonString: String? = null
            val receiptsDir = ReceiptImageStorage.getReceiptsDir(context)

            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name
                    if (entryName == "data.json") {
                        jsonString = zis.bufferedReader(Charsets.UTF_8).readText()
                    } else if (entryName.startsWith("receipt_images/") && !entry.isDirectory) {
                        val fileName = entryName.substringAfter("receipt_images/")
                        val destFile = File(receiptsDir, fileName)
                        FileOutputStream(destFile).use { fos -> zis.copyTo(fos) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (jsonString.isNullOrBlank()) {
                throw IllegalArgumentException("The selected ZIP file does not contain a valid 'data.json' backup file.")
            }

            restoreFromJson(jsonString!!, isMerge)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
