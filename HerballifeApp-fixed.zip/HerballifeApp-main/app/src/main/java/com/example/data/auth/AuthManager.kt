package com.example.data.auth

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

data class AccountInfo(
    val name: String,
    val username: String,
    val passwordHash: String,
    val salt: String,
    val securityQuestion: String,
    val securityAnswerHash: String,
    val createdAtMs: Long
)

sealed class AuthState {
    object Loading : AuthState()
    object Unauthenticated : AuthState()
    data class Authenticated(val account: AccountInfo) : AuthState()
}

class AuthManager private constructor(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("onest_nutrition_auth_prefs", Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Loading)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        checkSession()
    }

    fun hasAccount(): Boolean {
        return prefs.contains(KEY_USERNAME) && prefs.contains(KEY_PASSWORD_HASH)
    }

    fun isRememberMeEnabled(): Boolean {
        return prefs.getBoolean(KEY_REMEMBER_ME, true)
    }

    fun checkSession() {
        val hasAcc = hasAccount()
        if (!hasAcc) {
            _authState.value = AuthState.Unauthenticated
            return
        }

        val rememberMe = prefs.getBoolean(KEY_REMEMBER_ME, true)
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)

        if (rememberMe && isLoggedIn) {
            val acc = loadAccount()
            if (acc != null) {
                _authState.value = AuthState.Authenticated(acc)
            } else {
                _authState.value = AuthState.Unauthenticated
            }
        } else {
            _authState.value = AuthState.Unauthenticated
        }
    }

    fun getAccount(): AccountInfo? = loadAccount()

    fun register(
        name: String,
        username: String,
        password: String,
        securityQuestion: String,
        securityAnswer: String,
        rememberMe: Boolean = true
    ): Result<AccountInfo> {
        val trimmedName = name.trim()
        val trimmedUsername = username.trim().lowercase()
        val trimmedPassword = password.trim()
        val trimmedQuestion = securityQuestion.trim()
        val trimmedAnswer = securityAnswer.trim().lowercase()

        if (trimmedName.isBlank()) {
            return Result.failure(IllegalArgumentException("Name cannot be empty"))
        }
        if (trimmedUsername.length < 3) {
            return Result.failure(IllegalArgumentException("Username/Email must be at least 3 characters"))
        }
        if (trimmedPassword.length < 4) {
            return Result.failure(IllegalArgumentException("Password must be at least 4 characters"))
        }
        if (trimmedQuestion.isBlank() || trimmedAnswer.isBlank()) {
            return Result.failure(IllegalArgumentException("Please provide a security question and answer for recovery"))
        }

        val salt = generateSalt()
        val passwordHash = hashPassword(trimmedPassword, salt)
        val answerHash = hashPassword(trimmedAnswer, salt)
        val now = System.currentTimeMillis()

        val account = AccountInfo(
            name = trimmedName,
            username = trimmedUsername,
            passwordHash = passwordHash,
            salt = salt,
            securityQuestion = trimmedQuestion,
            securityAnswerHash = answerHash,
            createdAtMs = now
        )

        saveAccount(account, rememberMe)
        _authState.value = AuthState.Authenticated(account)
        return Result.success(account)
    }

    fun login(username: String, password: String, rememberMe: Boolean = true): Result<AccountInfo> {
        val trimmedUsername = username.trim().lowercase()
        val trimmedPassword = password.trim()

        val account = loadAccount()
            ?: return Result.failure(IllegalStateException("No account found. Please create an account first."))

        if (!account.username.equals(trimmedUsername, ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("Invalid username or password"))
        }

        val checkHash = hashPassword(trimmedPassword, account.salt)
        if (checkHash != account.passwordHash) {
            return Result.failure(IllegalArgumentException("Invalid username or password"))
        }

        prefs.edit()
            .putBoolean(KEY_REMEMBER_ME, rememberMe)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()

        _authState.value = AuthState.Authenticated(account)
        return Result.success(account)
    }

    fun verifySecurityAnswer(username: String, answer: String): Boolean {
        val account = loadAccount() ?: return false
        if (!account.username.equals(username.trim(), ignoreCase = true)) return false
        val hashed = hashPassword(answer.trim().lowercase(), account.salt)
        return hashed == account.securityAnswerHash
    }

    fun resetPassword(username: String, securityAnswer: String, newPassword: String): Result<Unit> {
        val account = loadAccount()
            ?: return Result.failure(IllegalStateException("No account found."))

        if (!account.username.equals(username.trim(), ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("Username does not match."))
        }

        if (newPassword.trim().length < 4) {
            return Result.failure(IllegalArgumentException("New password must be at least 4 characters."))
        }

        val answerHash = hashPassword(securityAnswer.trim().lowercase(), account.salt)
        if (answerHash != account.securityAnswerHash) {
            return Result.failure(IllegalArgumentException("Incorrect security answer."))
        }

        val newSalt = generateSalt()
        val newPasswordHash = hashPassword(newPassword.trim(), newSalt)
        val newAnswerHash = hashPassword(securityAnswer.trim().lowercase(), newSalt)

        val updated = account.copy(
            passwordHash = newPasswordHash,
            salt = newSalt,
            securityAnswerHash = newAnswerHash
        )
        saveAccount(updated, isRememberMeEnabled())
        return Result.success(Unit)
    }

    fun logout() {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .apply()
        _authState.value = AuthState.Unauthenticated
    }

    private fun saveAccount(account: AccountInfo, rememberMe: Boolean) {
        prefs.edit()
            .putString(KEY_NAME, account.name)
            .putString(KEY_USERNAME, account.username)
            .putString(KEY_PASSWORD_HASH, account.passwordHash)
            .putString(KEY_SALT, account.salt)
            .putString(KEY_SECURITY_QUESTION, account.securityQuestion)
            .putString(KEY_SECURITY_ANSWER_HASH, account.securityAnswerHash)
            .putLong(KEY_CREATED_AT, account.createdAtMs)
            .putBoolean(KEY_REMEMBER_ME, rememberMe)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()
    }

    private fun loadAccount(): AccountInfo? {
        val username = prefs.getString(KEY_USERNAME, null) ?: return null
        val passwordHash = prefs.getString(KEY_PASSWORD_HASH, null) ?: return null
        val salt = prefs.getString(KEY_SALT, null) ?: return null
        val name = prefs.getString(KEY_NAME, "Manager") ?: "Manager"
        val question = prefs.getString(KEY_SECURITY_QUESTION, "What is your primary store name?") ?: "What is your primary store name?"
        val answerHash = prefs.getString(KEY_SECURITY_ANSWER_HASH, "") ?: ""
        val createdAt = prefs.getLong(KEY_CREATED_AT, System.currentTimeMillis())

        return AccountInfo(
            name = name,
            username = username,
            passwordHash = passwordHash,
            salt = salt,
            securityQuestion = question,
            securityAnswerHash = answerHash,
            createdAtMs = createdAt
        )
    }

    private fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return Base64.getEncoder().encodeToString(saltBytes)
    }

    private fun hashPassword(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt.toByteArray(Charsets.UTF_8))
        val hashedBytes = digest.digest(password.toByteArray(Charsets.UTF_8))
        return hashedBytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_NAME = "auth_user_name"
        private const val KEY_USERNAME = "auth_username"
        private const val KEY_PASSWORD_HASH = "auth_password_hash"
        private const val KEY_SALT = "auth_salt"
        private const val KEY_SECURITY_QUESTION = "auth_security_question"
        private const val KEY_SECURITY_ANSWER_HASH = "auth_security_answer_hash"
        private const val KEY_CREATED_AT = "auth_created_at"
        private const val KEY_REMEMBER_ME = "auth_remember_me"
        private const val KEY_IS_LOGGED_IN = "auth_is_logged_in"

        @Volatile
        private var INSTANCE: AuthManager? = null

        fun getInstance(context: Context): AuthManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AuthManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
