package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.GeminiClient
import com.example.data.preferences.AppSettingsManager
import com.example.data.preferences.CustomThemeConfig
import com.example.data.preferences.ThemeMode
import com.example.ui.components.AiActionLogDialog
import com.example.ui.components.CustomThemeEditor
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.viewmodel.NutritionViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsBackupScreen(
    viewModel: NutritionViewModel,
    onNavigateToProfile: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settingsManager = remember { AppSettingsManager.getInstance(context) }
    val authManager = remember { com.example.data.auth.AuthManager.getInstance(context) }
    val accountInfo = remember { authManager.getAccount() }

    val currentThemeMode by settingsManager.themeMode.collectAsStateWithLifecycle()
    val customThemeConfig by settingsManager.customThemeConfig.collectAsStateWithLifecycle()
    val animationsEnabled by settingsManager.animationsEnabled.collectAsStateWithLifecycle()
    val userProfile by settingsManager.userProfile.collectAsStateWithLifecycle()

    val products by viewModel.products.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val movements by viewModel.movements.collectAsStateWithLifecycle()
    val aiLogs by viewModel.repository.allAiLogs.collectAsStateWithLifecycle(emptyList())

    var showExportDialog by remember { mutableStateOf(false) }
    var exportJsonString by remember { mutableStateOf("") }

    var showImportDialog by remember { mutableStateOf(false) }
    var importInputText by remember { mutableStateOf("") }
    var importStatusMessage by remember { mutableStateOf<String?>(null) }

    var showResetDialog by remember { mutableStateOf(false) }
    var showAiLogDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val hasGemini = GeminiClient.isConfigured()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("settings_backup_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Business Profile Quick Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            ),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToProfile() }
                .testTag("settings_profile_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = userProfile.businessName.take(2).uppercase().ifBlank { "ON" },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = userProfile.businessName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Owner: ${userProfile.ownerName} • View profile & points",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open Profile",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Section A: Visual & UI Settings
        Text(
            text = "Display & Appearance",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Theme Mode Selector
                Text(
                    text = "Theme Mode",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ThemeOptionButton(
                        modifier = Modifier.weight(1f),
                        title = "Light",
                        icon = Icons.Default.LightMode,
                        isSelected = currentThemeMode == ThemeMode.LIGHT,
                        onClick = { settingsManager.setThemeMode(ThemeMode.LIGHT) }
                    )
                    ThemeOptionButton(
                        modifier = Modifier.weight(1f),
                        title = "Dark",
                        icon = Icons.Default.DarkMode,
                        isSelected = currentThemeMode == ThemeMode.DARK,
                        onClick = { settingsManager.setThemeMode(ThemeMode.DARK) }
                    )
                    ThemeOptionButton(
                        modifier = Modifier.weight(1f),
                        title = "System",
                        icon = Icons.Default.SettingsBrightness,
                        isSelected = currentThemeMode == ThemeMode.SYSTEM,
                        onClick = { settingsManager.setThemeMode(ThemeMode.SYSTEM) }
                    )
                    ThemeOptionButton(
                        modifier = Modifier.weight(1f),
                        title = "Custom",
                        icon = Icons.Default.Palette,
                        isSelected = currentThemeMode == ThemeMode.CUSTOM,
                        onClick = { settingsManager.setThemeMode(ThemeMode.CUSTOM) }
                    )
                }

                if (currentThemeMode == ThemeMode.CUSTOM) {
                    CustomThemeEditor(
                        currentConfig = customThemeConfig,
                        onConfigChange = { settingsManager.updateCustomThemeConfig(it) },
                        onReset = { settingsManager.resetCustomTheme() }
                    )
                }

                HorizontalDivider()

                // Animations Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Animations",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (animationsEnabled) "Smooth transitions and UI motion active" else "Non-essential animations disabled for instant response",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = animationsEnabled,
                        onCheckedChange = { settingsManager.setAnimationsEnabled(it) },
                        modifier = Modifier.testTag("animations_toggle")
                    )
                }
            }
        }

        // Section B: AI Assistant & History Log
        Text(
            text = "AI Engine & Activity Log",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (hasGemini) "Gemini Multimodal Active" else "Offline Deterministic NLP Active",
                            fontWeight = FontWeight.Bold,
                            color = if (hasGemini) ForestGreenPrimary else PointsGold
                        )
                        Text(
                            text = if (hasGemini) "Gemini 3.5 Flash online OCR, voice & full control" else "100% offline rule-based parser & receipt review",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = if (hasGemini) Icons.Default.CloudDone else Icons.Default.Bolt,
                        contentDescription = null,
                        tint = if (hasGemini) ForestGreenPrimary else PointsGold
                    )
                }

                Button(
                    onClick = { showAiLogDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("view_ai_logs_btn")
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("View AI Activity / History Log (${aiLogs.size})")
                }
            }
        }

        // Section C: Local Storage Health & Statistics
        Text("Local Storage Health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Products in Catalog:", style = MaterialTheme.typography.bodyMedium)
                    Text("${products.size} items", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Purchases Recorded:", style = MaterialTheme.typography.bodyMedium)
                    Text("${purchases.size} entries", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Sales Completed:", style = MaterialTheme.typography.bodyMedium)
                    Text("${sales.size} orders", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Stock Ledger Records:", style = MaterialTheme.typography.bodyMedium)
                    Text("${movements.size} logs", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section D: Backup & Restore Actions
        Text("Data Backup & Portability", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        exportJsonString = viewModel.backupManager.generateBackupJson()
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Onest Nutrition Backup", exportJsonString))
                        Toast.makeText(context, "Backup copied to clipboard!", Toast.LENGTH_SHORT).show()
                        showExportDialog = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("export_backup_button")
            ) {
                Icon(Icons.Default.Upload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export Backup")
            }

            OutlinedButton(
                onClick = {
                    importInputText = ""
                    importStatusMessage = null
                    showImportDialog = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("import_backup_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Import Backup")
            }
        }

        // Section E: Account & Session
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Account Session",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (accountInfo != null) "Logged in as ${accountInfo.name} (${accountInfo.username})" else "Local Account Active",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedButton(
                    onClick = { showLogoutDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("settings_logout_btn")
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Log Out of Session")
                }
            }
        }

        // Section F: Reset Data
        OutlinedButton(
            onClick = { showResetDialog = true },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.DeleteForever, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Clear / Reset All Database Records")
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Logout Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
            },
            title = { Text("Log Out?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to log out? Your business records, purchases, and sales will remain safe on this device.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        authManager.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Log Out")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // AI Activity Log Dialog
    if (showAiLogDialog) {
        AiActionLogDialog(
            logs = aiLogs,
            onDismiss = { showAiLogDialog = false },
            onClearLogs = {
                coroutineScope.launch {
                    viewModel.repository.clearAiLogs()
                    Toast.makeText(context, "AI activity history cleared", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Backup Exported Successfully") },
            text = {
                Column {
                    Text("Your business data has been copied to your clipboard as JSON. You can also view or copy it below:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = exportJsonString,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        textStyle = MaterialTheme.typography.labelSmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showExportDialog = false }) { Text("Done") }
            }
        )
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("Import Database Backup") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paste your backup JSON below to restore products, purchases, sales, and stock movements:")
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("Paste JSON here...") },
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        textStyle = MaterialTheme.typography.labelSmall
                    )
                    if (importStatusMessage != null) {
                        Text(importStatusMessage!!, color = ForestGreenPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importInputText.isNotBlank()) {
                            coroutineScope.launch {
                                val res = viewModel.backupManager.restoreFromJson(importInputText)
                                if (res.isSuccess) {
                                    val payload = res.getOrNull()
                                    Toast.makeText(context, "Restored ${payload?.products?.size} products and ${payload?.sales?.size} sales!", Toast.LENGTH_LONG).show()
                                    showImportDialog = false
                                } else {
                                    importStatusMessage = "Error restoring: ${res.exceptionOrNull()?.message}"
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                ) {
                    Text("Restore Now")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showImportDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Reset Confirmation Dialog
    if (showResetDialog) {
        DeleteProtectionDialog(
            title = "Reset All Database Data?",
            whatWillBeDeleted = "All Products, Purchases, Sales, and Movements",
            dateText = "Current Timestamp",
            productText = "${products.size} Products",
            quantityText = "${sales.size} Sales, ${purchases.size} Purchases",
            amountText = "All Financial History",
            onConfirm = {
                coroutineScope.launch {
                    viewModel.backupManager.restoreFromJson("{\"products\":[],\"purchases\":[],\"sales\":[],\"stockMovements\":[]}")
                    showResetDialog = false
                    Toast.makeText(context, "Database cleared successfully", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { showResetDialog = false }
        )
    }
}

@Composable
private fun ThemeOptionButton(
    modifier: Modifier = Modifier,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.height(48.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
        }
    }
}
