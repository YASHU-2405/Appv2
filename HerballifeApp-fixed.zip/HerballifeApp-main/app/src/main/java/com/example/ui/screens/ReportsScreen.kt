package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DateRangeSelectorRow
import com.example.ui.components.StatCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import com.example.ui.viewmodel.DateRangeFilter
import com.example.ui.viewmodel.NutritionViewModel
import java.util.*

@Composable
fun ReportsScreen(
    viewModel: NutritionViewModel,
    modifier: Modifier = Modifier
) {
    val selectedRange by viewModel.selectedDateRange.collectAsStateWithLifecycle()
    val customStart by viewModel.customStartMs.collectAsStateWithLifecycle()
    val customEnd by viewModel.customEndMs.collectAsStateWithLifecycle()

    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()

    var showCustomDateDialog by remember { mutableStateOf(false) }

    if (showCustomDateDialog) {
        com.example.ui.components.CustomDateRangeDialog(
            initialStartMs = customStart,
            initialEndMs = customEnd,
            onDismiss = { showCustomDateDialog = false },
            onApplyRange = { start, end ->
                viewModel.setCustomDateRange(start, end)
                showCustomDateDialog = false
            }
        )
    }

    // Filter data according to selected date range
    val (pStart, pEnd) = viewModel.getRangeTimestamps(selectedRange, customStart, customEnd)
    val periodSales = remember(sales, pStart, pEnd) { sales.filter { it.saleDate in pStart..pEnd } }
    val periodPurchases = remember(purchases, pStart, pEnd) { purchases.filter { it.purchaseDate in pStart..pEnd } }

    val totalRevenue = periodSales.sumOf { it.totalSaleAmount }
    val totalCost = periodSales.sumOf { it.totalPurchaseCost }
    val totalProfit = periodSales.sumOf { it.profit }
    val totalPoints = periodPurchases.sumOf { it.totalPoints }
    val totalUnitsSold = periodSales.sumOf { it.quantity }
    val totalUnitsPurchased = periodPurchases.sumOf { it.quantity }
    val totalPurchasesCost = periodPurchases.sumOf { it.totalAmount }
    val profitMargin = if (totalRevenue > 0) (totalProfit / totalRevenue) * 100.0 else 0.0

    // Product-wise rankings for this period
    val productStats = remember(periodSales, periodPurchases, products) {
        products.map { prod ->
            val pSales = periodSales.filter { it.productId == prod.id }
            val pPurchases = periodPurchases.filter { it.productId == prod.id }
            val sold = pSales.sumOf { it.quantity }
            val rev = pSales.sumOf { it.totalSaleAmount }
            val prof = pSales.sumOf { it.profit }
            val pts = pPurchases.sumOf { it.totalPoints }
            Triple(prod, prof, pts) to Pair(sold, rev)
        }.filter { it.first.second > 0 || it.first.third > 0 || it.second.first > 0 }
    }

    val sortedByProfit = remember(productStats) { productStats.sortedByDescending { it.first.second } }
    val sortedByPoints = remember(productStats) { productStats.sortedByDescending { it.first.third } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("reports_screen"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Date Selector Row
        item {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Text(
                    text = "Report Period",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                DateRangeSelectorRow(
                    selectedRange = selectedRange,
                    onSelectRange = { viewModel.setDateRange(it) },
                    onCustomRangeClick = { showCustomDateDialog = true }
                )
            }
        }

        // Summary Title
        item {
            Text(
                text = "${selectedRange.label} Financial & Inventory Summary",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = ForestGreenPrimary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        // Summary Cards Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(
                        title = "Total Revenue",
                        value = "₹%.2f".format(totalRevenue),
                        subtitle = "$totalUnitsSold items sold",
                        icon = Icons.Default.Payments,
                        iconTint = ForestGreenPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Net Profit",
                        value = "₹%.2f".format(totalProfit),
                        subtitle = "Margin: %.1f%%".format(profitMargin),
                        icon = Icons.Default.TrendingUp,
                        iconTint = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(
                        title = "Volume Points",
                        value = "%.2f pts".format(totalPoints),
                        subtitle = "From stock purchases",
                        icon = Icons.Default.Stars,
                        iconTint = PointsGold,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Purchases / Stock In",
                        value = "₹%.2f".format(totalPurchasesCost),
                        subtitle = "$totalUnitsPurchased units purchased",
                        icon = Icons.Default.ShoppingBag,
                        iconTint = StockBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Product-wise Profit Rankings
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "🏆 Top Products by Profit (${selectedRange.label})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (sortedByProfit.isEmpty()) {
            item {
                Text(
                    text = "No sales in this period to rank products.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        } else {
            items(sortedByProfit.take(10)) { item ->
                val prod = item.first.first
                val profit = item.first.second
                val qtySold = item.second.first
                val rev = item.second.second

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, fontWeight = FontWeight.Bold)
                            Text("$qtySold units sold • Revenue: ₹%.2f".format(rev), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("₹%.2f".format(profit), fontWeight = FontWeight.Bold, color = ProfitGreen)
                            Text("profit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        }

        // Product-wise Points Rankings
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "⭐ Top Products by Volume Points (${selectedRange.label})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (sortedByPoints.isEmpty()) {
            item {
                Text(
                    text = "No points accumulated in this period.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        } else {
            items(sortedByPoints.take(10)) { item ->
                val prod = item.first.first
                val points = item.first.third
                val qtySold = item.second.first

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, fontWeight = FontWeight.Bold)
                            Text("$qtySold units sold", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("%.2f pts".format(points), fontWeight = FontWeight.Bold, color = PointsGold)
                            Text("volume points", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        }
    }
}
