package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Purchase
import com.example.data.model.PurchaseOrder
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ReceiptImageViewerDialog
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchasesScreen(
    viewModel: NutritionViewModel,
    onOpenAddPurchase: () -> Unit,
    modifier: Modifier = Modifier
) {
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val purchaseOrders by viewModel.purchaseOrders.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: All Items, 1: Orders, 2: Discount History
    var searchQuery by remember { mutableStateOf("") }
    var purchaseToDelete by remember { mutableStateOf<Purchase?>(null) }
    var orderToDelete by remember { mutableStateOf<PurchaseOrder?>(null) }
    var selectedPurchaseForDetail by remember { mutableStateOf<Purchase?>(null) }
    var selectedPurchaseOrderForDetail by remember { mutableStateOf<PurchaseOrder?>(null) }
    var receiptImageToView by remember { mutableStateOf<String?>(null) }

    val filteredPurchases = remember(purchases, searchQuery) {
        if (searchQuery.isBlank()) purchases
        else {
            val q = searchQuery.trim().lowercase()
            purchases.filter {
                it.productName.lowercase().contains(q) ||
                it.invoiceNumber.lowercase().contains(q) ||
                it.supplierName.lowercase().contains(q)
            }
        }
    }

    val filteredOrders = remember(purchaseOrders, searchQuery) {
        if (searchQuery.isBlank()) purchaseOrders
        else {
            val q = searchQuery.trim().lowercase()
            purchaseOrders.filter {
                it.orderNumber.lowercase().contains(q) ||
                it.invoiceNumber.lowercase().contains(q) ||
                it.supplierName.lowercase().contains(q)
            }
        }
    }

    val discountedPurchases = remember(purchases, searchQuery) {
        val list = purchases.filter { it.discountAmount > 0.001 || it.discountPercentage > 0.001 }
        if (searchQuery.isBlank()) list
        else {
            val q = searchQuery.trim().lowercase()
            list.filter {
                it.productName.lowercase().contains(q) ||
                it.invoiceNumber.lowercase().contains(q) ||
                it.supplierName.lowercase().contains(q)
            }
        }
    }

    val totalSpent = remember(purchases) { purchases.sumOf { it.totalAmount } }
    val totalUnits = remember(purchases) { purchases.sumOf { it.quantity } }
    val totalPoints = remember(purchases) { purchases.sumOf { it.totalPoints } }
    val totalDiscountsSaved = remember(purchases) {
        purchases.sumOf { it.discountAmount * it.quantity }
    }

    Scaffold(
        modifier = modifier.testTag("purchases_screen"),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAddPurchase,
                icon = { Icon(Icons.Default.AddShoppingCart, contentDescription = "Add Purchase") },
                text = { Text("Stock In") },
                containerColor = StockBlue,
                contentColor = Color.White,
                modifier = Modifier
                    .padding(bottom = 60.dp)
                    .testTag("fab_add_purchase")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header summary banner
            Surface(
                color = StockBlue.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Stock In", style = MaterialTheme.typography.labelSmall, color = StockBlue)
                        Text("₹%.2f".format(totalSpent), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Discounts Saved", style = MaterialTheme.typography.labelSmall, color = ProfitGreen)
                        Text("₹%.2f".format(totalDiscountsSaved), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ProfitGreen)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Units Added", style = MaterialTheme.typography.labelSmall, color = StockBlue)
                        Text("$totalUnits units", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Tab Row: All Items | Purchase Orders | Discount History
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = StockBlue
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("All Items (${purchases.size})", style = MaterialTheme.typography.labelMedium) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Orders (${purchaseOrders.size})", style = MaterialTheme.typography.labelMedium) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Discount History", style = MaterialTheme.typography.labelMedium) }
                )
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        when (selectedTab) {
                            1 -> "Search orders by order#, invoice, supplier..."
                            2 -> "Search discount records..."
                            else -> "Search by product, invoice, supplier..."
                        }
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Body based on active tab
            when (selectedTab) {
                0 -> {
                    // TAB 0: ALL ITEM PURCHASES
                    if (filteredPurchases.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.AddShoppingCart,
                            title = if (searchQuery.isBlank()) "No Purchases Recorded" else "No Matching Purchases",
                            description = if (searchQuery.isBlank())
                                "Record when you stock in inventory to automatically compute purchase cost, discounts, and tax."
                            else "No purchases match '$searchQuery'. Try checking spelling.",
                            actionText = if (searchQuery.isBlank()) "Add First Stock In" else null,
                            onActionClick = if (searchQuery.isBlank()) onOpenAddPurchase else null
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredPurchases, key = { it.id }) { purchase ->
                                PurchaseItemCard(
                                    purchase = purchase,
                                    onClick = { selectedPurchaseForDetail = purchase },
                                    onDelete = { purchaseToDelete = purchase },
                                    onViewReceipt = { uri -> receiptImageToView = uri }
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // TAB 1: PURCHASE ORDER HISTORY
                    if (filteredOrders.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.ReceiptLong,
                            title = if (searchQuery.isBlank()) "No Purchase Orders" else "No Matching Orders",
                            description = if (searchQuery.isBlank())
                                "Grouped purchase orders with supplier details, invoice tracking, and multiple items will appear here."
                            else "No orders match '$searchQuery'.",
                            actionText = if (searchQuery.isBlank()) "Create Stock In" else null,
                            onActionClick = if (searchQuery.isBlank()) onOpenAddPurchase else null
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredOrders, key = { it.id }) { order ->
                                PurchaseOrderCard(
                                    order = order,
                                    onClick = { selectedPurchaseOrderForDetail = order },
                                    onDelete = { orderToDelete = order },
                                    onViewReceipt = { uri -> receiptImageToView = uri }
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 2: PURCHASE DISCOUNT HISTORY
                    if (discountedPurchases.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.LocalOffer,
                            title = if (searchQuery.isBlank()) "No Discounted Purchases" else "No Matching Discounts",
                            description = "Every time a supplier discount (% or ₹) is applied to stock-in records, the exact historical discount amount and net cost are recorded immutably here."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Surface(
                                    color = ProfitGreen.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.Verified, contentDescription = null, tint = ProfitGreen)
                                        Column {
                                            Text("Immutable Historical Record", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                                            Text(
                                                "Discounts received remain fixed to original purchase prices and are preserved even if product base prices change in the future.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }

                            items(discountedPurchases, key = { "disc_${it.id}" }) { purchase ->
                                PurchaseDiscountCard(
                                    purchase = purchase,
                                    onClick = { selectedPurchaseForDetail = purchase }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Purchase Detail Dialog
    selectedPurchaseForDetail?.let { purchase ->
        PurchaseDetailDialog(
            purchase = purchase,
            onDismiss = { selectedPurchaseForDetail = null },
            onViewReceipt = { uri -> receiptImageToView = uri }
        )
    }

    // Purchase Order Detail Dialog
    selectedPurchaseOrderForDetail?.let { order ->
        val orderItems = remember(purchases, order.id) {
            purchases.filter { it.orderId == order.id }
        }
        PurchaseOrderDetailDialog(
            order = order,
            items = orderItems,
            onDismiss = { selectedPurchaseOrderForDetail = null },
            onViewReceipt = { uri -> receiptImageToView = uri }
        )
    }

    // Delete Item Purchase Confirmation Dialog
    purchaseToDelete?.let { p ->
        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(p.purchaseDate))
        DeleteProtectionDialog(
            title = "Delete Purchase Record?",
            whatWillBeDeleted = "Purchase Entry (Stock will be reversed)",
            dateText = dateStr,
            productText = p.productName,
            quantityText = "${p.quantity} units",
            amountText = "₹%.2f".format(p.totalAmount),
            onConfirm = {
                viewModel.deletePurchase(p)
                purchaseToDelete = null
            },
            onDismiss = { purchaseToDelete = null }
        )
    }

    // Delete Purchase Order Confirmation Dialog
    orderToDelete?.let { o ->
        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(o.purchaseDate))
        DeleteProtectionDialog(
            title = "Delete Purchase Order?",
            whatWillBeDeleted = "Order #${o.orderNumber} and all ${o.totalProducts} item entries (Stock reversed)",
            dateText = dateStr,
            productText = "Supplier: ${o.supplierName.ifBlank { "Direct" }}",
            quantityText = "${o.totalQuantity} total units",
            amountText = "₹%.2f".format(o.finalPurchaseAmount),
            onConfirm = {
                viewModel.deletePurchaseOrder(o.id)
                orderToDelete = null
            },
            onDismiss = { orderToDelete = null }
        )
    }

    // Receipt Image Viewer
    receiptImageToView?.let { uri ->
        ReceiptImageViewerDialog(
            imageUri = uri,
            title = "Purchase Bill / Receipt",
            onDismiss = { receiptImageToView = null }
        )
    }
}

@Composable
fun PurchaseItemCard(
    purchase: Purchase,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(purchase.purchaseDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("purchase_card_${purchase.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = purchase.productName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        if (purchase.invoiceNumber.isNotBlank()) {
                            Surface(color = StockBlue.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = "Inv: ${purchase.invoiceNumber}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StockBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "₹%.2f".format(purchase.totalAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = StockBlue
                )
            }

            // Supplier Name banner if available
            if (purchase.supplierName.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = null, tint = StockBlue, modifier = Modifier.size(14.dp))
                        Text(
                            text = "Supplier: ${purchase.supplierName}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Discount Badge if discount was received
            if (purchase.discountAmount > 0.001 || purchase.discountPercentage > 0.001) {
                Surface(
                    color = ProfitGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.LocalOffer, contentDescription = null, tint = ProfitGreen, modifier = Modifier.size(14.dp))
                        Text(
                            text = "Discount Saved: -₹%.2f/unit (%.1f%% OFF)".format(purchase.discountAmount, purchase.discountPercentage),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ProfitGreen
                        )
                    }
                }
            }

            // Payment Settlement Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = when (purchase.paymentStatus) {
                            "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                            "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                            else -> Color(0xFFC62828).copy(alpha = 0.15f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = purchase.paymentStatus,
                            color = when (purchase.paymentStatus) {
                                "PAID" -> Color(0xFF2E7D32)
                                "PARTIAL" -> Color(0xFFF57F17)
                                else -> Color(0xFFC62828)
                            },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "Paid: ₹%.2f".format(purchase.amountPaid),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (purchase.amountPending > 0.01) {
                    Text(
                        text = "Pending: ₹%.2f".format(purchase.amountPending),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC62828)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Quantity", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("${purchase.quantity} units", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Final Unit Cost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.2f".format(purchase.finalPricePerUnit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text("Points", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("%.2f pts".format(purchase.totalPoints), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = PointsGold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (!purchase.receiptImageUri.isNullOrBlank()) {
                        IconButton(
                            onClick = { onViewReceipt(purchase.receiptImageUri) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = "View Bill", tint = StockBlue, modifier = Modifier.size(18.dp))
                        }
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PurchaseOrderCard(
    order: PurchaseOrder,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(order.purchaseDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("purchase_order_card_${order.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = StockBlue, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = "#${order.orderNumber}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (order.invoiceNumber.isNotBlank()) {
                        Text(
                            text = "Inv: ${order.invoiceNumber}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Text(
                    text = "₹%.2f".format(order.finalPurchaseAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = StockBlue
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                    Text(
                        text = order.supplierName.ifBlank { "Direct Vendor" },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(text = dateStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${order.totalProducts} products • ${order.totalQuantity} units",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (order.totalDiscountAmount > 0.001) {
                        Text(
                            text = "Saved: ₹%.2f".format(order.totalDiscountAmount),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ProfitGreen
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Points: %.2f".format(order.totalPoints), style = MaterialTheme.typography.labelSmall, color = PointsGold, fontWeight = FontWeight.Bold)
                    if (order.totalGstAmount > 0) {
                        Text("GST: ₹%.2f".format(order.totalGstAmount), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!order.receiptImageUri.isNullOrBlank()) {
                        IconButton(onClick = { onViewReceipt(order.receiptImageUri) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Receipt, contentDescription = "View Bill", tint = StockBlue, modifier = Modifier.size(16.dp))
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Order", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PurchaseDiscountCard(
    purchase: Purchase,
    onClick: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(purchase.purchaseDate))
    val totalSaved = purchase.discountAmount * purchase.quantity

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(purchase.productName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("$dateStr ${if (purchase.supplierName.isNotBlank()) "• ${purchase.supplierName}" else ""}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
                Surface(color = ProfitGreen, shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = "Total Saved: ₹%.2f".format(totalSaved),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Base Cost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.2f".format(purchase.originalPrice), style = MaterialTheme.typography.bodySmall)
                }
                Column {
                    Text("Discount Given", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("%.1f%% (-₹%.2f)".format(purchase.discountPercentage, purchase.discountAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                }
                Column {
                    Text("Net Unit Cost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("₹%.2f".format(purchase.finalPricePerUnit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = StockBlue)
                }
                Column {
                    Text("Batch Qty", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text("${purchase.quantity} units", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun PurchaseDetailDialog(
    purchase: Purchase,
    onDismiss: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date(purchase.purchaseDate))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Purchase Details",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (purchase.invoiceNumber.isNotBlank()) {
                    Surface(
                        color = StockBlue.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = purchase.invoiceNumber,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StockBlue,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = purchase.productName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Date: $dateStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                if (purchase.supplierName.isNotBlank()) {
                    Text(
                        text = "Supplier: ${purchase.supplierName}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                HorizontalDivider()

                // Historical Discount Details (Immutable)
                Surface(
                    color = ProfitGreen.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Historical Discount Details (Immutable)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ProfitGreen
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount Type:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                if (purchase.discountType == "FIXED_AMOUNT") "Fixed Amount (₹)" else "Percentage (%)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount Value:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "%.1f%% (-₹%.2f/unit)".format(purchase.discountPercentage, purchase.discountAmount),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = ProfitGreen
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Batch Discount Saved:", style = MaterialTheme.typography.bodySmall)
                            Text("₹%.2f".format(purchase.discountAmount * purchase.quantity), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                        }
                    }
                }

                // Historical GST & Tax Details
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Historical GST State (Protected)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StockBlue
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("GST Type:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                if (purchase.gstType == "FIXED_AMOUNT") "Fixed Amount (₹)" else "Percentage (%)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("GST Value:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                if (purchase.gstType == "FIXED_AMOUNT") "₹%.2f".format(purchase.gstFixedAmount) else "%.1f%%".format(purchase.taxPercentage),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Calculated Tax Amount:", style = MaterialTheme.typography.bodySmall)
                            Text("₹%.2f per unit".format(purchase.taxAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Cost & Quantities
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Quantity Purchased:", style = MaterialTheme.typography.bodySmall)
                    Text("${purchase.quantity} units", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Base Purchase Price:", style = MaterialTheme.typography.bodySmall)
                    Text("₹%.2f".format(purchase.originalPrice), style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Final Cost per Unit:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Text("₹%.2f".format(purchase.finalPricePerUnit), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Purchase Amount:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("₹%.2f".format(purchase.totalAmount), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = StockBlue)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Volume Points Earned:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("%.2f pts".format(purchase.totalPoints), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = PointsGold)
                }

                if (!purchase.receiptImageUri.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { onViewReceipt(purchase.receiptImageUri) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("View Attached Bill / Invoice")
                    }
                }

                if (purchase.notes.isNotBlank()) {
                    Text(
                        text = "Notes: ${purchase.notes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun PurchaseOrderDetailDialog(
    order: PurchaseOrder,
    items: List<Purchase>,
    onDismiss: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date(order.purchaseDate))

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Order #${order.orderNumber}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        if (order.invoiceNumber.isNotBlank()) {
                            Text("Invoice: ${order.invoiceNumber}", style = MaterialTheme.typography.bodySmall, color = StockBlue, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Supplier / Vendor:", style = MaterialTheme.typography.bodySmall)
                            Text(order.supplierName.ifBlank { "Direct Vendor" }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Purchase Date:", style = MaterialTheme.typography.bodySmall)
                            Text(dateStr, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Discount Saved:", style = MaterialTheme.typography.bodySmall)
                            Text("₹%.2f".format(order.totalDiscountAmount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Invoice Amount:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("₹%.2f".format(order.finalPurchaseAmount), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = StockBlue)
                        }
                    }
                }

                if (!order.receiptImageUri.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { onViewReceipt(order.receiptImageUri) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("View Attached Bill Image")
                    }
                }

                Text("Products in Order (${items.size}):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { it.id }) { item ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(item.productName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    Text("₹%.2f".format(item.totalAmount), fontWeight = FontWeight.Bold, color = StockBlue)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${item.quantity} units @ ₹%.2f".format(item.finalPricePerUnit), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    if (item.discountAmount > 0) {
                                        Text("Saved: ₹%.2f".format(item.discountAmount * item.quantity), style = MaterialTheme.typography.labelSmall, color = ProfitGreen, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = StockBlue)) {
                        Text("Close")
                    }
                }
            }
        }
    }
}
