package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "purchase_orders")
data class PurchaseOrder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNumber: String,
    val invoiceNumber: String = "",
    val supplierName: String = "",
    val purchaseDate: Long = System.currentTimeMillis(),
    val totalProducts: Int = 0,
    val totalQuantity: Int = 0,
    val totalOriginalAmount: Double = 0.0,
    val totalDiscountAmount: Double = 0.0,
    val totalGstAmount: Double = 0.0,
    val finalPurchaseAmount: Double = 0.0,
    val totalPoints: Double = 0.0,
    val notes: String = "",
    val receiptImageUri: String? = null
)
