package com.example.data.dao

import androidx.room.*
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.BillWithItems
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Transaction
    @Query("SELECT * FROM bills ORDER BY billDate DESC")
    fun getAllBillsWithItems(): Flow<List<BillWithItems>>

    @Transaction
    @Query("SELECT * FROM bills ORDER BY billDate DESC")
    suspend fun getAllBillsWithItemsList(): List<BillWithItems>

    @Transaction
    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getBillWithItemsById(id: Long): BillWithItems?

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: Long): Bill?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: Bill): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBillItems(items: List<BillItem>): List<Long>

    @Update
    suspend fun updateBill(bill: Bill)

    @Delete
    suspend fun deleteBill(bill: Bill)

    @Query("DELETE FROM bill_items WHERE billId = :billId")
    suspend fun deleteBillItemsForBill(billId: Long)

    @Query("DELETE FROM bills")
    suspend fun deleteAll()
}
