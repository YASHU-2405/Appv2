package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sale_payments")
data class SalePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val customerName: String? = null,
    val customerContact: String? = null,
    val amount: Double = 0.0,
    val paymentDate: Long = System.currentTimeMillis(),
    val paymentMethod: String = "Cash", // "Cash", "UPI", "Bank Transfer", "Other"
    val notes: String = "",
    val receiptImageUri: String? = null
)
