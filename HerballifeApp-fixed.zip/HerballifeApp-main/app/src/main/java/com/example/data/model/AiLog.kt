package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ai_logs")
data class AiLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val userCommand: String,
    val detectedAction: String,
    val status: String, // "Confirmed", "Cancelled", "Executed", "Read-only", "Rejected"
    val resultSummary: String
)
