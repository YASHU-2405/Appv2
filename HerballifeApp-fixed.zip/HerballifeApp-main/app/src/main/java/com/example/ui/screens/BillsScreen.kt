package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BillWithItems
import com.example.ui.components.DeleteProtectionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ReceiptImageViewerDialog
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.StockBlue
import com.example.ui.viewmodel.NutritionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillsScreen(
    viewModel: NutritionViewModel,
    onOpenAddBill: () -> Unit,
    modifier: Modifier = Modifier
) {
    val billsWithItems by viewModel.bills.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var paymentFilter by remember { mutableStateOf("ALL") } // ALL, PAID, PARTIAL, PENDING
    var selectedBillForDetail by remember { mutableStateOf<BillWithItems?>(null) }
    var billToEdit by remember { mutableStateOf<BillWithItems?>(null) }
    var billToDelete by remember { mutableStateOf<BillWithItems?>(null) }
    var receiptImageToView by remember { mutableStateOf<String?>(null) }

    val filteredBills = remember(billsWithItems, searchQuery, paymentFilter) {
        billsWithItems.filter { item ->
            val matchesQuery = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                item.bill.billNumber.lowercase().contains(q) ||
                item.bill.supplierName.lowercase().contains(q) ||
                item.items.any { it.productName.lowercase().contains(q) }
            }
            val matchesFilter = when (paymentFilter) {
                "PAID" -> item.bill.paymentStatus == "PAID"
                "PARTIAL" -> item.bill.paymentStatus == "PARTIAL"
                "PENDING" -> item.bill.paymentStatus == "PENDING"
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    val totalBilled = billsWithItems.sumOf { it.bill.finalAmount }
    val totalPaid = billsWithItems.sumOf { it.bill.amountPaid }
    val totalPending = billsWithItems.sumOf { it.bill.amountPending }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAddBill,
                icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null) },
                text = { Text("New Bill / Scan") },
                containerColor = ForestGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_bill_fab")
            )
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by Bill No., Supplier, or Product") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("bill_search_input")
            )

            // Payment Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL" to "All", "PAID" to "Paid", "PARTIAL" to "Partial", "PENDING" to "Pending").forEach { (key, label) ->
                    val isSelected = paymentFilter == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { paymentFilter = key },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier.testTag("filter_bill_$key")
                    )
                }
            }

            // Summary Metrics Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Billed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Text("₹%.2f".format(totalBilled), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                    Column {
                        Text("Paid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Text("₹%.2f".format(totalPaid), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF2E7D32))
                    }
                    Column {
                        Text("Pending", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Text("₹%.2f".format(totalPending), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFC62828))
                    }
                }
            }

            // Bills List
            if (filteredBills.isEmpty()) {
                EmptyStateCard(
                    title = "No Bills Recorded",
                    description = "Capture or upload invoices from suppliers. Keep official records without altering inventory, or stock them when ready.",
                    icon = Icons.Default.Receipt
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredBills, key = { it.bill.id }) { item ->
                        BillCard(
                            billWithItems = item,
                            onClick = { selectedBillForDetail = item },
                            onDelete = { billToDelete = item },
                            onViewReceipt = { path -> receiptImageToView = path }
                        )
                    }
                }
            }
        }
    }

    // Bill Detail Dialog
    selectedBillForDetail?.let { detail ->
        BillDetailDialog(
            billWithItems = detail,
            onDismiss = { selectedBillForDetail = null },
            onViewReceipt = { path -> receiptImageToView = path }
        )
    }

    // Receipt Full Image Viewer
    receiptImageToView?.let { path ->
        ReceiptImageViewerDialog(
            imageUri = path,
            title = "Bill / Invoice Document",
            onDismiss = { receiptImageToView = null }
        )
    }

    // Delete Protection Dialog
    billToDelete?.let { toDelete ->
        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(toDelete.bill.billDate))
        DeleteProtectionDialog(
            title = "Delete Bill Document?",
            whatWillBeDeleted = "Bill #${toDelete.bill.billNumber} (${toDelete.items.size} line items)",
            dateText = dateStr,
            productText = toDelete.bill.supplierName,
            quantityText = "${toDelete.items.sumOf { it.quantity }} items",
            amountText = "₹%.2f".format(toDelete.bill.finalAmount),
            onConfirm = {
                viewModel.deleteBill(toDelete.bill)
                billToDelete = null
            },
            onDismiss = { billToDelete = null }
        )
    }
}

@Composable
fun BillCard(
    billWithItems: BillWithItems,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val bill = billWithItems.bill
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(bill.billDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("bill_card_${bill.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Bill Number & Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(color = ForestGreenPrimary, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = "#${bill.billNumber}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    if (bill.linkedPurchaseOrderId != null) {
                        Surface(color = StockBlue.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "Stock Linked",
                                color = StockBlue,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "₹%.2f".format(bill.finalAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary
                )
            }

            // Supplier & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (bill.supplierName.isNotBlank()) "Supplier: ${bill.supplierName}" else "Supplier: Not specified",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            // Products summary
            Text(
                text = "${billWithItems.items.size} item(s): " + billWithItems.items.joinToString(", ") { "${it.quantity}x ${it.productName}" }.take(60) + if (billWithItems.items.joinToString { it.productName }.length > 60) "..." else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Footer: Payment status & Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = when (bill.paymentStatus) {
                            "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                            "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                            else -> Color(0xFFC62828).copy(alpha = 0.15f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = bill.paymentStatus,
                            color = when (bill.paymentStatus) {
                                "PAID" -> Color(0xFF2E7D32)
                                "PARTIAL" -> Color(0xFFF57F17)
                                else -> Color(0xFFC62828)
                            },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (bill.amountPending > 0.01) {
                        Text(
                            text = "Bal: ₹%.2f".format(bill.amountPending),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC62828),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (!bill.billImageUri.isNullOrBlank()) {
                        IconButton(
                            onClick = { onViewReceipt(bill.billImageUri) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = "View Bill Image", tint = StockBlue, modifier = Modifier.size(18.dp))
                        }
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Bill", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun BillDetailDialog(
    billWithItems: BillWithItems,
    onDismiss: () -> Unit,
    onViewReceipt: (String) -> Unit
) {
    val bill = billWithItems.bill
    val dateStr = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date(bill.billDate))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Bill #${bill.billNumber}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = when (bill.paymentStatus) {
                        "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                        "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                        else -> Color(0xFFC62828).copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = bill.paymentStatus,
                        color = when (bill.paymentStatus) {
                            "PAID" -> Color(0xFF2E7D32)
                            "PARTIAL" -> Color(0xFFF57F17)
                            else -> Color(0xFFC62828)
                        },
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Supplier: ${if (bill.supplierName.isNotBlank()) bill.supplierName else "N/A"}", fontWeight = FontWeight.SemiBold)
                Text("Date: $dateStr", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                if (bill.linkedPurchaseOrderId != null) {
                    Surface(color = StockBlue.copy(alpha = 0.12f), shape = RoundedCornerShape(6.dp)) {
                        Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StockBlue, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inventory Stock Added from this Bill", style = MaterialTheme.typography.bodySmall, color = StockBlue, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(6.dp)) {
                        Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Document Record Only (Inventory unchanged)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }

                HorizontalDivider()

                Text("Line Items (${billWithItems.items.size})", fontWeight = FontWeight.Bold)

                billWithItems.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.productName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${item.quantity} units @ ₹%.2f (Disc: %.0f%%, GST: %.0f%%)".format(item.originalPrice, item.discountPercentage, item.taxPercentage),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                        Text("₹%.2f".format(item.totalAmount), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Original:", style = MaterialTheme.typography.bodySmall)
                    Text("₹%.2f".format(bill.totalOriginalAmount), style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Discount:", style = MaterialTheme.typography.bodySmall, color = ProfitGreen)
                    Text("-₹%.2f".format(bill.totalDiscountAmount), style = MaterialTheme.typography.bodySmall, color = ProfitGreen, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total GST:", style = MaterialTheme.typography.bodySmall)
                    Text("+₹%.2f".format(bill.totalGstAmount), style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Final Bill Total:", fontWeight = FontWeight.Bold)
                    Text("₹%.2f".format(bill.finalAmount), fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Paid: ₹%.2f".format(bill.amountPaid), style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                    Text("Balance: ₹%.2f".format(bill.amountPending), style = MaterialTheme.typography.bodySmall, color = if (bill.amountPending > 0.01) Color(0xFFC62828) else Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                }

                if (bill.notes.isNotBlank()) {
                    Text("Notes: ${bill.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                }

                if (!bill.billImageUri.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { onViewReceipt(bill.billImageUri) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Attached Bill Photo")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
