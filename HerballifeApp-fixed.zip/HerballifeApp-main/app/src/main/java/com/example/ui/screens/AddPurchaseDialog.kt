package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.ui.components.DiscountTypeSelector
import com.example.ui.components.GstTypeSelector
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PointsGold
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPurchaseDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (Purchase) -> Unit,
    onAddNewProductRequested: () -> Unit
) {
    val context = LocalContext.current
    val appSettings = remember { com.example.data.preferences.AppSettingsManager.getInstance(context) }
    val userProfile by appSettings.userProfile.collectAsState()
    val defaultProfileDiscount = userProfile.defaultPurchaseDiscount

    var selectedProductId by remember { mutableStateOf<Long?>(products.firstOrNull()?.id) }
    var expandedProductDropdown by remember { mutableStateOf(false) }

    val selectedProduct = products.find { it.id == selectedProductId }

    var quantityStr by remember { mutableStateOf("1") }
    var mrpStr by remember { mutableStateOf(selectedProduct?.mrp?.toString() ?: "1000") }
    var originalPriceStr by remember {
        mutableStateOf(selectedProduct?.purchasePrice?.takeIf { it > 0 }?.toString() ?: selectedProduct?.mrp?.toString() ?: "1000")
    }
    var discountType by remember { mutableStateOf("PERCENTAGE") }
    var discountPercentStr by remember {
        val initialDisc = selectedProduct?.discountPercentage?.takeIf { it > 0 } ?: defaultProfileDiscount
        mutableStateOf(if (initialDisc % 1.0 == 0.0) "%.0f".format(initialDisc) else "%.2f".format(initialDisc))
    }
    var discountFixedAmountStr by remember { mutableStateOf("0") }
    var gstType by remember {
        mutableStateOf(selectedProduct?.gstType ?: "PERCENTAGE")
    }
    var taxPercentStr by remember {
        mutableStateOf(selectedProduct?.taxPercentage?.toString() ?: "18")
    }
    var gstFixedAmountStr by remember {
        mutableStateOf(selectedProduct?.gstFixedAmount?.takeIf { it > 0 }?.toString() ?: "0")
    }
    var invoiceNumber by remember { mutableStateOf("") }
    var supplierName by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var purchaseDateMs by remember { mutableStateOf(System.currentTimeMillis()) }

    var amountPaidStr by remember { mutableStateOf("") }
    var userModifiedPaid by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // When product changes, update defaults
    LaunchedEffect(selectedProductId) {
        selectedProduct?.let { p ->
            mrpStr = p.mrp.toString()
            originalPriceStr = if (p.purchasePrice > 0) p.purchasePrice.toString() else p.mrp.toString()
            val discVal = if (p.discountPercentage > 0) p.discountPercentage else defaultProfileDiscount
            discountPercentStr = if (discVal % 1.0 == 0.0) "%.0f".format(discVal) else "%.2f".format(discVal)
            gstType = p.gstType
            taxPercentStr = p.taxPercentage.toString()
            gstFixedAmountStr = p.gstFixedAmount.takeIf { it > 0 }?.toString() ?: "0"
        }
    }

    val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(purchaseDateMs))

    // Mathematical calculations:
    // Original Amount per unit
    val origPrice = (originalPriceStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val qty = (quantityStr.toIntOrNull() ?: 1).coerceAtLeast(1)
    val discPercent = (discountPercentStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
    val discFixedAmt = (discountFixedAmountStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val taxPercent = (taxPercentStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val gstFixedAmt = (gstFixedAmountStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val mrp = (mrpStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    // Unit discount & tax
    val discAmtPerUnit = if (discountType == "FIXED_AMOUNT") {
        discFixedAmt.coerceAtMost(origPrice)
    } else {
        origPrice * (discPercent / 100.0)
    }
    val afterDiscAmtPerUnit = (origPrice - discAmtPerUnit).coerceAtLeast(0.0)
    val taxAmtPerUnit = if (gstType == "FIXED_AMOUNT") {
        gstFixedAmt
    } else {
        afterDiscAmtPerUnit * (taxPercent / 100.0)
    }
    val finalPricePerUnit = afterDiscAmtPerUnit + taxAmtPerUnit
    val totalAmount = finalPricePerUnit * qty
    val pointsPerUnit = selectedProduct?.points ?: 0.0
    val totalPoints = pointsPerUnit * qty

    val paidAmount = if (userModifiedPaid) (amountPaidStr.toDoubleOrNull() ?: 0.0) else totalAmount
    val pendingAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)
    val paymentStatus = if (paidAmount >= totalAmount - 0.01) "PAID" else if (paidAmount <= 0.01) "PENDING" else "PARTIAL"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Stock In / Purchase Entry", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForestGreenPrimary,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    val prod = selectedProduct ?: run {
                                        errorMessage = "Please select or create a product"
                                        return@Button
                                    }
                                    if (qty <= 0) {
                                        errorMessage = "Quantity must be at least 1"
                                        return@Button
                                    }

                                    val purchase = Purchase(
                                        productId = prod.id,
                                        productName = prod.name,
                                        quantity = qty,
                                        mrp = mrp,
                                        originalPrice = origPrice,
                                        discountType = discountType,
                                        discountPercentage = if (discountType == "PERCENTAGE") discPercent else 0.0,
                                        discountFixedAmount = if (discountType == "FIXED_AMOUNT") discFixedAmt else 0.0,
                                        discountAmount = discAmtPerUnit * qty,
                                        gstType = gstType,
                                        taxPercentage = if (gstType == "PERCENTAGE") taxPercent else 0.0,
                                        gstFixedAmount = if (gstType == "FIXED_AMOUNT") gstFixedAmt else 0.0,
                                        taxAmount = taxAmtPerUnit * qty,
                                        finalPricePerUnit = finalPricePerUnit,
                                        totalAmount = totalAmount,
                                        purchaseDate = purchaseDateMs,
                                        invoiceNumber = invoiceNumber.trim(),
                                        supplierName = supplierName.trim(),
                                        receiptImageUri = null,
                                        notes = notes.trim(),
                                        pointsPerUnit = pointsPerUnit,
                                        totalPoints = totalPoints,
                                        paymentStatus = paymentStatus,
                                        amountPaid = paidAmount,
                                        amountPending = pendingAmount
                                    )
                                    onSave(purchase)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                modifier = Modifier.testTag("save_purchase_button")
                            ) {
                                Text("Confirm Purchase")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(modifier = Modifier.height(4.dp))

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // Product Selector
                    Text("Select Product", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    if (products.isEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                                Text("No products exist in your catalog yet.")
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(onClick = onAddNewProductRequested) {
                                    Text("Create Product First")
                                }
                            }
                        }
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = expandedProductDropdown,
                            onExpandedChange = { expandedProductDropdown = !expandedProductDropdown }
                        ) {
                            OutlinedTextField(
                                value = selectedProduct?.name ?: "Select a product",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProductDropdown) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("purchase_product_dropdown")
                            )
                            ExposedDropdownMenu(
                                expanded = expandedProductDropdown,
                                onDismissRequest = { expandedProductDropdown = false }
                            ) {
                                products.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text("${p.name} (Stock: ${p.currentStock})") },
                                        onClick = {
                                            selectedProductId = p.id
                                            expandedProductDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Quantity & Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text("Quantity *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("purchase_quantity_input")
                        )

                        OutlinedTextField(
                            value = dateDisplay,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Purchase Date") },
                            trailingIcon = {
                                IconButton(onClick = {
                                    val cal = Calendar.getInstance().apply { timeInMillis = purchaseDateMs }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            purchaseDateMs = c.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date")
                                }
                            },
                            modifier = Modifier.weight(1.2f)
                        )
                    }

                    // Pricing breakdown
                    Text("Price Breakdown", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = mrpStr,
                            onValueChange = { mrpStr = it },
                            label = { Text("MRP (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = originalPriceStr,
                            onValueChange = { originalPriceStr = it },
                            label = { Text("Base Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Purchase Discount Mode Selector
                    DiscountTypeSelector(
                        selectedType = discountType,
                        onTypeSelected = { discountType = it },
                        label = "Purchase Discount Mode"
                    )

                    if (discountType == "PERCENTAGE") {
                        OutlinedTextField(
                            value = discountPercentStr,
                            onValueChange = { discountPercentStr = it },
                            label = { Text("Purchase Discount (%)") },
                            supportingText = { Text("Profile default: %.2f%% (editable for this transaction)".format(defaultProfileDiscount)) },
                            trailingIcon = { Text("%", fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 12.dp)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("purchase_discount_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = discountFixedAmountStr,
                            onValueChange = { discountFixedAmountStr = it },
                            label = { Text("Purchase Discount Fixed Amount (₹ per unit)") },
                            supportingText = { Text("Direct cash discount deducted from base price per unit") },
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("purchase_discount_fixed_input")
                        )
                    }

                    // GST Type Selector: Percentage (%) vs Fixed Amount (₹)
                    GstTypeSelector(
                        selectedType = gstType,
                        onTypeSelected = { gstType = it }
                    )

                    if (gstType == "PERCENTAGE") {
                        OutlinedTextField(
                            value = taxPercentStr,
                            onValueChange = { taxPercentStr = it },
                            label = { Text("GST Percentage (%) *") },
                            placeholder = { Text("e.g. 18") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("purchase_tax_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = gstFixedAmountStr,
                            onValueChange = { gstFixedAmountStr = it },
                            label = { Text("GST Fixed Amount (₹ per unit) *") },
                            placeholder = { Text("e.g. 100") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth().testTag("purchase_gst_fixed_input")
                        )
                    }

                    // Calculation Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Automatic Calculations", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            val discLabel = if (discountType == "FIXED_AMOUNT") {
                                "Discount Amount: ₹%.2f (₹%.2f/unit)".format(discAmtPerUnit * qty, discAmtPerUnit)
                            } else {
                                "Discount Amount (%.1f%%): ₹%.2f".format(discPercent, discAmtPerUnit * qty)
                            }
                            Text(discLabel, style = MaterialTheme.typography.bodySmall)
                            val gstLabel = if (gstType == "FIXED_AMOUNT") {
                                "GST Fixed: ₹%.2f (₹%.2f/unit)".format(taxAmtPerUnit * qty, taxAmtPerUnit)
                            } else {
                                "GST Amount (%.1f%%): ₹%.2f".format(taxPercent, taxAmtPerUnit * qty)
                            }
                            Text(gstLabel, style = MaterialTheme.typography.bodySmall)
                            Text("Final Price Per Unit: ₹%.2f".format(finalPricePerUnit), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Volume Points Earned:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text("%.2f pts".format(totalPoints), fontWeight = FontWeight.Bold, color = PointsGold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Purchase Amount:", fontWeight = FontWeight.Bold)
                                Text("₹%.2f".format(totalAmount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                            }
                        }
                    }

                    // Supplier, Invoice & Receipt
                    OutlinedTextField(
                        value = supplierName,
                        onValueChange = { supplierName = it },
                        label = { Text("Supplier / Vendor Name (Optional)") },
                        placeholder = { Text("e.g. Optimum Health Distribution") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = invoiceNumber,
                        onValueChange = { invoiceNumber = it },
                        label = { Text("Invoice / Bill Number (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Payment & Settlement Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment Details", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = when (paymentStatus) {
                                        "PAID" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                        "PARTIAL" -> Color(0xFFF57F17).copy(alpha = 0.15f)
                                        else -> Color(0xFFC62828).copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = paymentStatus,
                                        color = when (paymentStatus) {
                                            "PAID" -> Color(0xFF2E7D32)
                                            "PARTIAL" -> Color(0xFFF57F17)
                                            else -> Color(0xFFC62828)
                                        },
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Bill Cost:", style = MaterialTheme.typography.bodyMedium)
                                Text("₹%.2f".format(totalAmount), fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = if (userModifiedPaid) amountPaidStr else if (totalAmount > 0) "%.2f".format(totalAmount) else "",
                                onValueChange = {
                                    userModifiedPaid = true
                                    amountPaidStr = it
                                },
                                label = { Text("Amount Paid (₹)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Balance Pending:", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "₹%.2f".format(pendingAmount),
                                    fontWeight = FontWeight.Bold,
                                    color = if (pendingAmount > 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
